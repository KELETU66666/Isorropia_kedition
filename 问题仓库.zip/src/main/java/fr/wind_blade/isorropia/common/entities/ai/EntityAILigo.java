/*     */ package fr.wind_blade.isorropia.common.entities.ai;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.state.BlockFaceShape;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAITasks;
/*     */ import net.minecraft.pathfinding.PathPoint;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import thaumcraft.common.lib.SoundsTC;
/*     */ import thaumcraft.common.lib.network.PacketHandler;
/*     */ import thaumcraft.common.lib.network.fx.PacketFXBlockArc;
/*     */ 
/*     */ public class EntityAILigo
/*     */   extends EntityAIBase {
/*     */   protected EntityLiving living;
/*     */   protected Chunk bindChunk;
/*     */   
/*     */   public EntityAILigo(EntityLiving living, Chunk bindChunk, int chunkRange, EntityAITasks.EntityAITaskEntry entry) {
/*  26 */     this.living = living;
/*  27 */     this.bindChunk = bindChunk;
/*  28 */     this.chunkRange = chunkRange;
/*  29 */     this.entry = entry;
/*     */     
/*  31 */     living.field_70714_bg.field_75782_a.remove(entry);
/*     */   }
/*     */   protected int chunkRange; protected EntityAITasks.EntityAITaskEntry entry;
/*     */   
/*     */   public boolean func_75250_a() {
/*  36 */     Chunk livingChunk = this.living.field_70170_p.func_72964_e((int)this.living.field_70165_t >> 4, (int)this.living.field_70161_v >> 4);
/*     */     
/*  38 */     int distance = getDistance(livingChunk);
/*  39 */     boolean havePath = !this.living.func_70661_as().func_75500_f();
/*     */     
/*  41 */     if (distance > this.chunkRange) {
/*  42 */       if (havePath) {
/*  43 */         this.living.func_70661_as().func_75499_g();
/*     */       }
/*  45 */       return true;
/*     */     } 
/*     */     
/*  48 */     if (havePath) {
/*  49 */       PathPoint point = this.living.func_70661_as().func_75505_d().func_189964_i();
/*     */       
/*  51 */       if (point != null) {
/*  52 */         Chunk targetChunk = this.living.field_70170_p.func_72964_e(point.field_75839_a >> 4, point.field_75838_c >> 4);
/*  53 */         distance = getDistance(targetChunk);
/*     */         
/*  55 */         if (distance > this.chunkRange) {
/*  56 */           this.living.func_70661_as().func_75499_g();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  67 */     double distance = getDistance((int)this.living.field_70165_t >> 4, (int)this.living.field_70161_v >> 4);
/*  68 */     if (distance <= this.living.func_70661_as().func_111269_d()) {
/*  69 */       BlockPos pos = findSuitableBlockPos(this.bindChunk);
/*     */       
/*  71 */       if (pos != null && 
/*  72 */         this.living.func_70661_as().func_75492_a(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), 1.0D)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  78 */     tpToBindedChunk();
/*     */   }
/*     */   
/*     */   public void tpToBindedChunk() {
/*  82 */     BlockPos pos = findSuitableBlockPos(this.bindChunk);
/*     */     
/*  84 */     if (pos != null) {
/*  85 */       PacketHandler.INSTANCE.sendToAllTracking((IMessage)new PacketFXBlockArc(pos, (Entity)this.living, 0.5F + (new Random())
/*  86 */             .nextFloat() * 0.2F, 0.0F, 0.0F), (Entity)this.living);
/*     */       
/*  88 */       this.living.func_184185_a(SoundsTC.wandfail, 1.0F, 1.0F);
/*     */       
/*  90 */       this.living.func_70012_b(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), this.living.field_70177_z, this.living.field_70125_A);
/*     */       
/*  92 */       this.living.func_70661_as().func_75499_g();
/*     */     } 
/*     */   }
/*     */   
/*     */   public BlockPos findSuitableBlockPos(Chunk chunk) {
/*  97 */     int i = chunk.field_76635_g * 16 + 8;
/*  98 */     int j = chunk.field_76647_h * 16 + 8;
/*     */     
/* 100 */     for (int y = 255; y > 0; y--) {
/* 101 */       for (int l = 0; l <= 4; l++) {
/* 102 */         for (int i1 = 0; i1 <= 4; i1++) {
/* 103 */           if ((l < 1 || i1 < 1 || l > 3 || i1 > 3) && isTeleportFriendlyBlock(i, j, y, l, i1)) {
/* 104 */             return new BlockPos(((i + l) + 0.5F), y, ((j + i1) + 0.5F));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 109 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isTeleportFriendlyBlock(int x, int z, int y, int xOffset, int zOffset) {
/* 113 */     int distance = getDistance(this.living.field_70170_p.func_72964_e(x >> 4, z >> 4));
/* 114 */     if (distance > this.chunkRange) {
/* 115 */       return false;
/*     */     }
/*     */     
/* 118 */     BlockPos blockpos = new BlockPos(x + xOffset, y - 1, z + zOffset);
/* 119 */     IBlockState iblockstate = this.living.field_70170_p.func_180495_p(blockpos);
/* 120 */     return (iblockstate.func_193401_d((IBlockAccess)this.living.field_70170_p, blockpos, EnumFacing.DOWN) == BlockFaceShape.SOLID && iblockstate
/* 121 */       .func_189884_a((Entity)this.living) && this.living.field_70170_p.func_175623_d(blockpos.func_177984_a()) && this.living.field_70170_p
/* 122 */       .func_175623_d(blockpos.func_177981_b(2)));
/*     */   }
/*     */   
/*     */   public EntityAITasks.EntityAITaskEntry getAi() {
/* 126 */     return this.entry;
/*     */   }
/*     */   
/*     */   public int getDistance(Chunk targetChunk) {
/* 130 */     return getDistance(targetChunk.field_76635_g, targetChunk.field_76647_h);
/*     */   }
/*     */   
/*     */   public int getDistance(int targetX, int targetZ) {
/* 134 */     return (int)Math.sqrt(Math.pow((this.bindChunk.field_76635_g - targetX), 2.0D) + Math.pow((this.bindChunk.field_76647_h - targetZ), 2.0D));
/*     */   }
/*     */   
/*     */   public int getChunkRange() {
/* 138 */     return this.chunkRange;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\ai\EntityAILigo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */