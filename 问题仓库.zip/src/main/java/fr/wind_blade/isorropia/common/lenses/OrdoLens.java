/*     */ package fr.wind_blade.isorropia.common.lenses;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.items.misc.ItemLens;
/*     */ import java.awt.Color;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectHelper;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.research.ScanningManager;
/*     */ import thaumcraft.client.fx.FXDispatcher;
/*     */ import thaumcraft.client.lib.events.RenderEventHandler;
/*     */ import thaumcraft.common.lib.utils.EntityUtils;
/*     */ 
/*     */ public class OrdoLens
/*     */   extends Lens
/*     */ {
/*     */   private static float nameSize;
/*     */   
/*     */   public OrdoLens(ItemLens lensIn) {
/*  41 */     super(lensIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleTicks(World worldIn, EntityPlayer playerIn, boolean doubleLens) {
/*  46 */     if (worldIn.field_72995_K) {
/*     */       return;
/*     */     }
/*  49 */     Entity target = EntityUtils.getPointedEntity(worldIn, (Entity)playerIn, 1.0D, 5.0D, 0.0F, true);
/*     */     
/*  51 */     if (target != null && ScanningManager.isThingStillScannable(playerIn, target)) {
/*  52 */       ScanningManager.scanTheThing(playerIn, target);
/*     */     } else {
/*     */       
/*  55 */       RayTraceResult mop = rayTrace(worldIn, playerIn, true);
/*  56 */       if (mop != null && mop.func_178782_a() != null && 
/*  57 */         ScanningManager.isThingStillScannable(playerIn, mop.func_178782_a())) {
/*  58 */         ScanningManager.scanTheThing(playerIn, mop.func_178782_a());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void handleRenderGameOverlay(World worldIn, EntityPlayer playerIn, ScaledResolution resolution, boolean doubleLens, float partialTicks) {
/*  69 */     if ((Minecraft.func_71410_x()).field_71474_y.field_74320_O != 0) {
/*     */       return;
/*     */     }
/*  72 */     Entity target = EntityUtils.getPointedEntity(worldIn, (Entity)playerIn, 1.0D, 5.0D, 0.0F, true);
/*  73 */     if (target != null) {
/*  74 */       Entity entity = RenderEventHandler.thaumTarget;
/*  75 */       if (entity == null || entity != target) {
/*  76 */         RenderEventHandler.tagscale = 0.0F;
/*  77 */         nameSize = 0.0F;
/*     */       } 
/*  79 */       RenderEventHandler.thaumTarget = target;
/*     */       
/*  81 */       if (ScanningManager.isThingStillScannable(playerIn, target)) {
/*  82 */         FXDispatcher.INSTANCE.scanHighlight(target);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*  87 */     RayTraceResult mop = rayTrace(worldIn, playerIn, true);
/*  88 */     if (mop != null && mop.func_178782_a() != null && mop.field_72313_a == RayTraceResult.Type.BLOCK) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       List<EntityItem> itemstacks = (Minecraft.func_71410_x()).field_71441_e.func_72872_a(EntityItem.class, new AxisAlignedBB(new BlockPos(mop
/*  95 */               .func_178782_a().func_177958_n(), mop.func_178782_a().func_177956_o() + 1, mop
/*  96 */               .func_178782_a().func_177952_p())));
/*  97 */       if (!itemstacks.isEmpty() && !((EntityItem)itemstacks.get(0)).func_92059_d().func_190926_b()) {
/*  98 */         renderNameAndAspects(resolution, AspectHelper.getObjectAspects(((EntityItem)itemstacks.get(0)).func_92059_d()), ((EntityItem)itemstacks
/*  99 */             .get(0)).func_92059_d().func_82833_r());
/*     */         
/* 101 */         if (ScanningManager.isThingStillScannable(playerIn, itemstacks.get(0))) {
/* 102 */           FXDispatcher.INSTANCE.scanHighlight((Entity)itemstacks.get(0));
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 107 */         RayTraceResult mob = playerIn.func_174822_a(5.0D, partialTicks);
/* 108 */         if (mob != null && mop.func_178782_a() != null) {
/* 109 */           Block block = worldIn.func_180495_p(mop.func_178782_a()).func_177230_c();
/* 110 */           renderNameAndAspects(resolution, AspectHelper.getObjectAspects(new ItemStack(block)), block
/* 111 */               .func_149732_F());
/*     */           
/* 113 */           if (ScanningManager.isThingStillScannable(playerIn, mob.func_178782_a())) {
/* 114 */             FXDispatcher.INSTANCE.scanHighlight(mop.func_178782_a());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void handleRenderWorldLast(World worldIn, EntityPlayer playerIn, boolean doubleLens, float partialTicks) {
/* 126 */     Entity entity = RenderEventHandler.thaumTarget;
/* 127 */     if (entity != null) {
/*     */       
/* 129 */       if (entity.field_70128_L) {
/* 130 */         RenderEventHandler.thaumTarget = null;
/*     */         
/*     */         return;
/*     */       } 
/* 134 */       double playerOffX = playerIn.field_70169_q + (playerIn.field_70165_t - playerIn.field_70169_q) * partialTicks;
/* 135 */       double playerOffY = playerIn.field_70167_r + (playerIn.field_70163_u - playerIn.field_70167_r) * partialTicks;
/* 136 */       double playerOffZ = playerIn.field_70166_s + (playerIn.field_70161_v - playerIn.field_70166_s) * partialTicks;
/*     */       
/* 138 */       double eOffX = entity.field_70169_q + (entity.field_70165_t - entity.field_70169_q) * partialTicks;
/* 139 */       double eOffY = entity.field_70167_r + (entity.field_70163_u - entity.field_70167_r) * partialTicks;
/* 140 */       double eOffZ = entity.field_70166_s + (entity.field_70161_v - entity.field_70166_s) * partialTicks;
/* 141 */       AspectList aspects = AspectHelper.getEntityAspects(entity);
/*     */       
/* 143 */       GlStateManager.func_179094_E();
/*     */       
/* 145 */       GlStateManager.func_179137_b(-playerOffX, -playerOffY, -playerOffZ);
/* 146 */       GlStateManager.func_179137_b(eOffX, eOffY + entity.field_70131_O + ((aspects != null && aspects.size() > 0) ? 1.1D : 0.6D), eOffZ);
/*     */ 
/*     */       
/* 149 */       GlStateManager.func_179114_b(-playerIn.field_70177_z, 0.0F, 1.0F, 0.0F);
/* 150 */       GlStateManager.func_179114_b(180.0F, 0.0F, 0.0F, 1.0F);
/*     */       
/* 152 */       if (nameSize < 1.0F)
/* 153 */         nameSize += 0.031F; 
/* 154 */       float size = 0.03F * nameSize;
/* 155 */       GlStateManager.func_179152_a(size, size, size);
/*     */ 
/*     */       
/* 158 */       String name = (entity instanceof EntityItem) ? ((EntityItem)entity).func_92059_d().func_82833_r() : entity.func_70005_c_();
/* 159 */       (Minecraft.func_71410_x()).field_71466_p.func_78276_b(name, 1 - 
/* 160 */           (Minecraft.func_71410_x()).field_71466_p.func_78256_a(name) / 2, 1, Color.WHITE.getRGB());
/*     */       
/* 162 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleRemoval(World worldIn, EntityPlayer playerIn) {
/* 168 */     if (worldIn.field_72995_K) {
/* 169 */       RenderEventHandler.thaumTarget = null;
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static void renderNameAndAspects(ScaledResolution resolution, AspectList aspects, String text) {
/* 175 */     int w = resolution.func_78326_a();
/* 176 */     int h = resolution.func_78328_b();
/*     */     
/* 178 */     if (aspects != null && aspects.size() > 0) {
/* 179 */       int num = 0;
/* 180 */       int yOff = 0;
/* 181 */       int thisRow = 0;
/* 182 */       int size = 18;
/* 183 */       if (aspects.size() - num < 5) {
/* 184 */         thisRow = aspects.size() - num;
/*     */       } else {
/* 186 */         thisRow = 5;
/*     */       } 
/*     */       
/* 189 */       for (Aspect aspect : aspects.getAspects()) {
/* 190 */         yOff = num / 5 * size;
/* 191 */         drawAspectTag(aspect, aspects.getAmount(aspect), w / 2 - size * thisRow / 2 + size * num % 5, h / 2 + 16 + yOff);
/*     */         
/* 193 */         if (++num % 5 == 0)
/*     */         {
/*     */           
/* 196 */           if (aspects.size() - num < 5) {
/* 197 */             thisRow = aspects.size() - num;
/*     */           } else {
/* 199 */             thisRow = 5;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 204 */     if (text.length() > 0) {
/* 205 */       (Minecraft.func_71410_x()).field_71456_v.func_73731_b((Minecraft.func_71410_x()).field_71466_p, text, w / 2 - 
/* 206 */           (Minecraft.func_71410_x()).field_71466_p.func_78256_a(text) / 2, h / 2 - 16, 16777215);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static void drawAspectTag(Aspect aspect, int amount, int x, int y) {
/* 212 */     Color color = new Color(aspect.getColor());
/* 213 */     GL11.glPushMatrix();
/* 214 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 0.5F);
/* 215 */     Minecraft.func_71410_x().func_110434_K().func_110577_a(aspect.getImage());
/* 216 */     Tessellator tessellator = Tessellator.func_178181_a();
/* 217 */     BufferBuilder buffer = tessellator.func_178180_c();
/* 218 */     buffer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
/* 219 */     buffer.func_178994_b(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 0);
/* 220 */     buffer.func_181662_b(x, y, 0.0D).func_187315_a(0.0D, 0.0D)
/* 221 */       .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F)
/* 222 */       .func_181675_d();
/* 223 */     buffer.func_181662_b(x, y + 16.0D, 0.0D).func_187315_a(0.0D, 1.0D)
/* 224 */       .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F)
/* 225 */       .func_181675_d();
/* 226 */     buffer.func_181662_b(x + 16.0D, y + 16.0D, 0.0D).func_187315_a(1.0D, 1.0D)
/* 227 */       .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F)
/* 228 */       .func_181675_d();
/* 229 */     buffer.func_181662_b(x + 16.0D, y, 0.0D).func_187315_a(1.0D, 0.0D)
/* 230 */       .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F)
/* 231 */       .func_181675_d();
/* 232 */     tessellator.func_78381_a();
/* 233 */     GL11.glScalef(0.5F, 0.5F, 0.5F);
/* 234 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 235 */     DecimalFormat myFormatter = new DecimalFormat("#######.##");
/* 236 */     String am = myFormatter.format(amount);
/* 237 */     (Minecraft.func_71410_x()).field_71466_p.func_78276_b(am, 24 + x * 2, 32 - 
/* 238 */         (Minecraft.func_71410_x()).field_71466_p.field_78288_b + y * 2, 16777215);
/* 239 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 240 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   public static RayTraceResult rayTrace(World worldIn, EntityPlayer playerIn, boolean useLiquids) {
/* 244 */     float f = playerIn.field_70125_A;
/* 245 */     float f1 = playerIn.field_70177_z;
/* 246 */     double d0 = playerIn.field_70165_t;
/* 247 */     double d1 = playerIn.field_70163_u + playerIn.func_70047_e();
/* 248 */     double d2 = playerIn.field_70161_v;
/* 249 */     Vec3d vec3d = new Vec3d(d0, d1, d2);
/* 250 */     float f2 = MathHelper.func_76134_b(-f1 * 0.017453292F - 3.1415927F);
/* 251 */     float f3 = MathHelper.func_76126_a(-f1 * 0.017453292F - 3.1415927F);
/* 252 */     float f4 = -MathHelper.func_76134_b(-f * 0.017453292F);
/* 253 */     float f5 = MathHelper.func_76126_a(-f * 0.017453292F);
/* 254 */     float f6 = f3 * f4;
/* 255 */     float f7 = f2 * f4;
/* 256 */     double d3 = playerIn.func_110148_a(EntityPlayer.REACH_DISTANCE).func_111126_e();
/* 257 */     Vec3d vec3d1 = vec3d.func_72441_c(f6 * d3, f5 * d3, f7 * d3);
/* 258 */     return worldIn.func_147447_a(vec3d, vec3d1, useLiquids, !useLiquids, false);
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\lenses\OrdoLens.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */