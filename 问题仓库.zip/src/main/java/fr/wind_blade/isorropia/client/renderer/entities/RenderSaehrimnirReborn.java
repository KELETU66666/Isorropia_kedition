/*     */ package fr.wind_blade.isorropia.client.renderer.entities;
/*     */ 
/*     */ import fr.wind_blade.isorropia.client.model.ModelSaehrimnirReborn;
/*     */ import fr.wind_blade.isorropia.client.renderer.RenderEntity;
/*     */ import fr.wind_blade.isorropia.common.entities.EntitySaehrimnirReborn;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderSaehrimnirReborn extends RenderEntity<EntitySaehrimnirReborn> {
/*  23 */   private static final ResourceLocation TEXTURE = new ResourceLocation("textures/blocks/cobblestone.png");
/*     */   
/*     */   public RenderSaehrimnirReborn(RenderManager renderManagerIn) {
/*  26 */     super(renderManagerIn, (ModelBase)new ModelSaehrimnirReborn(), 0.5F);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ResourceLocation getEntityTexture(EntitySaehrimnirReborn entity) {
/*  31 */     return TEXTURE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_76979_b(Entity entityIn, double x, double y, double z, float yaw, float partialTicks) {
/*  36 */     if (this.field_76990_c.field_78733_k != null && 
/*  37 */       entityIn.func_90999_ad() && (!(entityIn instanceof EntityPlayer) || 
/*  38 */       !((EntityPlayer)entityIn).func_175149_v())) {
/*  39 */       renderEntityOnFire(entityIn, x, y, z, partialTicks);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderEntityOnFire(Entity entity, double x, double y, double z, float partialTicks) {
/*  45 */     GlStateManager.func_179140_f();
/*  46 */     TextureMap texturemap = Minecraft.func_71410_x().func_147117_R();
/*  47 */     TextureAtlasSprite textureatlassprite = texturemap.func_110572_b("minecraft:blocks/fire_layer_0");
/*  48 */     TextureAtlasSprite textureatlassprite1 = texturemap.func_110572_b("minecraft:blocks/fire_layer_1");
/*  49 */     GlStateManager.func_179094_E();
/*  50 */     GlStateManager.func_179109_b((float)x, (float)y, (float)z);
/*  51 */     float f = entity.field_70130_N * 1.4F;
/*  52 */     GlStateManager.func_179152_a(f, f, f);
/*  53 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  54 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/*  55 */     float f1 = 0.5F;
/*  56 */     float f3 = entity.field_70131_O / f;
/*  57 */     float f4 = (float)(entity.field_70163_u - (entity.func_174813_aQ()).field_72338_b);
/*  58 */     GlStateManager.func_179114_b(-this.field_76990_c.field_78735_i, 0.0F, 1.0F, 0.0F);
/*  59 */     GlStateManager.func_179109_b(0.0F, 0.0F, -0.3F + (int)f3 * 0.02F);
/*  60 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*  61 */     float f5 = 0.0F;
/*  62 */     int i = 0;
/*  63 */     vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*     */     
/*  65 */     while (f3 > 0.0F) {
/*  66 */       TextureAtlasSprite textureatlassprite2 = (i % 2 == 0) ? textureatlassprite : textureatlassprite1;
/*  67 */       func_110776_a(TextureMap.field_110575_b);
/*  68 */       float f6 = textureatlassprite2.func_94209_e();
/*  69 */       float f7 = textureatlassprite2.func_94206_g();
/*  70 */       float f8 = textureatlassprite2.func_94212_f();
/*  71 */       float f9 = textureatlassprite2.func_94210_h();
/*     */       
/*  73 */       if (i / 2 % 2 == 0) {
/*  74 */         float f10 = f8;
/*  75 */         f8 = f6;
/*  76 */         f6 = f10;
/*     */       } 
/*     */       
/*  79 */       vertexbuffer.func_181662_b((f1 - 0.0F), (0.0F - f4), f5).func_187315_a(f8, f9).func_181675_d();
/*  80 */       vertexbuffer.func_181662_b((-f1 - 0.0F), (0.0F - f4), f5).func_187315_a(f6, f9).func_181675_d();
/*  81 */       vertexbuffer.func_181662_b((-f1 - 0.0F), (1.4F - f4), f5).func_187315_a(f6, f7).func_181675_d();
/*  82 */       vertexbuffer.func_181662_b((f1 - 0.0F), (1.4F - f4), f5).func_187315_a(f8, f7).func_181675_d();
/*  83 */       f3 -= 0.45F;
/*  84 */       f4 -= 0.45F;
/*  85 */       f1 *= 0.9F;
/*  86 */       f5 += 0.03F;
/*  87 */       i++;
/*     */     } 
/*     */     
/*  90 */     tessellator.func_78381_a();
/*  91 */     GlStateManager.func_179121_F();
/*  92 */     GlStateManager.func_179145_e();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doRender(EntitySaehrimnirReborn entity, double x, double y, double z, float entityYaw, float partialTicks) {
/*  98 */     GlStateManager.func_179094_E();
/*  99 */     float scale = (entity.field_70173_aa + partialTicks) / 24000.0F;
/* 100 */     GlStateManager.func_179137_b((float)x, (float)y + (
/* 101 */         (entity.func_174813_aQ()).field_72337_e - (entity.func_174813_aQ()).field_72338_b) / 2.0D, (float)z);
/* 102 */     GlStateManager.func_179152_a(scale, scale, scale);
/* 103 */     GlStateManager.func_179137_b(0.0D, -0.5D, 0.0D);
/* 104 */     if (this.field_188301_f) {
/* 105 */       GlStateManager.func_179142_g();
/* 106 */       GlStateManager.func_187431_e(func_188298_c((Entity)entity));
/*     */     } 
/*     */     
/* 109 */     func_180548_c((Entity)entity);
/* 110 */     ModelBase model = this.mainModel;
/*     */ 
/*     */     
/* 113 */     float pitch = -((float)Math.toRadians((entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks)));
/*     */ 
/*     */     
/* 116 */     model.func_78088_a((Entity)entity, 0.0F, 0.0F, entity.field_70173_aa + partialTicks, 0.0F, pitch, 0.0625F);
/*     */     
/* 118 */     if (this.field_188301_f) {
/* 119 */       GlStateManager.func_187417_n();
/* 120 */       GlStateManager.func_179119_h();
/*     */     } 
/*     */     
/* 123 */     GlStateManager.func_179121_F();
/*     */     
/* 125 */     if (!this.field_188301_f)
/* 126 */       func_177067_a((Entity)entity, x, y, z); 
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\entities\RenderSaehrimnirReborn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */