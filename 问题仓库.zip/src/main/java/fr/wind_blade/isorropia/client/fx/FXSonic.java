/*     */ package fr.wind_blade.isorropia.client.fx;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.particle.ParticleManager;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.ReflectionHelper;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.obj.AdvancedModelLoader;
/*     */ import thaumcraft.client.lib.obj.IModelCustom;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class FXSonic
/*     */   extends Particle
/*     */ {
/*  24 */   public Entity target = null;
/*  25 */   public float yaw = 0.0F;
/*  26 */   public float pitch = 0.0F;
/*     */   public IModelCustom hemisphere;
/*  28 */   public static final ResourceLocation MODEL = new ResourceLocation("thaumcraft", "models/obj/hemis.obj");
/*     */   
/*     */   public FXSonic(World world, double d, double d1, double d2, Entity target, int age) {
/*  31 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*  32 */     this.particleRed = 0.0F;
/*  33 */     this.particleGreen = 1.0F;
/*  34 */     this.particleBlue = 1.0F;
/*  35 */     this.field_70545_g = 0.0F;
/*  36 */     this.field_187131_k = 0.0D;
/*  37 */     this.field_187130_j = 0.0D;
/*  38 */     this.field_187129_i = 0.0D;
/*  39 */     this.field_70547_e = age + this.field_187136_p.nextInt(age / 2);
/*  40 */     this.field_190017_n = false;
/*  41 */     func_187115_a(0.01F, 0.01F);
/*  42 */     this.field_190017_n = true;
/*  43 */     this.field_70544_f = 1.0F;
/*  44 */     this.target = target;
/*  45 */     this.yaw = target.func_70079_am();
/*  46 */     this.pitch = target.field_70125_A;
/*  47 */     this.field_187123_c = this.field_187126_f = target.field_70165_t;
/*  48 */     this.field_187124_d = this.field_187127_g = target.field_70163_u + target.func_70047_e();
/*  49 */     this.field_187125_e = this.field_187128_h = target.field_70161_v;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180434_a(BufferBuilder buffer, Entity entityIn, float f, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/*  55 */     Tessellator.func_178181_a().func_78381_a();
/*  56 */     GL11.glPushMatrix();
/*  57 */     GL11.glDepthMask(false);
/*  58 */     GL11.glEnable(3042);
/*  59 */     GL11.glBlendFunc(770, 771);
/*  60 */     if (this.hemisphere == null) {
/*  61 */       this.hemisphere = AdvancedModelLoader.loadModel(MODEL);
/*     */     }
/*  63 */     float fade = (this.field_70546_d + f) / this.field_70547_e;
/*  64 */     float xx = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * f - field_70556_an);
/*  65 */     float yy = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * f - field_70554_ao);
/*  66 */     float zz = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * f - field_70555_ap);
/*  67 */     GL11.glTranslated(xx, yy, zz);
/*  68 */     float b = 1.0F;
/*  69 */     int frame = Math.min(15, (int)(14.0F * fade) + 1);
/*  70 */     (Minecraft.func_71410_x()).field_71446_o
/*  71 */       .func_110577_a(new ResourceLocation("thaumcraft", "textures/models/ripple" + frame + ".png"));
/*  72 */     b = 0.5F;
/*  73 */     int i = 220;
/*  74 */     int j = i % 65536;
/*  75 */     int k = i / 65536;
/*  76 */     OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, j / 1.0F, k / 1.0F);
/*  77 */     GL11.glRotatef(-this.yaw, 0.0F, 1.0F, 0.0F);
/*  78 */     GL11.glRotatef(this.pitch, 1.0F, 0.0F, 0.0F);
/*  79 */     GL11.glTranslated(0.0D, 0.0D, (2.0F * this.target.field_70131_O + this.target.field_70130_N / 2.0F));
/*  80 */     GL11.glScaled(0.25D * this.target.field_70131_O, 0.25D * this.target.field_70131_O, (-1.0F * this.target.field_70131_O));
/*     */     
/*  82 */     GL11.glColor4f(0.0F, b, b, 1.0F);
/*  83 */     this.hemisphere.renderAll();
/*  84 */     GL11.glDisable(3042);
/*  85 */     GL11.glDepthMask(true);
/*  86 */     GL11.glPopMatrix();
/*  87 */     (Minecraft.func_71410_x()).field_71446_o.func_110577_a(getParticleTexture());
/*  88 */     buffer.func_181668_a(7, DefaultVertexFormats.field_181704_d);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_189213_a() {
/*  93 */     this.field_187123_c = this.field_187126_f;
/*  94 */     this.field_187124_d = this.field_187127_g;
/*  95 */     this.field_187125_e = this.field_187128_h;
/*  96 */     if (this.field_70546_d++ >= this.field_70547_e) {
/*  97 */       func_187112_i();
/*     */     }
/*     */   }
/*     */   
/*     */   public static ResourceLocation getParticleTexture() {
/*     */     try {
/* 103 */       return (ResourceLocation)ReflectionHelper.getPrivateValue(ParticleManager.class, null, new String[] { "PARTICLE_TEXTURES", "b", "field_110737_b" });
/*     */     }
/* 105 */     catch (Exception e) {
/* 106 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\fx\FXSonic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */