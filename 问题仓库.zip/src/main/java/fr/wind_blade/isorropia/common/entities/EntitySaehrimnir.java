 package fr.wind_blade.isorropia.common.entities;
 
 import net.minecraft.entity.passive.EntityPig;
 import net.minecraft.world.World;
 
 
 
 
 public class EntitySaehrimnir
   extends EntityPig
 {
   public EntitySaehrimnir(World worldIn) {
/* 13 */     super(worldIn);
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntitySaehrimnir.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */