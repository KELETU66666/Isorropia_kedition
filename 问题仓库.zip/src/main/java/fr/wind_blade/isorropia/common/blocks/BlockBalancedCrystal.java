/*   */ package fr.wind_blade.isorropia.common.blocks;
/*   */ 
/*   */ import thaumcraft.api.aspects.Aspect;
/*   */ import thaumcraft.common.blocks.world.ore.BlockCrystal;
/*   */ 
/*   */ public class BlockBalancedCrystal
/*   */   extends BlockCrystal {
/*   */   public BlockBalancedCrystal(Aspect aspect) {
/* 9 */     super("balanced_shard", aspect);
/*   */   }
/*   */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockBalancedCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */