/*     */ package fr.wind_blade.isorropia.common.entities.ai;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.libs.helpers.IRMathHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.passive.EntityTameable;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.pathfinding.Path;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import thaumcraft.common.lib.SoundsTC;
/*     */ import thaumcraft.common.lib.network.PacketHandler;
/*     */ import thaumcraft.common.lib.network.fx.PacketFXWispZap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIZapAttack
/*     */   extends EntityAIBase
/*     */ {
/*     */   protected final int attackCooldown;
/*     */   protected EntityLiving attacker;
/*     */   private final float range;
/*     */   boolean longMemory;
/*     */   Path path;
/*     */   
/*     */   public EntityAIZapAttack(EntityLiving attacker, float range, int cooldownTicks, boolean useLongMemory) {
/*  36 */     this.attacker = attacker;
/*  37 */     this.range = range;
/*  38 */     this.attackCooldown = cooldownTicks;
/*  39 */     this.longMemory = useLongMemory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  49 */     EntityLivingBase target = this.attacker.func_70638_az();
/*     */     
/*  51 */     if (target == null && 
/*  52 */       this.attacker instanceof EntityTameable) {
/*  53 */       EntityTameable tameable = (EntityTameable)this.attacker;
/*  54 */       if (!tameable.func_70909_n() || tameable.func_70902_q() == null) {
/*  55 */         return false;
/*     */       }
/*     */       
/*  58 */       tameable.func_70604_c(tameable.func_70902_q().func_94060_bK());
/*  59 */       target = this.attacker.func_70638_az();
/*     */       
/*  61 */       if (target == null) {
/*  62 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  67 */     if (!target.func_70089_S()) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  76 */     EntityLivingBase target = this.attacker.func_70638_az();
/*     */     
/*  78 */     if (target == null || !target.func_70089_S()) {
/*  79 */       return false;
/*     */     }
/*     */     
/*  82 */     if (!(target instanceof EntityPlayer) || (
/*  83 */       !((EntityPlayer)target).func_175149_v() && !((EntityPlayer)target).func_184812_l_())) {
/*  84 */       return (IRMathHelper.getTchebychevDistance((Entity)this.attacker, (Entity)target) <= getAttackRange(target));
/*     */     }
/*     */     
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  92 */     EntityLivingBase target = this.attacker.func_70638_az();
/*     */     
/*  94 */     if (this.attacker.field_70173_aa % this.attackCooldown != 0) {
/*     */       return;
/*     */     }
/*     */     
/*  98 */     this.attacker.func_184185_a(SoundsTC.zap, 1.0F, 1.1F);
/*  99 */     PacketHandler.INSTANCE.sendToAllAround((IMessage)new PacketFXWispZap(this.attacker.func_145782_y(), target.func_145782_y()), new NetworkRegistry.TargetPoint(this.attacker.field_70170_p.field_73011_w
/* 100 */           .getDimension(), this.attacker.field_70165_t, this.attacker.field_70163_u, this.attacker.field_70161_v, 32.0D));
/*     */ 
/*     */     
/* 103 */     float damage = (float)this.attacker.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e();
/* 104 */     if (Math.abs(target.field_70159_w) > 0.10000000149011612D || Math.abs(target.field_70181_x) > 0.10000000149011612D || 
/* 105 */       Math.abs(target.field_70179_y) > 0.10000000149011612D) {
/* 106 */       target.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this.attacker), damage);
/*     */     } else {
/* 108 */       target.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this.attacker), damage + 1.0F);
/*     */     } 
/*     */   }
/*     */   
/*     */   private float getAttackRange(EntityLivingBase target) {
/* 113 */     return this.range;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\ai\EntityAIZapAttack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */