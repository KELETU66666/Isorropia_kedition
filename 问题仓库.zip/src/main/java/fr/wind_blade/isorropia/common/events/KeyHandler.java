 package fr.wind_blade.isorropia.common.events;
 
 import fr.wind_blade.isorropia.common.Common;
 import fr.wind_blade.isorropia.common.lenses.LensManager;
 import fr.wind_blade.isorropia.common.network.LensRemoveMessageSP;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.entity.EntityPlayerSP;
 import net.minecraft.client.settings.KeyBinding;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraftforge.fml.client.FMLClientHandler;
 import net.minecraftforge.fml.client.registry.ClientRegistry;
 import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
 import net.minecraftforge.fml.common.gameevent.InputEvent;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
 
 public class KeyHandler
 {
   public KeyBinding keyLens;
/* 19 */   public static long lastPressV = 0L;
   public static boolean radialActive;
   public static boolean radialLock;
   
   public KeyHandler() {
/* 24 */     this.keyLens = new KeyBinding("Change Goggles Lens", 47, "key.categories.misc");
/* 25 */     ClientRegistry.registerKeyBinding(this.keyLens);
   }
   
   @SubscribeEvent
   public void keyEvent(InputEvent.KeyInputEvent event) {
/* 30 */     if (this.keyLens.func_151470_d()) {
/* 31 */       if ((FMLClientHandler.instance().getClient()).field_71415_G) {
/* 32 */         EntityPlayerSP entityPlayerSP = (Minecraft.func_71410_x()).field_71439_g;
/* 33 */         if (entityPlayerSP != null) {
/* 34 */           if (entityPlayerSP.func_70093_af()) {
/* 35 */             Common.INSTANCE.sendToServer((IMessage)new LensRemoveMessageSP());
             return;
           } 
/* 38 */           lastPressV = System.currentTimeMillis();
/* 39 */           radialLock = false;
/* 40 */           if (!radialLock && !LensManager.getRevealer((EntityPlayer)entityPlayerSP).func_190926_b()) {
/* 41 */             radialActive = true;
           }
         } 
       } 
/* 45 */       lastPressV = System.currentTimeMillis();
     } else {
/* 47 */       radialActive = false;
     } 
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\events\KeyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */