 package fr.wind_blade.isorropia.client.renderer.entities;
 import fr.wind_blade.isorropia.common.entities.EntityScholarChicken;
 import net.minecraft.client.model.ModelBase;
 import net.minecraft.client.model.ModelChicken;
 import net.minecraft.client.renderer.entity.RenderLiving;
 import net.minecraft.client.renderer.entity.RenderManager;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.util.ResourceLocation;
 import net.minecraft.util.math.MathHelper;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 
 @SideOnly(Side.CLIENT)
 public class RenderScholarChicken extends RenderLiving<EntityScholarChicken> {
/* 16 */   public static ResourceLocation TEXTURE = new ResourceLocation("isorropia", "textures/entity/scholar_chicken.png");
 
   
   public RenderScholarChicken(RenderManager rendermanagerIn) {
/* 20 */     super(rendermanagerIn, (ModelBase)new ModelChicken(), 0.5F);
   }
 
   
   protected ResourceLocation getEntityTexture(EntityScholarChicken entity) {
/* 25 */     return TEXTURE;
   }
 
   
   protected float handleRotationFloat(EntityScholarChicken livingBase, float partialTicks) {
/* 30 */     float f = livingBase.field_70888_h + (livingBase.field_70886_e - livingBase.field_70888_h) * partialTicks;
/* 31 */     float f1 = livingBase.field_70884_g + (livingBase.field_70883_f - livingBase.field_70884_g) * partialTicks;
/* 32 */     return (MathHelper.func_76126_a(f) + 1.0F) * f1;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\entities\RenderScholarChicken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */