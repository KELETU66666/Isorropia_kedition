/*     */ package fr.wind_blade.isorropia.common.entities.projectile;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.projectile.EntityThrowable;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EntityDamageSourceIndirect;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.registry.IEntityAdditionalSpawnData;
/*     */ 
/*     */ 
/*     */ public class EntityEmber
/*     */   extends EntityThrowable
/*     */   implements IEntityAdditionalSpawnData
/*     */ {
/*     */   public int duration;
/*     */   public int firey;
/*     */   public float damage;
/*     */   
/*     */   public EntityEmber(World par1World) {
/*  26 */     super(par1World);
/*  27 */     this.duration = 20;
/*  28 */     this.firey = 0;
/*  29 */     this.damage = 1.0F;
/*     */   }
/*     */   
/*     */   public EntityEmber(World par1World, EntityLivingBase par2EntityLiving, float scatter) {
/*  33 */     super(par1World, par2EntityLiving);
/*  34 */     this.duration = 20;
/*  35 */     this.firey = 0;
/*  36 */     this.damage = 1.0F;
/*  37 */     func_70186_c(this.field_70159_w, this.field_70181_x, this.field_70179_y, func_70182_d(), scatter);
/*     */   }
/*     */   
/*     */   protected float func_70185_h() {
/*  41 */     return 0.0F;
/*     */   }
/*     */   
/*     */   protected float func_70182_d() {
/*  45 */     return 1.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70030_z() {
/*  50 */     if (this.field_70173_aa > this.duration) {
/*  51 */       func_70106_y();
/*     */     }
/*  53 */     if (this.duration <= 20) {
/*  54 */       this.field_70159_w *= 0.95D;
/*  55 */       this.field_70181_x *= 0.95D;
/*  56 */       this.field_70179_y *= 0.95D;
/*     */     } else {
/*  58 */       this.field_70159_w *= 0.975D;
/*  59 */       this.field_70181_x *= 0.975D;
/*  60 */       this.field_70179_y *= 0.975D;
/*     */     } 
/*  62 */     if (this.field_70122_E) {
/*  63 */       this.field_70159_w *= 0.66D;
/*  64 */       this.field_70181_x *= 0.66D;
/*  65 */       this.field_70179_y *= 0.66D;
/*     */     } 
/*  67 */     super.func_70030_z();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeSpawnData(ByteBuf data) {
/*  72 */     data.writeByte(this.duration);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readSpawnData(ByteBuf data) {
/*  77 */     this.duration = data.readByte();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70184_a(RayTraceResult mop) {
/*  82 */     if (!this.field_70170_p.field_72995_K) {
/*  83 */       if (mop.field_72308_g != null) {
/*  84 */         if (!mop.field_72308_g.func_70045_F()) if (mop.field_72308_g.func_70097_a((new EntityDamageSourceIndirect("fireball", (Entity)this, (Entity)
/*  85 */                 func_85052_h())).func_76361_j(), this.damage)) {
/*  86 */             mop.field_72308_g.func_70015_d(3 + this.firey);
/*     */           } 
/*  88 */       } else if (this.field_70146_Z.nextFloat() < 0.025F * this.firey) {
/*  89 */         double i = mop.field_72308_g.field_70165_t;
/*  90 */         double j = mop.field_72308_g.field_70163_u;
/*  91 */         double k = mop.field_72308_g.field_70161_v;
/*  92 */         switch (mop.field_178784_b.func_176745_a()) {
/*     */           case 0:
/*  94 */             j--;
/*     */             break;
/*     */           
/*     */           case 1:
/*  98 */             j++;
/*     */             break;
/*     */           
/*     */           case 2:
/* 102 */             k--;
/*     */             break;
/*     */           
/*     */           case 3:
/* 106 */             k++;
/*     */             break;
/*     */           
/*     */           case 4:
/* 110 */             i--;
/*     */             break;
/*     */           
/*     */           case 5:
/* 114 */             i++;
/*     */             break;
/*     */         } 
/* 117 */         if (this.field_70170_p.func_175623_d(new BlockPos(i, j, k))) {
/* 118 */           this.field_70170_p.func_175656_a(new BlockPos(i, j, k), Blocks.field_150480_ab.func_176223_P());
/*     */         }
/*     */       } 
/*     */     }
/* 122 */     func_70106_y();
/*     */   }
/*     */   
/*     */   protected boolean func_70041_e_() {
/* 126 */     return false;
/*     */   }
/*     */   
/*     */   public float func_70053_R() {
/* 130 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound par1NBTTagCompound) {
/* 135 */     super.func_70014_b(par1NBTTagCompound);
/* 136 */     par1NBTTagCompound.func_74776_a("damage", this.damage);
/* 137 */     par1NBTTagCompound.func_74768_a("firey", this.firey);
/* 138 */     par1NBTTagCompound.func_74768_a("duration", this.duration);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound par1NBTTagCompound) {
/* 143 */     super.func_70037_a(par1NBTTagCompound);
/* 144 */     this.damage = par1NBTTagCompound.func_74760_g("damage");
/* 145 */     this.firey = par1NBTTagCompound.func_74762_e("firey");
/* 146 */     this.duration = par1NBTTagCompound.func_74762_e("duration");
/*     */   }
/*     */   
/*     */   public boolean func_70067_L() {
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70097_a(DamageSource p_70097_1_, float p_70097_2_) {
/* 155 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\projectile\EntityEmber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */