/*     */ package fr.wind_blade.isorropia.common.research;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.IsorropiaAPI;
/*     */ import fr.wind_blade.isorropia.common.blocks.BlocksIS;
/*     */ import fr.wind_blade.isorropia.common.celestial.CelestialBody;
/*     */ import fr.wind_blade.isorropia.common.config.Config;
/*     */ import fr.wind_blade.isorropia.common.curative.JellyRabbitRecipe;
/*     */ import fr.wind_blade.isorropia.common.curative.OreBoarRecipe;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityChromaticSheep;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityGravekeeper;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityScholarChicken;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityTaintPig;
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import fr.wind_blade.isorropia.common.items.misc.ItemCat;
/*     */ import fr.wind_blade.isorropia.common.research.recipes.CurativeInfusionRecipe;
/*     */ import fr.wind_blade.isorropia.common.research.recipes.OrganCurativeInfusionRecipe;
/*     */ import fr.wind_blade.isorropia.common.research.recipes.SpecieCurativeInfusionRecipe;
/*     */ import java.util.Collection;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.monster.EntityIronGolem;
/*     */ import net.minecraft.entity.monster.EntityPigZombie;
/*     */ import net.minecraft.entity.monster.EntitySlime;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.passive.EntityChicken;
/*     */ import net.minecraft.entity.passive.EntityCow;
/*     */ import net.minecraft.entity.passive.EntityOcelot;
/*     */ import net.minecraft.entity.passive.EntityPig;
/*     */ import net.minecraft.entity.passive.EntityRabbit;
/*     */ import net.minecraft.entity.passive.EntitySheep;
/*     */ import net.minecraft.entity.passive.EntityVillager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemFood;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*     */ import net.minecraftforge.fml.common.registry.ForgeRegistries;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ import thaumcraft.api.ThaumcraftApi;
/*     */ import thaumcraft.api.ThaumcraftApiHelper;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectHelper;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.blocks.BlocksTC;
/*     */ import thaumcraft.api.crafting.IArcaneRecipe;
/*     */ import thaumcraft.api.crafting.InfusionRecipe;
/*     */ import thaumcraft.api.crafting.ShapedArcaneRecipe;
/*     */ import thaumcraft.api.entities.ITaintedMob;
/*     */ import thaumcraft.api.items.ItemsTC;
/*     */ import thaumcraft.api.research.IScanThing;
/*     */ import thaumcraft.api.research.ResearchCategories;
/*     */ import thaumcraft.api.research.ScanEntity;
/*     */ import thaumcraft.api.research.ScanningManager;
/*     */ 
/*     */ 
/*     */ public class ResearchsIS
/*     */ {
/*     */   private static void registerBatchAspect(AspectList aspects, Item... items) {
/*  73 */     for (Item item : items) ThaumcraftApi.registerObjectTag(new ItemStack(item), aspects); 
/*     */   }
/*     */   
/*     */   private static AspectList getAspects(ItemStack stack) {
/*  77 */     AspectList list = AspectHelper.getObjectAspects(stack);
/*  78 */     return (list != null) ? list : new AspectList();
/*     */   }
/*     */   
/*     */   private static void addAspects(ItemStack stack, AspectList aspects) {
/*  82 */     AspectList list = getAspects(stack);
/*     */     
/*  84 */     list.add(aspects);
/*  85 */     ThaumcraftApi.registerObjectTag(stack, list);
/*     */   }
/*     */   
/*     */   private static void addAspects(Item item, AspectList list) {
/*  89 */     addAspects(new ItemStack(item), list);
/*     */   }
/*     */   
/*     */   private static void addAspects(Block block, AspectList list) {
/*  93 */     addAspects(new ItemStack(block), list);
/*     */   }
/*     */   
/*     */   public static void initAspects(FMLPostInitializationEvent event) {
/*  97 */     for (Item item : ForgeRegistries.ITEMS) {
/*  98 */       if (item instanceof ItemFood) {
/*  99 */         ItemFood food = (ItemFood)item;
/* 100 */         ItemStack stack = new ItemStack(item);
/* 101 */         AspectList list = AspectHelper.getObjectAspects(stack);
/*     */         
/* 103 */         list = ((list == null) ? new AspectList() : list).add(IsorropiaAPI.HUNGER, Math.round(food.func_150905_g(stack)));
/* 104 */         for (int raw : OreDictionary.getOreIDs(stack)) {
/* 105 */           if (OreDictionary.getOreName(raw).contains("raw")) {
/* 106 */             list.add(IsorropiaAPI.FLESH, food.func_150905_g(stack));
/*     */             break;
/*     */           } 
/*     */         } 
/* 110 */         if (food.func_150906_h(stack) < 0.6D) {
/* 111 */           ThaumcraftApi.registerObjectTag(stack, list);
/*     */           continue;
/*     */         } 
/* 114 */         ThaumcraftApi.registerObjectTag(stack, list.add(IsorropiaAPI.GLUTTONY, Math.round(food.func_150906_h(stack) * food.func_150905_g(stack))));
/*     */       } 
/*     */     } 
/* 117 */     addAspects(Items.field_151016_H, (new AspectList()).add(IsorropiaAPI.WRATH, 2));
/* 118 */     addAspects(new ItemStack(Items.field_151144_bL, 1, 4), (new AspectList()).add(IsorropiaAPI.WRATH, 4));
/* 119 */     addAspects(Items.field_151073_bk, (new AspectList()).add(IsorropiaAPI.WRATH, 14));
/* 120 */     addAspects(Items.field_151061_bv, (new AspectList()).add(IsorropiaAPI.ENVY, 2));
/* 121 */     addAspects(Items.field_151166_bC, (new AspectList()).add(IsorropiaAPI.ENVY, 10));
/* 122 */     addAspects(Items.field_151045_i, (new AspectList()).add(IsorropiaAPI.ENVY, 5));
/* 123 */     addAspects(Items.field_151141_av, (new AspectList()).add(IsorropiaAPI.LUST, 8));
/* 124 */     addAspects(Items.field_151058_ca, (new AspectList()).add(IsorropiaAPI.LUST, 6));
/* 125 */     addAspects(Items.field_151146_bM, (new AspectList()).add(IsorropiaAPI.LUST, 2));
/* 126 */     addAspects(Items.field_179558_bo, (new AspectList()).add(IsorropiaAPI.FLESH, 2));
/* 127 */     addAspects(Items.field_151147_al, (new AspectList()).add(IsorropiaAPI.FLESH, 2));
/* 128 */     addAspects(Items.field_151082_bd, (new AspectList()).add(IsorropiaAPI.FLESH, 2));
/* 129 */     addAspects(Items.field_151076_bf, (new AspectList()).add(IsorropiaAPI.FLESH, 2));
/* 130 */     addAspects(Items.field_179561_bm, (new AspectList()).add(IsorropiaAPI.FLESH, 2));
/* 131 */     addAspects(Blocks.field_150324_C, (new AspectList()).add(IsorropiaAPI.SLOTH, 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init() {
/* 136 */     ResearchCategories.registerCategory("ISORROPIA", null, null, new ResourceLocation("isorropia", "textures/misc/logo.png"), new ResourceLocation("isorropia", "textures/research/background.jpg"));
/*     */ 
/*     */     
/* 139 */     ThaumcraftApi.registerResearchLocation(new ResourceLocation("isorropia", "research/isorropia.json"));
/* 140 */     Config.CRYSTALS.addAll((Collection)Aspect.aspects.values().stream().map(aspect -> ThaumcraftApiHelper.makeCrystal(aspect))
/* 141 */         .collect(Collectors.toList()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     ThaumcraftApi.addArcaneCraftingRecipe(new ResourceLocation("isorropia", "base_lens"), (IArcaneRecipe)new ShapedArcaneRecipe(new ResourceLocation(""), "ARCANELENSES@1", 20, (new AspectList())
/*     */           
/* 193 */           .add(Aspect.AIR, 1).add(Aspect.EARTH, 1).add(Aspect.WATER, 1)
/* 194 */           .add(Aspect.FIRE, 1).add(Aspect.ORDER, 1).add(Aspect.ENTROPY, 1), new ItemStack(ItemsIS.itemBaseLens), new Object[] { "GSG", "SPS", "GSG", 
/*     */             
/* 196 */             Character.valueOf('G'), Items.field_151043_k, 
/* 197 */             Character.valueOf('S'), ItemsTC.salisMundus, Character.valueOf('P'), Blocks.field_150410_aZ }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "lens_fire"), new InfusionRecipe("FIRELENS", new ItemStack((Item)ItemsIS.itemFireLens), 1, (new AspectList())
/*     */           
/* 204 */           .add(Aspect.LIGHT, 40).add(Aspect.ENERGY, 20).add(Aspect.SENSES, 30), new ItemStack(ItemsIS.itemBaseLens), new Object[] { ItemsTC.amber, 
/*     */             
/* 206 */             ThaumcraftApiHelper.makeCrystal(Aspect.FIRE), ItemsTC.amber, 
/* 207 */             ThaumcraftApiHelper.makeCrystal(Aspect.FIRE) }));
/* 208 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "lens_air"), new InfusionRecipe("AIRLENS", new ItemStack((Item)ItemsIS.itemAirLens), 1, (new AspectList())
/*     */           
/* 210 */           .add(Aspect.AURA, 15).add(Aspect.SENSES, 20), new ItemStack(ItemsIS.itemBaseLens), new Object[] { Items.field_151043_k, 
/*     */             
/* 212 */             ThaumcraftApiHelper.makeCrystal(Aspect.AIR), Items.field_151043_k, 
/* 213 */             ThaumcraftApiHelper.makeCrystal(Aspect.AIR) }));
/* 214 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "lens_ordo"), new InfusionRecipe("ORDOLENS", new ItemStack((Item)ItemsIS.itemOrdoLens), 1, (new AspectList())
/*     */           
/* 216 */           .add(Aspect.MIND, 32).add(Aspect.MAGIC, 32).add(Aspect.SENSES, 20), ItemsIS.itemBaseLens, new Object[] { ItemsTC.scribingTools, 
/* 217 */             ThaumcraftApiHelper.makeCrystal(Aspect.ORDER), Items.field_151122_aG, 
/* 218 */             ThaumcraftApiHelper.makeCrystal(Aspect.ORDER) }));
/* 219 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "lens_envy"), new InfusionRecipe("ENVYLENS", new ItemStack((Item)ItemsIS.itemEnvyLens), 6, (new AspectList())
/*     */           
/* 221 */           .add(Aspect.DESIRE, 32).add(IsorropiaAPI.HUNGER, 32).add(IsorropiaAPI.LUST, 32)
/* 222 */           .add(IsorropiaAPI.ENVY, 64), ItemsIS.itemBaseLens, new Object[] { Items.field_151045_i, 
/* 223 */             ThaumcraftApiHelper.makeCrystal(IsorropiaAPI.ENVY), Items.field_151121_aF, 
/* 224 */             ThaumcraftApiHelper.makeCrystal(IsorropiaAPI.ENVY) }));
/*     */     
/* 226 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "somatic_brain"), new InfusionRecipe("SOMATICBRAIN", new ItemStack((Item)ItemsIS.itemSomaticBrain), 4, (new AspectList())
/*     */           
/* 228 */           .add(Aspect.MIND, 150).add(Aspect.DESIRE, 100).add(IsorropiaAPI.ENVY, 20), BlocksTC.jarBrain, new Object[] { new ItemStack(ItemsTC.plate), new ItemStack(ItemsTC.mind, 1, 1), Blocks.field_150438_bZ, new ItemStack(ItemsTC.mind, 1, 1) }));
/*     */ 
/*     */ 
/*     */     
/* 232 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "modified_matrix"), new InfusionRecipe("CREATUREINFUSIONS@1", new ItemStack((Block)BlocksIS.blockModifiedMatrix), 8, (new AspectList())
/*     */           
/* 234 */           .add(Aspect.LIFE, 500).add(Aspect.CRAFT, 500).add(Aspect.MAGIC, 500)
/* 235 */           .add(Aspect.BEAST, 500), BlocksTC.infusionMatrix, new Object[] { ItemsTC.salisMundus, ItemsTC.visResonator, ItemsTC.salisMundus, ItemsTC.visResonator }));
/*     */ 
/*     */ 
/*     */     
/* 239 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "skulltaker"), new InfusionRecipe("SKULLTAKER", new ItemStack(ItemsIS.itemSkullAxe), 4, (new AspectList())
/*     */           
/* 241 */           .add(IsorropiaAPI.WRATH, 100).add(Aspect.TOOL, 100)
/* 242 */           .add(Aspect.DESIRE, 100).add(IsorropiaAPI.ENVY, 25), new ItemStack(ItemsTC.thaumiumAxe), new Object[] { new ItemStack(Items.field_151144_bL, 1, 1), 
/*     */             
/* 244 */             ThaumcraftApiHelper.makeCrystal(IsorropiaAPI.WRATH), 
/* 245 */             ThaumcraftApiHelper.makeCrystal(IsorropiaAPI.WRATH), Items.field_151045_i }));
/* 246 */     ThaumcraftApi.addInfusionCraftingRecipe(new ResourceLocation("isorropia", "arcane_cake"), new InfusionRecipe("ARCANECAKE", new ItemStack((Block)BlocksIS.blockArcaneCake), 1, (new AspectList())
/*     */ 
/*     */           
/* 249 */           .add(IsorropiaAPI.GLUTTONY, 24).add(IsorropiaAPI.HUNGER, 50).add(Aspect.CRAFT, 50), Items.field_151105_aU, new Object[] { ItemsTC.salisMundus, Items.field_151110_aK, Items.field_151117_aB, Items.field_151110_aK, 
/*     */ 
/*     */             
/* 252 */             ThaumcraftApiHelper.makeCrystal(IsorropiaAPI.GLUTTONY), 
/* 253 */             ThaumcraftApiHelper.makeCrystal(IsorropiaAPI.GLUTTONY) }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "enderheart"), (new OrganCurativeInfusionRecipe.Builder())
/*     */         
/* 265 */         .withOrganTarget(OrganCurativeInfusionRecipe.Organ.HEART)
/* 266 */         .build());
/* 267 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "shockskin"), (new OrganCurativeInfusionRecipe.Builder())
/*     */         
/* 269 */         .withOrganTarget(OrganCurativeInfusionRecipe.Organ.SKIN)
/* 270 */         .build());
/* 271 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "awakened_blood"), ((OrganCurativeInfusionRecipe.Builder)((OrganCurativeInfusionRecipe.Builder)((OrganCurativeInfusionRecipe.Builder)(new OrganCurativeInfusionRecipe.Builder())
/*     */         
/* 273 */         .withOrganTarget(OrganCurativeInfusionRecipe.Organ.BLOOD)
/* 274 */         .withAspects((new AspectList()).add(IsorropiaAPI.HUNGER, 64).add(Aspect.PLANT, 16)
/* 275 */           .add(Aspect.LIFE, 16).add(Aspect.FLUX, 12)))
/* 276 */         .withComponents(new Ingredient[] { Ingredient.func_193367_a(ItemsTC.bottleTaint), 
/* 277 */             Ingredient.func_193367_a(Item.func_150898_a(BlocksTC.logSilverwood)), 
/* 278 */             Ingredient.func_193367_a(Item.func_150898_a(BlocksTC.jarVoid)), 
/* 279 */             Ingredient.func_193367_a(Item.func_150898_a(BlocksTC.logSilverwood))
/* 280 */           })).withFakeIngredients(Ingredient.func_193369_a(new ItemStack[] { ItemCat.createCat(ItemCat.EnumCat.PIG, "Creature")
/* 281 */             }), ItemCat.createCat(ItemCat.EnumCat.AWAKENED_BLOOD, "Awakened Blood")))
/*     */         
/* 283 */         .build());
/* 284 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "diamond_skin"), ((OrganCurativeInfusionRecipe.Builder)((OrganCurativeInfusionRecipe.Builder)(new OrganCurativeInfusionRecipe.Builder())
/*     */         
/* 286 */         .withOrganTarget(OrganCurativeInfusionRecipe.Organ.SKIN)
/* 287 */         .withModifier("generic.armor", new AttributeModifier(UUID.fromString("6bc2ebe8-2b1c-11eb-adc1-0242ac120002"), "DIAMOND_SKIN", 20.0D, 0)))
/* 288 */         .withModifier("generic.armorToughness", new AttributeModifier(UUID.fromString("21afc412-2b1d-11eb-adc1-0242ac120002"), "DIAMOND_SKIN_TOUGHNESS", 8.0D, 0)))
/* 289 */         .build());
/* 290 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "quicksilver_limbs"), ((OrganCurativeInfusionRecipe.Builder)((OrganCurativeInfusionRecipe.Builder)(new OrganCurativeInfusionRecipe.Builder())
/*     */         
/* 292 */         .withOrganTarget(OrganCurativeInfusionRecipe.Organ.MUSCLE)
/*     */         
/* 294 */         .withModifier("generic.movementSpeed", new AttributeModifier(UUID.fromString("b3f15142-2b27-11eb-adc1-0242ac120002"), "QUICKSILVER_SPEED", 0.08D, 0)))
/* 295 */         .withModifier("forge.swimSpeed", new AttributeModifier(UUID.fromString("c1719976-2b27-11eb-adc1-0242ac120002"), "QUICKSILVER_SWIM_SPEED", 0.2D, 0)))
/* 296 */         .build());
/*     */     
/* 298 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "jelly_rabbit"), (CurativeInfusionRecipe)new JellyRabbitRecipe());
/*     */     
/* 300 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "ore_boar"), (CurativeInfusionRecipe)new OreBoarRecipe());
/*     */     
/* 302 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "taintfeeder"), ((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)(new SpecieCurativeInfusionRecipe.Builder())
/*     */         
/* 304 */         .withAspects((new AspectList()).add(IsorropiaAPI.HUNGER, 64).add(Aspect.PLANT, 16)
/* 305 */           .add(Aspect.LIFE, 16).add(Aspect.FLUX, 12)))
/* 306 */         .withComponents(new Ingredient[] { Ingredient.func_193367_a(ItemsTC.bottleTaint), 
/* 307 */             Ingredient.func_193367_a(Item.func_150898_a(BlocksTC.logSilverwood)), 
/* 308 */             Ingredient.func_193367_a(Item.func_150898_a(BlocksTC.jarVoid)), 
/* 309 */             Ingredient.func_193367_a(Item.func_150898_a(BlocksTC.logSilverwood))
/* 310 */           })).withInstability(4)).withKnowledgeRequirement("TAINTFEEDER")).withResult(EntityTaintPig.class)
/* 311 */         .withPredicate(entity -> (entity.getClass() == EntityPig.class)))
/* 312 */         .withFakeIngredients(Ingredient.func_193369_a(new ItemStack[] { ItemCat.createCat(ItemCat.EnumCat.PIG, "Pig")
/* 313 */             }), ItemCat.createCat(ItemCat.EnumCat.PIG, "Taintfeeder")))
/* 314 */         .build());
/* 315 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "selfshearing"), (new CurativeInfusionRecipe.Builder())
/*     */         
/* 317 */         .withAspects((new AspectList()).add(Aspect.TOOL, 16).add(Aspect.MECHANISM, 8))
/* 318 */         .withComponents(new Ingredient[] { Ingredient.func_193367_a((Item)Items.field_151097_aZ), Ingredient.func_193367_a(Items.field_151132_bS)
/* 319 */           }).withInstability(2).withKnowledgeRequirement("SELFSHEARING")
/* 320 */         .withPredicate(entity -> entity instanceof net.minecraftforge.common.IShearable)
/* 321 */         .withFakeIngredients(
/* 322 */           Ingredient.func_193369_a(new ItemStack[] { ItemCat.createCat(ItemCat.EnumCat.SHEEP, "Shearable Mob")
/* 323 */             }), ItemCat.createCat(ItemCat.EnumCat.SELFSHEARING, "Self Shearing Mob"))
/* 324 */         .withInformationNBT(new NBTTagCompound())
/* 325 */         .build());
/* 326 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "scholarschicken"), ((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)(new SpecieCurativeInfusionRecipe.Builder())
/*     */         
/* 328 */         .withAspects((new AspectList()).add(Aspect.SENSES, 16).add(Aspect.EXCHANGE, 8)
/* 329 */           .add(Aspect.DARKNESS, 16)))
/* 330 */         .withComponents(new Ingredient[] { Ingredient.func_193369_a(new ItemStack[] { new ItemStack(Items.field_151100_aR, 1, 0)
/* 331 */               }), Ingredient.func_193367_a((Item)Items.field_151097_aZ)
/* 332 */           })).withInstability(2)).withResult(EntityScholarChicken.class)
/* 333 */         .withKnowledgeRequirement("SCHOLARSCHICKEN"))
/* 334 */         .withPredicate(entity -> (entity.getClass() == EntityChicken.class)))
/* 335 */         .withFakeIngredients(
/* 336 */           Ingredient.func_193369_a(new ItemStack[] { ItemCat.createCat(ItemCat.EnumCat.CHICKEN, "Chicken")
/* 337 */             }), ItemCat.createCat(ItemCat.EnumCat.CHICKEN, "Scholar's Chicken")))
/* 338 */         .build());
/* 339 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "chromaticsheep"), ((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)(new SpecieCurativeInfusionRecipe.Builder())
/*     */         
/* 341 */         .withAspects((new AspectList()).add(Aspect.SENSES, 16).add(Aspect.EXCHANGE, 8)
/* 342 */           .add(Aspect.DARKNESS, 16)))
/* 343 */         .withComponents(new Ingredient[] { Ingredient.func_193369_a(new ItemStack[] { new ItemStack(Items.field_151100_aR, 1, 1)
/* 344 */               }), Ingredient.func_193369_a(new ItemStack[] { new ItemStack(Items.field_151100_aR, 1, 2)
/* 345 */               }), Ingredient.func_193369_a(new ItemStack[] { new ItemStack(Items.field_151100_aR, 1, 4)
/* 346 */               }) })).withInstability(2)).withResult(EntityChromaticSheep.class)
/* 347 */         .withKnowledgeRequirement("CHROMATICSHEEP"))
/* 348 */         .withPredicate(entity -> (entity.getClass() == EntitySheep.class)))
/* 349 */         .withFakeIngredients(Ingredient.func_193369_a(new ItemStack[] { ItemCat.createCat(ItemCat.EnumCat.SHEEP, "Sheep")
/* 350 */             }), ItemCat.createCat(ItemCat.EnumCat.SHEEP, "Chromatic Sheep")))
/* 351 */         .build());
/* 352 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "gravekeeper"), ((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)((SpecieCurativeInfusionRecipe.Builder)(new SpecieCurativeInfusionRecipe.Builder())
/*     */         
/* 354 */         .withAspects((new AspectList())
/* 355 */           .add(Aspect.LIGHT, 64).add(Aspect.UNDEAD, 16).add(Aspect.ORDER, 32)))
/* 356 */         .withComponents(new Ingredient[] { Ingredient.func_193367_a(Items.field_151103_aS), 
/* 357 */             Ingredient.func_193367_a(Item.func_150898_a(Blocks.field_150340_R)), 
/* 358 */             Ingredient.func_193367_a(ItemsTC.amber), 
/* 359 */             Ingredient.func_193367_a(Item.func_150898_a(BlocksTC.logSilverwood))
/* 360 */           })).withInstability(6)).withResult(EntityGravekeeper.class)
/* 361 */         .withKnowledgeRequirement("GRAVEKEEPERINFUSION")).withCelestialAura(CelestialBody.SUN, 50))
/* 362 */         .withPredicate(entity -> (entity.getClass() == EntityOcelot.class)))
/* 363 */         .withFakeIngredients(Ingredient.func_193369_a(new ItemStack[] { ItemCat.createCat(ItemCat.EnumCat.OCELOT, "Feline")
/* 364 */             }), ItemCat.createCat(ItemCat.EnumCat.OCELOT, "Gravekeeper")))
/* 365 */         .build());
/*     */     
/* 367 */     Ingredient food = Ingredient.func_193368_a(new Item[] { Items.field_151172_bF, Items.field_151174_bG, Items.field_185164_cV, Items.field_151015_O, Items.field_151034_e, Items.field_151103_aS, Items.field_185163_cU, Items.field_151081_bc, Items.field_151080_bb, Items.field_151014_N });
/*     */     
/* 369 */     IsorropiaAPI.registerCreatureInfusionRecipe(new ResourceLocation("isorropia", "instilledfidelity"), (new CurativeInfusionRecipe.Builder())
/*     */         
/* 371 */         .withAspects((new AspectList()).add(Aspect.BEAST, 16).add(Aspect.MIND, 16))
/* 372 */         .withComponents(new Ingredient[] { food, food, food }).withInstability(2)
/* 373 */         .withKnowledgeRequirement("INSTILLEDFIDELITY")
/* 374 */         .withPredicate(entity -> entity instanceof net.minecraft.entity.passive.EntityTameable)
/* 375 */         .withFakeIngredients(
/* 376 */           Ingredient.func_193369_a(new ItemStack[] { ItemCat.createCat(ItemCat.EnumCat.WOLF, "Tameable Mob")
/* 377 */             }), ItemCat.createCat(ItemCat.EnumCat.LOVE, "Tamed Mob"))
/* 378 */         .build());
/*     */     
/* 380 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.animal", EntityAnimal.class, true, "CREATUREINFUSIONS@1", "research.scan.animal.text"));
/*     */     
/* 382 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.taint", ITaintedMob.class, true, "CURATIVEVAT@1", "research.scan.taint.text"));
/*     */     
/* 384 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.chicken", EntityChicken.class, false, "SIMILITUDOINFUSIONS@1", "research.scan.chicken.text"));
/*     */     
/* 386 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.cow", EntityCow.class, false, "SIMILITUDOINFUSIONS@1", "research.scan.cow.text"));
/*     */     
/* 388 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.pig", EntityPig.class, false, "SIMILITUDOINFUSIONS@1", "research.scan.pig.text"));
/*     */     
/* 390 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.pigman", EntityPigZombie.class, false, "SIMILITUDOINFUSIONS@2", "research.scan.pigman.text"));
/*     */     
/* 392 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.enderman", EntityEnderman.class, false, "SIMILITUDOINFUSIONS@3", "research.scan.enderman.text"));
/*     */     
/* 394 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.golem", EntityIronGolem.class, false, "SIMILITUDOINFUSIONS@3", "research.scan.golem.text"));
/*     */     
/* 396 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.villager", EntityVillager.class, false, "SELFSHEARING@3", "research.scan.villager.text"));
/*     */     
/* 398 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.sheep", EntitySheep.class, false, "SIMILITUDOINFUSIONS@3", "research.scan.sheep.text"));
/*     */     
/* 400 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.slime", EntitySlime.class, false, "JELLYRABBIT@0", "research.scan.slime.text"));
/*     */     
/* 402 */     ScanningManager.addScannableThing((IScanThing)new ScanEntityResearch("!scan.rabbit", EntityRabbit.class, false, "JELLYRABBIT@0", "research.scan.rabbit.text"));
/*     */     
/* 404 */     ScanningManager.addScannableThing(new ScanFidelity());
/* 405 */     ScanningManager.addScannableThing(new ScanTameable());
/* 406 */     ScanningManager.addScannableThing(new ScanSkull());
/* 407 */     ScanningManager.addScannableThing((IScanThing)new ScanEntity("!scan.corrupted", EntityLiving.class, true)
/*     */         {
/*     */           public boolean checkThing(EntityPlayer player, Object obj) {
/* 410 */             return (super.checkThing(player, obj) && obj instanceof EntityLiving && ((EntityLiving)obj)
/* 411 */               .func_110148_a(ThaumcraftApiHelper.CHAMPION_MOD) != null && ((EntityLiving)obj)
/* 412 */               .func_110148_a(ThaumcraftApiHelper.CHAMPION_MOD)
/* 413 */               .func_111126_e() == 13.0D);
/*     */           }
/*     */ 
/*     */           
/*     */           public void onSuccess(EntityPlayer player, Object object) {
/* 418 */             super.onSuccess(player, object);
/* 419 */             player.func_145747_a((ITextComponent)new TextComponentString(TextFormatting.DARK_PURPLE + (new TextComponentTranslation("research.scan.corrupted.text", new Object[0]))
/* 420 */                   .func_150254_d()));
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 443 */     ScanningManager.addScannableThing(new ScanSun());
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\research\ResearchsIS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */