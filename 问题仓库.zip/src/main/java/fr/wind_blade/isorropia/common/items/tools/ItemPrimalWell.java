 package fr.wind_blade.isorropia.common.items.tools;
 
 import net.minecraft.item.EnumRarity;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import thaumcraft.api.items.IScribeTools;
 
 public class ItemPrimalWell
   extends Item implements IScribeTools {
   public ItemPrimalWell() {
/* 11 */     func_77625_d(1);
/* 12 */     func_77656_e(200);
   }
 
   
   public EnumRarity func_77613_e(ItemStack stack) {
/* 17 */     return EnumRarity.EPIC;
   }
 
   
   public void setDamage(ItemStack stack, int damage) {
/* 22 */     super.setDamage(stack, 0);
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\tools\ItemPrimalWell.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */