/*     */ package fr.wind_blade.isorropia.common.events;
/*     */ 
/*     */ import baubles.api.BaublesApi;
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.blocks.material.MaterialIR;
/*     */ import fr.wind_blade.isorropia.common.capabilities.LivingBaseCapability;
/*     */ import fr.wind_blade.isorropia.common.capabilities.LivingCapability;
/*     */ import fr.wind_blade.isorropia.common.config.Config;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityHangingLabel;
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import fr.wind_blade.isorropia.common.items.tools.ItemSkullAxe;
/*     */ import fr.wind_blade.isorropia.common.lenses.Lens;
/*     */ import fr.wind_blade.isorropia.common.lenses.LensManager;
/*     */ import fr.wind_blade.isorropia.common.network.LensRemoveMessage;
/*     */ import fr.wind_blade.isorropia.common.research.recipes.OrganCurativeInfusionRecipe;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.monster.EntityZombieVillager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*     */ import net.minecraftforge.event.AttachCapabilitiesEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingAttackEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDamageEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDropsEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerDestroyItemEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.fml.client.event.ConfigChangedEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.aspects.IEssentiaContainerItem;
/*     */ import thaumcraft.api.capabilities.IPlayerKnowledge;
/*     */ import thaumcraft.api.capabilities.ThaumcraftCapabilities;
/*     */ import thaumcraft.api.items.IRevealer;
/*     */ import thaumcraft.api.items.ItemsTC;
/*     */ import thaumcraft.api.research.ResearchEvent;
/*     */ import thaumcraft.client.fx.FXDispatcher;
/*     */ import thaumcraft.common.items.tools.ItemThaumometer;
/*     */ import thaumcraft.common.lib.research.ResearchManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityEventHandler
/*     */ {
/*  78 */   private static final ItemStack SHEARS = new ItemStack((Item)Items.field_151097_aZ);
/*     */   private Lens theRightLens;
/*  80 */   private static Random randy = new Random();
/*     */   private Lens theLeftLens;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerTick(TickEvent.PlayerTickEvent event) {
/*  85 */     if (event.phase == TickEvent.Phase.START) {
/*  86 */       World world = event.player.field_70170_p;
/*  87 */       ItemStack revealer = LensManager.getRevealer(event.player);
/*     */       
/*  89 */       if (!revealer.func_190926_b() && revealer.func_77942_o() && revealer
/*  90 */         .func_77978_p().func_74779_i("LeftLens") != null) {
/*  91 */         this.theLeftLens = LensManager.getLens(revealer, LensManager.LENSSLOT.LEFT);
/*  92 */         this.theRightLens = LensManager.getLens(revealer, LensManager.LENSSLOT.RIGHT);
/*  93 */         boolean doubleLens = (this.theRightLens != null && this.theRightLens.equals(this.theLeftLens));
/*     */ 
/*     */         
/*  96 */         if (this.theLeftLens != null) {
/*  97 */           this.theLeftLens.handleTicks(world, event.player, doubleLens);
/*     */         }
/*  99 */         if (!doubleLens && this.theRightLens != null) {
/* 100 */           this.theRightLens.handleTicks(world, event.player, false);
/*     */         }
/*     */       } 
/* 103 */       ItemSkullAxe.update(event.player);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onAttachCapability(AttachCapabilitiesEvent<Entity> event) {
/* 109 */     Entity entity = (Entity)event.getObject();
/* 110 */     if (entity instanceof EntityLiving) {
/* 111 */       event.addCapability(new ResourceLocation("isorropia", "LIVING_CAPABILITY"), (ICapabilityProvider)new LivingCapability((EntityLiving)event
/* 112 */             .getObject()));
/* 113 */     } else if (entity instanceof EntityLivingBase) {
/* 114 */       event.addCapability(new ResourceLocation("isorropia", "LIVING_BASE_CAPABILITY"), (ICapabilityProvider)new LivingBaseCapability((EntityLivingBase)event
/* 115 */             .getObject()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRevealerRemoved(LivingEquipmentChangeEvent event) {
/* 124 */     ItemStack stack = event.getFrom();
/*     */     
/* 126 */     if (!(event.getEntityLiving() instanceof EntityPlayer))
/*     */       return; 
/* 128 */     if (stack.func_77973_b() instanceof IRevealer && ((IRevealer)stack
/* 129 */       .func_77973_b()).showNodes(stack, event.getEntityLiving())) {
/* 130 */       Lens lens = LensManager.getLens(stack, LensManager.LENSSLOT.LEFT);
/* 131 */       Lens lens2 = LensManager.getLens(stack, LensManager.LENSSLOT.RIGHT);
/*     */       
/* 133 */       if (lens != null)
/* 134 */         lens.handleRemoval((event.getEntityLiving()).field_70170_p, (EntityPlayer)event.getEntityLiving()); 
/* 135 */       if (lens2 != null)
/* 136 */         lens2.handleRemoval((event.getEntityLiving()).field_70170_p, (EntityPlayer)event.getEntityLiving()); 
/* 137 */       Common.INSTANCE.sendTo((IMessage)new LensRemoveMessage(lens, lens2), (EntityPlayerMP)event.getEntityLiving());
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRevealerDestroy(PlayerDestroyItemEvent event) {
/* 143 */     ItemStack stack = event.getOriginal();
/* 144 */     EntityPlayer player = event.getEntityPlayer();
/*     */     
/* 146 */     if (stack.func_77973_b() instanceof IRevealer && ((IRevealer)stack
/* 147 */       .func_77973_b()).showNodes(stack, event.getEntityLiving())) {
/* 148 */       Lens lens = LensManager.getLens(stack, LensManager.LENSSLOT.LEFT);
/* 149 */       Lens lens2 = LensManager.getLens(stack, LensManager.LENSSLOT.RIGHT);
/*     */       
/* 151 */       if (lens != null && 
/* 152 */         !player.field_71071_by.func_70441_a(new ItemStack((Item)lens.getItemLens())))
/* 153 */         player.func_71019_a(new ItemStack((Item)lens.getItemLens()), false); 
/* 154 */       if (lens2 != null && 
/* 155 */         !player.field_71071_by.func_70441_a(new ItemStack((Item)lens.getItemLens()))) {
/* 156 */         player.func_71019_a(new ItemStack((Item)lens.getItemLens()), false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingDeath(LivingDeathEvent event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingUpdateEvent(LivingEvent.LivingUpdateEvent event) {
/* 183 */     EntityLivingBase entity = event.getEntityLiving();
/* 184 */     LivingBaseCapability cap = Common.getCap(entity);
/*     */     
/* 186 */     cap.update();
/* 187 */     if (entity.func_70055_a(MaterialIR.LIQUID_VAT)) {
/* 188 */       entity.func_70050_g(300);
/*     */     }
/* 190 */     if (!entity.field_70170_p.field_72995_K) {
/* 191 */       if (entity instanceof IShearable) {
/* 192 */         IShearable shear = (IShearable)entity;
/*     */         
/* 194 */         if (entity.field_70173_aa % 100 == 0 && cap.infusions.containsKey(new ResourceLocation("isorropia:selfshearing")) && shear.isShearable(SHEARS, (IBlockAccess)entity.field_70170_p, entity.func_180425_c())) {
/* 195 */           ArrayList<ItemStack> drops = (ArrayList<ItemStack>)shear.onSheared(SHEARS, (IBlockAccess)entity.field_70170_p, entity
/* 196 */               .func_180425_c(), 0);
/* 197 */           Random rand = new Random();
/* 198 */           for (ItemStack stack : drops) {
/*     */             
/* 200 */             EntityItem entityDropItem = entity.func_70099_a(stack, 1.0F), ent = entityDropItem;
/* 201 */             entityDropItem.field_70181_x += (rand.nextFloat() * 0.05F);
/* 202 */             EntityItem entityItem = ent;
/* 203 */             entityItem.field_70159_w += ((rand.nextFloat() - rand.nextFloat()) * 0.1F);
/* 204 */             EntityItem entityItem2 = ent;
/* 205 */             entityItem2.field_70179_y += ((rand.nextFloat() - rand.nextFloat()) * 0.1F);
/*     */           } 
/*     */         } 
/*     */       } 
/* 209 */       if (entity.field_70173_aa % 50 == 0 && cap.entityHasOrgan(OrganCurativeInfusionRecipe.Organ.BLOOD, "isorropia:awakened_blood") && 
/* 210 */         entity.func_110143_aJ() < entity.func_110138_aP())
/* 211 */         entity.func_70691_i(1.0F); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onStartTrack(PlayerEvent.StartTracking event) {
/* 217 */     if (event.getTarget() instanceof EntityLivingBase) {
/* 218 */       Common.getCap((EntityLivingBase)event.getTarget())
/* 219 */         .synchStartTracking((EntityPlayerMP)event.getEntityPlayer());
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
/* 225 */     Common.getCap((EntityLivingBase)event.player).synchStartTracking((EntityPlayerMP)event.player);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingDrops(LivingDropsEvent event) {
/* 230 */     if (event.getSource() != null && event.getSource().func_76346_g() != null && event
/* 231 */       .getSource().func_76346_g() instanceof EntityPlayer) {
/* 232 */       EntityPlayer player = (EntityPlayer)event.getSource().func_76346_g();
/* 233 */       ItemStack stack = player.func_184586_b(player.func_184600_cs());
/* 234 */       if (stack.func_77973_b() == ItemsIS.itemSkullAxe) {
/* 235 */         int headId = ItemSkullAxe.getHeadId(event.getEntityLiving().getClass());
/* 236 */         if (headId != -1) {
/* 237 */           int t1 = randy.nextInt(1);
/* 238 */           int t2 = 3 + EnchantmentHelper.func_77506_a(Enchantment.func_185262_c(21), stack);
/* 239 */           if (t1 <= t2) {
/* 240 */             ItemStack head = new ItemStack(Items.field_151144_bL, 1, headId);
/* 241 */             if (headId == 3) {
/* 242 */               NBTTagCompound nametag = new NBTTagCompound();
/* 243 */               nametag.func_74778_a("SkullOwner", ((EntityPlayer)event
/* 244 */                   .getEntityLiving()).func_174793_f().func_70005_c_());
/* 245 */               head.func_77982_d(nametag);
/*     */             } 
/* 247 */             addDrop(event, head);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerBlockInterract(PlayerInteractEvent.RightClickBlock event) {
/* 256 */     ItemStack stack = event.getEntityPlayer().func_184586_b(event.getHand());
/* 257 */     World world = event.getWorld();
/* 258 */     if (!world.field_72995_K && stack.func_77973_b() == ItemsTC.label && 
/* 259 */       ThaumcraftCapabilities.getKnowledge(event.getEntityPlayer()).isResearchKnown("HANGINGLABEL") && 
/* 260 */       !(world.func_180495_p(event.getPos()).func_177230_c() instanceof thaumcraft.api.blocks.ILabelable) && event
/* 261 */       .getFace() != EnumFacing.DOWN && event.getFace() != EnumFacing.UP && event.getEntityPlayer()
/* 262 */       .func_175151_a(event.getPos().func_177972_a(event.getFace()), event.getFace(), stack)) {
/* 263 */       AspectList aspects = ((IEssentiaContainerItem)stack.func_77973_b()).getAspects(stack);
/*     */ 
/*     */       
/* 266 */       EntityHangingLabel entityMessage = new EntityHangingLabel(world, true, event.getPos().func_177972_a(event.getFace()), event.getFace(), (aspects != null) ? aspects.getAspects()[0] : null);
/*     */       
/* 268 */       if (entityMessage.func_70518_d()) {
/* 269 */         entityMessage.func_184523_o();
/* 270 */         world.func_72838_d((Entity)entityMessage);
/* 271 */         stack.func_190918_g(1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
/* 278 */     ItemStack stack = event.getItemStack();
/*     */     
/* 280 */     if (event.getEntityPlayer() != null && event.getTarget() instanceof EntityZombieVillager) {
/* 281 */       EntityZombieVillager entity = (EntityZombieVillager)event.getTarget();
/*     */       
/* 283 */       if (stack.func_77973_b() == Items.field_151153_ao && stack.func_77960_j() == 0 && entity
/* 284 */         .func_70644_a(MobEffects.field_76437_t) && !entity.func_82230_o()) {
/* 285 */         IPlayerKnowledge knowledge = ThaumcraftCapabilities.getKnowledge(event.getEntityPlayer());
/* 286 */         if (!knowledge.isResearchKnown("!experiment.villager_zombie")) {
/* 287 */           knowledge.addResearch("!experiment.villager_zombie");
/* 288 */           knowledge.sync((EntityPlayerMP)event.getEntity());
/* 289 */           ((EntityPlayer)event.getEntity()).func_146105_b((ITextComponent)new TextComponentString(TextFormatting.DARK_PURPLE + 
/*     */                 
/* 291 */                 I18n.func_135052_a("research.experiment.villager_zombie.text", new Object[0])), false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onItemRightClick(PlayerInteractEvent.RightClickItem event) {
/* 301 */     ItemStack stack = event.getItemStack();
/*     */     
/* 303 */     if (!(event.getWorld()).field_72995_K && (stack.func_77973_b() instanceof IRevealer || stack.func_77973_b() instanceof thaumcraft.api.items.IGoggles) && stack
/* 304 */       .func_77942_o()) {
/* 305 */       String lens = stack.func_77978_p().func_74779_i(LensManager.LENSSLOT.LEFT.getName());
/*     */       
/* 307 */       if (!lens.equals("isorropia:ordo_lens")) {
/* 308 */         lens = stack.func_77978_p().func_74779_i(LensManager.LENSSLOT.RIGHT.getName());
/*     */       }
/*     */       
/* 311 */       if (lens.equals("isorropia:ordo_lens")) {
/* 312 */         ((ItemThaumometer)ItemsTC.thaumometer).doScan(event.getWorld(), event.getEntityPlayer());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onAttack(LivingAttackEvent event) {
/* 319 */     EntityLivingBase base = event.getEntityLiving();
/* 320 */     DamageSource source = event.getSource();
/* 321 */     LivingBaseCapability cap = Common.getCap(base);
/*     */     
/* 323 */     if (cap.entityHasOrgan(OrganCurativeInfusionRecipe.Organ.HEART, "isorropia:enderheart") && !base.func_180431_b(source) && source instanceof net.minecraft.util.EntityDamageSourceIndirect) {
/* 324 */       base.field_70170_p.func_184148_a((EntityPlayer)null, base.field_70169_q, base.field_70167_r, base.field_70166_s, SoundEvents.field_187534_aX, base.func_184176_by(), 1.0F, 1.0F);
/* 325 */       base.func_184185_a(SoundEvents.field_187534_aX, 1.0F, 1.0F);
/* 326 */       base.func_184595_k(base.field_70165_t, base.field_70163_u, base.field_70161_v);
/* 327 */       base.func_70690_d(new PotionEffect(MobEffects.field_76441_p, 3));
/* 328 */       event.setCanceled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onAttack(LivingDamageEvent event) {
/* 334 */     EntityLivingBase base = event.getEntityLiving();
/* 335 */     LivingBaseCapability cap = Common.getCap(base);
/* 336 */     Entity target = event.getSource().func_76346_g();
/*     */     
/* 338 */     if (target instanceof EntityLivingBase && cap.entityHasOrgan(OrganCurativeInfusionRecipe.Organ.SKIN, "isorropia:shockskin")) {
/* 339 */       FXDispatcher.INSTANCE.arcLightning(base.field_70165_t, base.field_70163_u, base.field_70161_v, target.field_70165_t, target.field_70163_u, target.field_70161_v, 0.2F, 0.8F, 0.8F, 1.0F);
/* 340 */       target.func_70097_a(DamageSource.field_180137_b, 4.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerResearch(ResearchEvent.Research event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hardCodedAntiRecursive = false;
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerGetKnowledge(ResearchEvent.Knowledge event) {
/* 356 */     ItemStack stack = event.getPlayer().func_184582_a(EntityEquipmentSlot.HEAD);
/*     */     
/* 358 */     if (stack.func_77973_b() != ItemsIS.itemSomaticBrain) {
/* 359 */       stack = BaublesApi.getBaublesHandler(event.getPlayer()).getStackInSlot(4);
/*     */     }
/*     */     
/* 362 */     if (stack.func_77973_b() == ItemsIS.itemSomaticBrain && !this.hardCodedAntiRecursive) {
/* 363 */       this.hardCodedAntiRecursive = true;
/* 364 */       ResearchManager.addKnowledge(event.getPlayer(), event.getType(), event.getCategory(), 
/* 365 */           (int)Math.round(event.getAmount() * ((event.getType() == IPlayerKnowledge.EnumKnowledgeType.THEORY) ? 0.3D : 0.6D)));
/* 366 */       this.hardCodedAntiRecursive = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onExperienceDrop(LivingExperienceDropEvent event) {
/* 372 */     EntityPlayer player = event.getAttackingPlayer();
/*     */     
/* 374 */     if (player != null) {
/* 375 */       ItemStack stack = player.func_184582_a(EntityEquipmentSlot.HEAD);
/*     */       
/* 377 */       if (stack.func_77973_b() != ItemsIS.itemSomaticBrain) {
/* 378 */         stack = BaublesApi.getBaublesHandler(player).getStackInSlot(4);
/*     */       }
/* 380 */       if (stack.func_77973_b() == ItemsIS.itemSomaticBrain) {
/* 381 */         event.setDroppedExperience(event.getDroppedExperience() * 2);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addDrop(LivingDropsEvent event, ItemStack drop) {
/* 387 */     EntityItem entityitem = new EntityItem((event.getEntityLiving()).field_70170_p, (event.getEntityLiving()).field_70165_t, (event.getEntityLiving()).field_70163_u, (event.getEntityLiving()).field_70161_v, drop);
/* 388 */     entityitem.func_174867_a(10);
/* 389 */     event.getDrops().add(entityitem);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent eventArgs) {
/* 394 */     if (eventArgs.getModID().equals("Thaumic Isorropia")) {
/* 395 */       Config.syncConfigurable();
/* 396 */       if (Config.config != null && Config.config.hasChanged())
/* 397 */         Config.save(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\events\EntityEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */