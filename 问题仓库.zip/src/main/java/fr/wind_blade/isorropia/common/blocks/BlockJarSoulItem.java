 package fr.wind_blade.isorropia.common.blocks;
 
 import net.minecraft.block.Block;
 import net.minecraft.entity.EntityList;
 import net.minecraft.item.ItemBlock;
 import net.minecraft.item.ItemStack;
 import net.minecraft.util.ResourceLocation;
 import net.minecraft.util.text.TextComponentTranslation;
 
 public class BlockJarSoulItem
   extends ItemBlock implements IItemStackRenderProvider {
   public BlockJarSoulItem() {
/* 13 */     super((Block)BlocksIS.blockJarSoul);
   }
 
   
   public String func_77653_i(ItemStack stack) {
     String stringy;
/* 19 */     if (stack.func_77942_o() && stack.func_77978_p().func_74764_b("ENTITY_DATA")) {
 
 
       
/* 23 */       stringy = (new TextComponentTranslation("item.jarredSoul.jarred", new Object[] { EntityList.func_191302_a(new ResourceLocation(stack.func_77978_p().func_74775_l("ENTITY_DATA").func_74779_i("id"))) })).func_150254_d();
     } else {
/* 25 */       stringy = (new TextComponentTranslation("item.jarredSoul.0.name", new Object[0])).func_150254_d();
     } 
/* 27 */     return stringy;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockJarSoulItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */