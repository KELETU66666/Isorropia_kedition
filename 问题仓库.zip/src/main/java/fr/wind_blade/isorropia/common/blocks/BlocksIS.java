 package fr.wind_blade.isorropia.common.blocks;
 
 import fr.wind_blade.isorropia.common.Common;
 import java.util.ArrayList;
 import java.util.List;
 import net.minecraft.block.Block;
 import net.minecraft.block.material.Material;
 import net.minecraft.util.ResourceLocation;
 
 
 
 public class BlocksIS
 {
/* 14 */   public static List<Block> blocks = new ArrayList<>();
   
   public static BlockCurativeVat blockCurativeVat;
   
   public static BlockLiquidVat blockVatInterior;
   public static BlockModifiedMatrix blockModifiedMatrix;
   public static BlockStatue blockStatue;
   public static BlockJarSoul blockJarSoul;
   public static BlockArcaneCake blockArcaneCake;
   public static BlockBalancedCrystal blockCrystalBalanced;
   public static BlockCelestialMagnet blockCelestialMagnet;
   public static BlockSoulAmber blockSoulAmber;
   
   public static void initBlocks() {
/* 28 */     blockCurativeVat = getBlock(new BlockCurativeVat(), "curative_vat");
/* 29 */     blockVatInterior = getBlock(new BlockLiquidVat(), "vat_interior");
/* 30 */     blockJarSoul = getBlock(new BlockJarSoul(), "jar_soul");
/* 31 */     blockArcaneCake = getBlock(new BlockArcaneCake(), "arcane_cake");
     
/* 33 */     blockModifiedMatrix = getBlock(new BlockModifiedMatrix(), "modified_matrix");
   }
   
   public static Block getBlock(String name, Material material) {
/* 37 */     return getBlock(new Block(material), name);
   }
 
   
   public static <T extends Block> T getBlock(T block, String name) {
/* 42 */     return registry((T)((Block)block.setRegistryName(new ResourceLocation("isorropia", name)))
/* 43 */         .func_149663_c("isorropia." + name));
   }
   
   public static <T extends Block> T registry(T block) {
/* 47 */     if (!(block instanceof IBlockRegistry) || ((IBlockRegistry)block).isInCreativeTabs())
/* 48 */       block.func_149647_a(Common.isorropiaCreativeTabs); 
/* 49 */     blocks.add((Block)block);
/* 50 */     return block;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlocksIS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */