/*     */ package fr.wind_blade.isorropia.common.lenses;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.items.misc.ItemLens;
/*     */ import fr.wind_blade.isorropia.common.libs.helpers.IRMathHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AirLens
/*     */   extends Lens
/*     */ {
/*     */   public static final byte AIR_LENS_DIST_CAP = 24;
/*  25 */   public static final ResourceLocation TEX = new ResourceLocation("isorropia", "textures/fx/ripple.png");
/*  26 */   public static final ResourceLocation TEX_UNDEAD = new ResourceLocation("isorropia", "textures/fx/vortex.png");
/*  27 */   public static final ResourceLocation TEX_ELDRITCH = new ResourceLocation("thaumcraft", "textures/misc/vortex.png");
/*     */ 
/*     */   
/*     */   public AirLens(ItemLens lensIn) {
/*  31 */     super(lensIn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleTicks(World worldIn, EntityPlayer playerIn, boolean doubleLens) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRenderGameOverlay(World worldIn, EntityPlayer playerIn, ScaledResolution resolution, boolean doubleLens, float partialTicks) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRenderWorldLast(World worldIn, EntityPlayer playerIn, boolean doubleLens, float partialTicks) {
/*  47 */     if ((Minecraft.func_71410_x()).field_71474_y.field_74320_O > 0) {
/*     */       return;
/*     */     }
/*  50 */     List<EntityLivingBase> base = playerIn.field_70170_p.func_175647_a(EntityLivingBase.class, new AxisAlignedBB(playerIn.field_70165_t - 24.0D, playerIn.field_70163_u - 24.0D, playerIn.field_70161_v - 24.0D, playerIn.field_70165_t + 24.0D, playerIn.field_70163_u + 24.0D, playerIn.field_70161_v + 24.0D), e -> (e != playerIn));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     for (EntityLivingBase e : base) {
/*     */       
/*  58 */       double playerOffX = playerIn.field_70169_q + (playerIn.field_70165_t - playerIn.field_70169_q) * partialTicks;
/*  59 */       double playerOffY = playerIn.field_70167_r + (playerIn.field_70163_u - playerIn.field_70167_r) * partialTicks;
/*  60 */       double playerOffZ = playerIn.field_70166_s + (playerIn.field_70161_v - playerIn.field_70166_s) * partialTicks;
/*     */       
/*  62 */       double eOffX = e.field_70169_q + (e.field_70165_t - e.field_70169_q) * partialTicks;
/*  63 */       double eOffY = e.field_70167_r + (e.field_70163_u - e.field_70167_r) * partialTicks;
/*  64 */       double eOffZ = e.field_70166_s + (e.field_70161_v - e.field_70166_s) * partialTicks;
/*     */       
/*  66 */       double scale = e.func_174791_d().func_178788_d(playerIn.func_174791_d()).func_72433_c();
/*  67 */       float sizeOffset = (e.field_70173_aa % 16);
/*     */       
/*  69 */       double cappedTchebychevDist = Math.min(IRMathHelper.getTchebychevDistance((Entity)e, (Entity)playerIn), 24.0D);
/*  70 */       float alpha = (float)(1.0D - cappedTchebychevDist / 24.0D);
/*  71 */       float size = Math.min(e.field_70131_O, e.field_70130_N);
/*     */       
/*  73 */       if (e instanceof thaumcraft.api.entities.IEldritchMob) {
/*  74 */         GlStateManager.func_179094_E();
/*  75 */         GL11.glDisable(2929);
/*  76 */         size = (float)(size * 0.8D);
/*     */         
/*  78 */         GlStateManager.func_179137_b(-playerOffX, -playerOffY, -playerOffZ);
/*  79 */         GlStateManager.func_179137_b(eOffX, eOffY + (e.field_70131_O / 2.0F), eOffZ);
/*  80 */         GlStateManager.func_179114_b(-playerIn.field_70177_z, 0.0F, 1.0F, 0.0F);
/*  81 */         GlStateManager.func_179114_b(playerIn.field_70125_A, 1.0F, 0.0F, 0.0F);
/*  82 */         GlStateManager.func_179114_b((e.field_70173_aa % 360), 0.0F, 0.0F, 1.0F);
/*  83 */         UtilsFX.renderQuadCentered(TEX_ELDRITCH, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*  84 */         GlStateManager.func_179114_b((-(e.field_70173_aa % 360) * 2), 0.0F, 0.0F, 1.0F);
/*  85 */         size *= 2.0F;
/*     */         
/*  87 */         UtilsFX.renderQuadCentered(TEX_ELDRITCH, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*     */         
/*  89 */         GL11.glEnable(2929);
/*  90 */         GlStateManager.func_179121_F(); continue;
/*     */       } 
/*  92 */       if (e.func_70662_br()) {
/*  93 */         size = (float)(size * 1.3D);
/*  94 */         GlStateManager.func_179094_E();
/*  95 */         GL11.glDisable(2929);
/*     */         
/*  97 */         GlStateManager.func_179137_b(-playerOffX, -playerOffY, -playerOffZ);
/*  98 */         GlStateManager.func_179137_b(eOffX, eOffY + (e.field_70131_O / 2.0F), eOffZ);
/*  99 */         GlStateManager.func_179114_b(-playerIn.field_70177_z, 0.0F, 1.0F, 0.0F);
/* 100 */         GlStateManager.func_179114_b(playerIn.field_70125_A, 1.0F, 0.0F, 0.0F);
/* 101 */         GlStateManager.func_179114_b(-(e.field_70173_aa % 360), 0.0F, 0.0F, 1.0F);
/* 102 */         UtilsFX.renderQuadCentered(TEX_UNDEAD, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/* 103 */         size *= 2.0F;
/* 104 */         GlStateManager.func_179114_b((e.field_70173_aa % 360 * 2), 0.0F, 0.0F, 1.0F);
/*     */         
/* 106 */         UtilsFX.renderQuadCentered(TEX_UNDEAD, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*     */         
/* 108 */         GL11.glEnable(2929);
/* 109 */         GlStateManager.func_179121_F(); continue;
/*     */       } 
/* 111 */       double numbers = Math.min(48.0D / scale + 1.0D, 4.0D);
/*     */       
/* 113 */       for (int i = 0; i < numbers; i++) {
/* 114 */         float numSize = (float)(((i * 16) / (numbers + 1.0D) + sizeOffset) % 16.0D / 12.0D) * size;
/*     */         
/* 116 */         GlStateManager.func_179094_E();
/* 117 */         GL11.glDisable(2929);
/*     */         
/* 119 */         GlStateManager.func_179137_b(-playerOffX, -playerOffY, -playerOffZ);
/* 120 */         GlStateManager.func_179137_b(eOffX, eOffY + (e.field_70131_O / 2.0F), eOffZ);
/* 121 */         GlStateManager.func_179114_b(-playerIn.field_70177_z, 0.0F, 1.0F, 0.0F);
/* 122 */         GlStateManager.func_179114_b(playerIn.field_70125_A, 1.0F, 0.0F, 0.0F);
/* 123 */         UtilsFX.renderQuadCentered(TEX, numSize, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*     */         
/* 125 */         GL11.glEnable(2929);
/* 126 */         GlStateManager.func_179121_F();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handleRemoval(World worldIn, EntityPlayer playerIn) {}
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\lenses\AirLens.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */