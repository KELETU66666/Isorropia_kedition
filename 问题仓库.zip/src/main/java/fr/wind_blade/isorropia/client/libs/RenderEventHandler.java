/*     */ package fr.wind_blade.isorropia.client.libs;
/*     */ 
/*     */ import fr.wind_blade.isorropia.client.model.DynamicStaticModel;
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.IsorropiaAPI;
/*     */ import fr.wind_blade.isorropia.common.blocks.BlocksIS;
/*     */ import fr.wind_blade.isorropia.common.capabilities.LivingBaseCapability;
/*     */ import fr.wind_blade.isorropia.common.events.KeyHandler;
/*     */ import fr.wind_blade.isorropia.common.items.misc.ItemLens;
/*     */ import fr.wind_blade.isorropia.common.lenses.Lens;
/*     */ import fr.wind_blade.isorropia.common.lenses.LensManager;
/*     */ import fr.wind_blade.isorropia.common.network.LensChangeMessage;
/*     */ import fr.wind_blade.isorropia.common.research.recipes.CurativeInfusionRecipe;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.TreeMap;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.RenderItem;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.block.model.IBakedModel;
/*     */ import net.minecraft.client.renderer.block.model.ModelResourceLocation;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.client.util.ITooltipFlag;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.GuiScreenEvent;
/*     */ import net.minecraftforge.client.event.ModelBakeEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderHandEvent;
/*     */ import net.minecraftforge.client.event.RenderLivingEvent;
/*     */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*     */ import net.minecraftforge.event.entity.player.ItemTooltipEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import net.minecraftforge.fml.relauncher.ReflectionHelper;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.Display;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.gui.GuiResearchBrowser;
/*     */ import thaumcraft.client.gui.GuiResearchPage;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderEventHandler
/*     */ {
/*  69 */   public static final ResourceLocation LIGO_TEX = new ResourceLocation("isorropia", "textures/misc/ligo.png");
/*     */   
/*  71 */   public static IBakedModel jar_soul = null;
/*     */   
/*     */   private static Lens theRightLens;
/*  74 */   private static fociHUD fociLeft = new fociHUD(LensManager.LENSSLOT.LEFT); private static Lens theLeftLens; private static float radialHudScale;
/*  75 */   private static fociHUD fociRight = new fociHUD(LensManager.LENSSLOT.RIGHT);
/*     */   
/*  77 */   public static ResourceLocation TEX_VIS = new ResourceLocation("thaumcraft", "textures/gui/gui_researchbook_overlay.png");
/*     */   
/*  79 */   public static ResourceLocation TEX_PAR = new ResourceLocation("thaumcraft", "textures/misc/particles.png");
/*  80 */   ResourceLocation tex4 = new ResourceLocation("thaumcraft", "textures/gui/paper.png");
/*  81 */   public static List<String> texts = Arrays.asList(new String[] { "wandtable.text1" });
/*     */   
/*     */   public static Method tip;
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onModelBakeEvent(ModelBakeEvent event) {
/*  87 */     ModelResourceLocation mrl = new ModelResourceLocation(BlocksIS.blockJarSoul.getRegistryName(), "inventory");
/*  88 */     jar_soul = (IBakedModel)event.getModelRegistry().func_82594_a(mrl);
/*  89 */     event.getModelRegistry().func_82595_a(mrl, new DynamicStaticModel(jar_soul, 
/*  90 */           Item.func_150898_a((Block)BlocksIS.blockJarSoul)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onOverlay(RenderGameOverlayEvent.Pre event) {
/* 108 */     if (event.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
/* 109 */       fociRight.handleFociRadial(Minecraft.func_71410_x(), System.nanoTime() / 1000000L, (RenderGameOverlayEvent)event);
/* 110 */       fociLeft.handleFociRadial(Minecraft.func_71410_x(), System.nanoTime() / 1000000L, (RenderGameOverlayEvent)event);
/*     */     } 
/*     */     
/* 113 */     if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
/* 114 */       WorldClient worldClient = (Minecraft.func_71410_x()).field_71441_e;
/* 115 */       EntityPlayerSP entityPlayerSP = (Minecraft.func_71410_x()).field_71439_g;
/* 116 */       ItemStack revealer = LensManager.getRevealer((EntityPlayer)entityPlayerSP);
/*     */       
/* 118 */       if (!revealer.func_190926_b() && revealer.func_77942_o() && revealer
/* 119 */         .func_77978_p().func_74779_i("LeftLens") != null) {
/* 120 */         theLeftLens = LensManager.getLens(revealer, LensManager.LENSSLOT.LEFT);
/* 121 */         theRightLens = LensManager.getLens(revealer, LensManager.LENSSLOT.RIGHT);
/* 122 */         boolean doubleLens = (theRightLens != null && theRightLens.equals(theLeftLens));
/*     */ 
/*     */         
/* 125 */         if (theLeftLens != null) {
/* 126 */           theLeftLens.handleRenderGameOverlay((World)worldClient, (EntityPlayer)entityPlayerSP, event.getResolution(), doubleLens, event
/* 127 */               .getPartialTicks());
/*     */         }
/* 129 */         if (!doubleLens && theRightLens != null) {
/* 130 */           theRightLens.handleRenderGameOverlay((World)worldClient, (EntityPlayer)entityPlayerSP, event.getResolution(), false, event
/* 131 */               .getPartialTicks());
/*     */         }
/*     */       } 
/* 134 */       LivingBaseCapability cap = Common.getCap((EntityLivingBase)entityPlayerSP);
/* 135 */       if (cap.petrification > 0) {
/* 136 */         float flag = 1.0F - (100.0F - cap.petrification) / 100.0F;
/* 137 */         float width = (float)event.getResolution().func_78327_c();
/* 138 */         float height = (float)event.getResolution().func_78324_d();
/* 139 */         float f2 = height / 34.0F;
/* 140 */         float f3 = width / 34.0F;
/*     */         
/* 142 */         GlStateManager.func_179094_E();
/* 143 */         GlStateManager.func_179112_b(770, 771);
/* 144 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, flag);
/* 145 */         (Minecraft.func_71410_x()).field_71446_o
/* 146 */           .func_110577_a(new ResourceLocation("textures/blocks/cobblestone.png"));
/* 147 */         Tessellator tessellator = Tessellator.func_178181_a();
/* 148 */         BufferBuilder buffer = tessellator.func_178180_c();
/* 149 */         buffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/* 150 */         buffer.func_181666_a(1.0F, 1.0F, 1.0F, 0.1F);
/* 151 */         buffer.func_181662_b(0.0D, f2, 1.0D).func_187315_a(0.0D, height).func_181675_d();
/* 152 */         buffer.func_181662_b(f3, f2, 1.0D).func_187315_a(width, height).func_181675_d();
/* 153 */         buffer.func_181662_b(f3, 0.0D, 1.0D).func_187315_a(width, 0.0D).func_181675_d();
/* 154 */         buffer.func_181662_b(0.0D, 0.0D, 1.0D).func_187315_a(0.0D, 0.0D).func_181675_d();
/* 155 */         tessellator.func_78381_a();
/* 156 */         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 157 */         GlStateManager.func_179121_F();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void onDrawGui(GuiScreenEvent.DrawScreenEvent event) {
/* 165 */     GuiScreen screen = event.getGui();
/*     */     
/* 167 */     if (screen instanceof GuiResearchPage) {
/* 168 */       Field index = ReflectionHelper.findField(GuiResearchPage.class, new String[] { "recipePage" });
/* 169 */       Field recipes = ReflectionHelper.findField(GuiResearchPage.class, new String[] { "recipeLists" });
/* 170 */       Field shown = ReflectionHelper.findField(GuiResearchPage.class, new String[] { "shownRecipe" });
/*     */       
/*     */       try {
/* 173 */         int recipePage = ((Integer)index.get(screen)).intValue();
/* 174 */         LinkedHashMap maps = (LinkedHashMap)recipes.get(screen);
/* 175 */         ResourceLocation loc = (ResourceLocation)shown.get(screen);
/*     */         
/* 177 */         if (maps == null || loc == null) {
/*     */           return;
/*     */         }
/* 180 */         List<Object> list = (List<Object>)maps.get(loc);
/*     */         
/* 182 */         if (list != null && !list.isEmpty()) {
/* 183 */           Object recipe = list.get(recipePage % list.size());
/*     */           
/* 185 */           if (recipe instanceof CurativeInfusionRecipe) {
/* 186 */             drawCurativeInfusionRecipe((CurativeInfusionRecipe)recipe, event);
/*     */           }
/*     */         }
/*     */       
/* 190 */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 191 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onToolTip(ItemTooltipEvent event) {
/* 198 */     ArrayList<String> tooltip = (ArrayList<String>)event.getToolTip();
/* 199 */     ItemStack stack = event.getItemStack();
/*     */     
/* 201 */     if (stack.func_77942_o() && (stack.func_77973_b() instanceof thaumcraft.api.items.IGoggles || stack.func_77973_b() instanceof thaumcraft.api.items.IRevealer)) {
/* 202 */       String lens = stack.func_77978_p().func_74779_i(LensManager.LENSSLOT.LEFT.getName());
/*     */       
/* 204 */       if (!lens.isEmpty()) {
/* 205 */         tooltip.add(1, "§a" + I18n.func_135052_a("lens." + ((Lens)IsorropiaAPI.lensRegistry
/* 206 */               .getValue(new ResourceLocation(lens))).getTranslationKey(), new Object[0]));
/*     */       }
/*     */       
/* 209 */       lens = stack.func_77978_p().func_74779_i(LensManager.LENSSLOT.RIGHT.getName());
/*     */       
/* 211 */       if (!lens.isEmpty()) {
/* 212 */         tooltip.add(1, "§a" + I18n.func_135052_a("lens." + ((Lens)IsorropiaAPI.lensRegistry
/* 213 */               .getValue(new ResourceLocation(lens))).getTranslationKey(), new Object[0]));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void drawCurativeInfusionRecipe(CurativeInfusionRecipe recipe, GuiScreenEvent.DrawScreenEvent event) {
/* 219 */     GuiScreen screen = event.getGui();
/*     */     
/* 221 */     int x = (screen.field_146294_l - 256) / 2 + 128;
/* 222 */     int y = (screen.field_146295_m - 256) / 2 + 128;
/*     */     
/* 224 */     if (recipe.getVis() > 0.0F) {
/* 225 */       GL11.glPushMatrix();
/* 226 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 227 */       String text = "" + (int)recipe.getVis();
/* 228 */       int offset = (Minecraft.func_71410_x()).field_71466_p.func_78256_a(text);
/* 229 */       (Minecraft.func_71410_x()).field_71466_p.func_78276_b(text, x - offset / 2 + 70, y - 45, 5263440);
/* 230 */       (Minecraft.func_71410_x()).field_71446_o.func_110577_a(TEX_VIS);
/* 231 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
/* 232 */       GL11.glTranslatef(x, (y - 55), 0.0F);
/* 233 */       GL11.glScalef(2.0F, 2.0F, 1.0F);
/* 234 */       screen.func_73729_b(30, 0, 68, 76, 12, 12);
/* 235 */       GL11.glPopMatrix();
/*     */     } 
/*     */     
/* 238 */     if (recipe.getCelestialAura() != 0) {
/* 239 */       GL11.glPushMatrix();
/* 240 */       (Minecraft.func_71410_x()).field_71446_o.func_110577_a(recipe.getCelestialBody().getTex());
/* 241 */       GL11.glTranslatef((x + 56), (y - 17), 0.0F);
/* 242 */       GL11.glScalef(0.12F, 0.12F, 1.0F);
/* 243 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.7F);
/* 244 */       screen.func_73729_b(30, 0, 46, 45, 161, 162);
/* 245 */       GL11.glPopMatrix();
/*     */     } 
/*     */     
/* 248 */     if (recipe.getFluxRejection() > 0.0F) {
/* 249 */       GuiResearchBrowser.drawForbidden(x, (y - 70));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void renderLast(RenderWorldLastEvent event) {
/* 276 */     EntityPlayerSP player = (Minecraft.func_71410_x()).field_71439_g;
/* 277 */     ItemStack revealer = LensManager.getRevealer((EntityPlayer)player);
/*     */     
/* 279 */     if (!revealer.func_190926_b() && revealer.func_77942_o() && revealer
/* 280 */       .func_77978_p().func_74779_i("LeftLens") != null) {
/* 281 */       theLeftLens = LensManager.getLens(revealer, LensManager.LENSSLOT.LEFT);
/* 282 */       theRightLens = LensManager.getLens(revealer, LensManager.LENSSLOT.RIGHT);
/* 283 */       boolean doubleLens = (theRightLens != null && theRightLens.equals(theLeftLens));
/*     */ 
/*     */       
/* 286 */       if (theLeftLens != null) {
/* 287 */         theLeftLens.handleRenderWorldLast(player.field_70170_p, (EntityPlayer)player, doubleLens, event.getPartialTicks());
/*     */       }
/* 289 */       if (!doubleLens && theRightLens != null) {
/* 290 */         theRightLens.handleRenderWorldLast(player.field_70170_p, (EntityPlayer)player, false, event.getPartialTicks());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void renderPlayerEvent(RenderHandEvent event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void preRenderLiving(RenderLivingEvent.Pre<EntityLivingBase> event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent
/*     */   public static void postRenderLiving(RenderLivingEvent.Post<EntityLivingBase> event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static float interpolateRotation(float prevYawOffset, float yawOffset, float partialTicks) {
/*     */     float f;
/* 326 */     for (f = yawOffset - prevYawOffset; f < -180.0F; f += 360.0F);
/*     */ 
/*     */ 
/*     */     
/* 330 */     while (f >= 180.0F) {
/* 331 */       f -= 360.0F;
/*     */     }
/*     */     
/* 334 */     return prevYawOffset + partialTicks * f;
/*     */   }
/*     */   
/*     */   public static class fociHUD
/*     */   {
/* 339 */     private static final ResourceLocation radial = new ResourceLocation("thaumcraft", "textures/misc/radial.png");
/* 340 */     private static final ResourceLocation radial2 = new ResourceLocation("thaumcraft", "textures/misc/radial2.png");
/* 341 */     static final TreeMap<ResourceLocation, Integer> foci = new TreeMap<>();
/* 342 */     static final HashMap<ResourceLocation, ItemStack> lensStack = new HashMap<>();
/*     */     HashMap<ResourceLocation, Boolean> lensHover;
/* 344 */     HashMap<ResourceLocation, Float> fociScale = new HashMap<>();
/* 345 */     static final HashMap<ResourceLocation, Integer> lensSlot = new HashMap<>();
/*     */     final LensManager.LENSSLOT type;
/*     */     long lastTime;
/*     */     boolean lastState;
/*     */     
/*     */     public fociHUD(LensManager.LENSSLOT type) {
/* 351 */       this.lensHover = new HashMap<>();
/* 352 */       this.type = type;
/* 353 */       this.lastTime = 0L;
/* 354 */       this.lastState = false;
/*     */     }
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public void handleFociRadial(Minecraft mc, long time, RenderGameOverlayEvent event) {
/* 359 */       if (KeyHandler.radialActive || RenderEventHandler.radialHudScale > 0.0F) {
/* 360 */         if (KeyHandler.radialActive) {
/* 361 */           if (mc.field_71462_r != null) {
/* 362 */             KeyHandler.radialActive = false;
/* 363 */             KeyHandler.radialLock = true;
/* 364 */             mc.func_71381_h();
/* 365 */             mc.func_71364_i();
/*     */             return;
/*     */           } 
/* 368 */           if (RenderEventHandler.radialHudScale == 0.0F) {
/* 369 */             foci.clear();
/* 370 */             lensStack.clear();
/* 371 */             this.lensHover.clear();
/* 372 */             this.fociScale.clear();
/* 373 */             lensSlot.clear();
/* 374 */             ItemStack item = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 389 */             for (int a = 0; a < mc.field_71439_g.field_71071_by.field_70462_a.size(); a++) {
/* 390 */               item = (ItemStack)mc.field_71439_g.field_71071_by.field_70462_a.get(a);
/* 391 */               if (!item.func_190926_b() && item.func_77973_b() instanceof ItemLens) {
/* 392 */                 ItemLens lens = (ItemLens)item.func_77973_b();
/* 393 */                 foci.put(lens.getLens().getRegistryName(), Integer.valueOf(a));
/* 394 */                 lensStack.put(lens.getLens().getRegistryName(), item.func_77946_l());
/* 395 */                 this.fociScale.put(lens.getLens().getRegistryName(), Float.valueOf(1.0F));
/* 396 */                 this.lensHover.put(lens.getLens().getRegistryName(), Boolean.valueOf(false));
/* 397 */                 lensSlot.put(lens.getLens().getRegistryName(), Integer.valueOf(a));
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 408 */               if (foci.size() > 0 && mc.field_71415_G) {
/* 409 */                 mc.field_71415_G = false;
/* 410 */                 mc.field_71417_B.func_74373_b();
/*     */               } 
/*     */             } 
/*     */           } 
/* 414 */         } else if (mc.field_71462_r == null && this.lastState) {
/* 415 */           if (Display.isActive() && !mc.field_71415_G) {
/* 416 */             mc.field_71415_G = true;
/* 417 */             mc.field_71417_B.func_74372_a();
/*     */           } 
/* 419 */           this.lastState = false;
/*     */         } 
/* 421 */         renderFocusRadialHUD(event.getResolution().func_78327_c(), event
/* 422 */             .getResolution().func_78324_d(), time, event.getPartialTicks());
/* 423 */         if (time > this.lastTime) {
/* 424 */           for (ResourceLocation key : this.lensHover.keySet()) {
/* 425 */             if (((Boolean)this.lensHover.get(key)).booleanValue()) {
/* 426 */               if (!KeyHandler.radialActive && !KeyHandler.radialLock) {
/* 427 */                 if (lensSlot.containsKey(key)) {
/* 428 */                   Lens lens = (Lens)IsorropiaAPI.lensRegistry.getValue(key);
/* 429 */                   LensManager.putLens((EntityPlayer)(Minecraft.func_71410_x()).field_71439_g, lens, this.type);
/* 430 */                   Common.INSTANCE
/* 431 */                     .sendToServer((IMessage)new LensChangeMessage(lens, ((Integer)lensSlot.get(key)).intValue(), this.type));
/*     */                 } 
/* 433 */                 KeyHandler.radialLock = true;
/*     */               } 
/* 435 */               if (((Float)this.fociScale.get(key)).floatValue() >= 1.3F) {
/*     */                 continue;
/*     */               }
/* 438 */               this.fociScale.put(key, Float.valueOf(((Float)this.fociScale.get(key)).floatValue() + 0.025F)); continue;
/*     */             } 
/* 440 */             if (((Float)this.fociScale.get(key)).floatValue() <= 1.0F) {
/*     */               continue;
/*     */             }
/* 443 */             this.fociScale.put(key, Float.valueOf(((Float)this.fociScale.get(key)).floatValue() - 0.025F));
/*     */           } 
/*     */ 
/*     */           
/* 447 */           if (!KeyHandler.radialActive) {
/* 448 */             RenderEventHandler.radialHudScale = RenderEventHandler.radialHudScale - 0.05F;
/* 449 */           } else if (RenderEventHandler.radialHudScale < 1.0F) {
/* 450 */             RenderEventHandler.radialHudScale = Math.min(RenderEventHandler.radialHudScale = RenderEventHandler.radialHudScale + 0.05F, 1.0F);
/*     */           } 
/*     */           
/* 453 */           if (RenderEventHandler.radialHudScale < 0.0F) {
/* 454 */             RenderEventHandler.radialHudScale = 0.0F;
/* 455 */             KeyHandler.radialLock = false;
/*     */           } 
/*     */           
/* 458 */           this.lastTime = time + 5L;
/* 459 */           this.lastState = KeyHandler.radialActive;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void renderFocusRadialHUD(double sw, double sh, long time, float partialTicks) {
/* 465 */       Minecraft mc = Minecraft.func_71410_x();
/* 466 */       RenderItem ri = Minecraft.func_71410_x().func_175599_af();
/* 467 */       ItemStack goggles = LensManager.getRevealer((EntityPlayer)mc.field_71439_g);
/* 468 */       if (goggles == null)
/*     */         return; 
/* 470 */       Lens lens = null;
/* 471 */       if (goggles.func_77978_p() != null)
/*     */       {
/* 473 */         lens = (Lens)IsorropiaAPI.lensRegistry.getValue(new ResourceLocation(goggles.func_77978_p().func_74779_i(this.type.getName()))); } 
/* 474 */       int i = (int)(Mouse.getEventX() * sw / mc.field_71443_c);
/* 475 */       int j = (int)(sh - Mouse.getEventY() * sh / mc.field_71440_d - 1.0D);
/* 476 */       int k = Mouse.getEventButton();
/* 477 */       if (lensStack.size() == 0) {
/*     */         return;
/*     */       }
/* 480 */       GL11.glPushMatrix();
/* 481 */       GL11.glClear(256);
/* 482 */       GL11.glMatrixMode(5889);
/* 483 */       GL11.glLoadIdentity();
/* 484 */       GL11.glOrtho(0.0D, sw, sh, 0.0D, 1000.0D, 3000.0D);
/* 485 */       GL11.glMatrixMode(5888);
/* 486 */       GL11.glLoadIdentity();
/* 487 */       GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/* 488 */       GL11.glDisable(2929);
/* 489 */       GL11.glDepthMask(false);
/* 490 */       GL11.glPushMatrix();
/* 491 */       GL11.glTranslated(sw / 2.0D, sh / 2.0D, 0.0D);
/* 492 */       ItemStack tt = null;
/* 493 */       float width = 16.0F + lensStack.size() * 2.5F;
/* 494 */       GL11.glTranslatef(this.type.getAngle(), 0.0F, 0.0F);
/* 495 */       mc.field_71446_o.func_110577_a(radial);
/* 496 */       GL11.glPushMatrix();
/* 497 */       if (this.type.equals(LensManager.LENSSLOT.LEFT)) {
/* 498 */         GL11.glRotatef(-(partialTicks + (mc.field_71439_g.field_70173_aa % 720) / 2.0F), 0.0F, 0.0F, 1.0F);
/*     */       } else {
/* 500 */         GL11.glRotatef(partialTicks + (mc.field_71439_g.field_70173_aa % 720) / 2.0F, 0.0F, 0.0F, 1.0F);
/* 501 */       }  GL11.glAlphaFunc(516, 0.003921569F);
/* 502 */       GL11.glEnable(3042);
/* 503 */       GL11.glBlendFunc(770, 771);
/* 504 */       UtilsFX.renderQuadCentered(1, 1, 0, width * 2.75F * RenderEventHandler.radialHudScale, 0.5F, 0.5F, 0.5F, 200, 771, 0.5F);
/* 505 */       GL11.glDisable(3042);
/* 506 */       GL11.glAlphaFunc(516, 0.1F);
/* 507 */       GL11.glPopMatrix();
/* 508 */       mc.field_71446_o.func_110577_a(radial2);
/* 509 */       GL11.glPushMatrix();
/* 510 */       if (this.type.equals(LensManager.LENSSLOT.LEFT)) {
/* 511 */         GL11.glRotatef(partialTicks + (mc.field_71439_g.field_70173_aa % 720) / 2.0F, 0.0F, 0.0F, 1.0F);
/*     */       } else {
/* 513 */         GL11.glRotatef(-(partialTicks + (mc.field_71439_g.field_70173_aa % 720) / 2.0F), 0.0F, 0.0F, 1.0F);
/* 514 */       }  GL11.glAlphaFunc(516, 0.003921569F);
/* 515 */       GL11.glEnable(3042);
/* 516 */       GL11.glBlendFunc(770, 771);
/* 517 */       UtilsFX.renderQuadCentered(1, 1, 0, width * 2.55F * RenderEventHandler.radialHudScale, 0.5F, 0.5F, 0.5F, 200, 771, 0.5F);
/* 518 */       GL11.glDisable(3042);
/* 519 */       GL11.glAlphaFunc(516, 0.1F);
/* 520 */       GL11.glPopMatrix();
/* 521 */       if (lens != null) {
/* 522 */         GL11.glPushMatrix();
/* 523 */         GL11.glEnable(32826);
/* 524 */         RenderHelper.func_74520_c();
/* 525 */         ItemLens itemLens = lens.getItemLens();
/* 526 */         ItemStack item = new ItemStack((Item)itemLens);
/* 527 */         item.func_77982_d(null);
/* 528 */         ri.func_175042_a(item, -8, -8);
/* 529 */         RenderHelper.func_74518_a();
/* 530 */         GL11.glDisable(32826);
/* 531 */         GL11.glPopMatrix();
/* 532 */         int mx = (int)(i - sw / 2.0D);
/* 533 */         int my = (int)(j - sh / 2.0D);
/* 534 */         if (mx >= -10 && mx <= 10 && my >= -10 && my <= 10) {
/* 535 */           tt = new ItemStack((Item)lens.getItemLens());
/*     */         }
/*     */       } 
/* 538 */       GL11.glScaled(RenderEventHandler.radialHudScale, RenderEventHandler.radialHudScale, RenderEventHandler
/* 539 */           .radialHudScale);
/* 540 */       float currentRot = -90.0F * RenderEventHandler.radialHudScale;
/* 541 */       float pieSlice = 360.0F / lensStack.size();
/* 542 */       ResourceLocation key = foci.firstKey();
/* 543 */       for (int a = 0; a < lensStack.size(); a++) {
/* 544 */         double xx = (MathHelper.func_76134_b(currentRot / 180.0F * 3.141593F) * width);
/* 545 */         double yy = (MathHelper.func_76126_a(currentRot / 180.0F * 3.141593F) * width);
/* 546 */         currentRot += pieSlice;
/* 547 */         GL11.glPushMatrix();
/* 548 */         if (this.type.equals(LensManager.LENSSLOT.LEFT)) {
/* 549 */           GL11.glTranslated(xx, yy, 100.0D);
/*     */         } else {
/* 551 */           GL11.glTranslated(-xx, yy, 100.0D);
/* 552 */         }  if (this.fociScale.get(key) == null)
/* 553 */           this.fociScale.put(key, Float.valueOf(1.0F)); 
/* 554 */         GL11.glScalef(((Float)this.fociScale.get(key)).floatValue(), ((Float)this.fociScale.get(key)).floatValue(), ((Float)this.fociScale.get(key)).floatValue());
/* 555 */         GL11.glEnable(32826);
/* 556 */         RenderHelper.func_74520_c();
/* 557 */         ItemStack item2 = ((ItemStack)lensStack.get(key)).func_77946_l();
/* 558 */         item2.func_77982_d(null);
/* 559 */         ri.func_175042_a(item2, -8, -8);
/* 560 */         RenderHelper.func_74518_a();
/* 561 */         GL11.glDisable(32826);
/* 562 */         GL11.glPopMatrix();
/* 563 */         if (!KeyHandler.radialLock && KeyHandler.radialActive) {
/*     */           int mx2;
/*     */           
/* 566 */           if (this.type.equals(LensManager.LENSSLOT.LEFT)) {
/* 567 */             mx2 = (int)(i - sw / 2.0D - xx + -this.type.getAngle());
/*     */           } else {
/* 569 */             mx2 = (int)(i - sw / 2.0D - -xx + -this.type.getAngle());
/* 570 */           }  int my2 = (int)(j - sh / 2.0D - yy);
/* 571 */           if (mx2 >= -10 && mx2 <= 10 && my2 >= -10 && my2 <= 10) {
/* 572 */             this.lensHover.put(key, Boolean.valueOf(true));
/* 573 */             tt = lensStack.get(key);
/* 574 */             if (k == 0) {
/* 575 */               KeyHandler.radialActive = false;
/* 576 */               KeyHandler.radialLock = true;
/* 577 */               if (lensSlot.containsKey(key)) {
/* 578 */                 Lens lens1 = (Lens)IsorropiaAPI.lensRegistry.getValue(key);
/* 579 */                 LensManager.putLens((EntityPlayer)(Minecraft.func_71410_x()).field_71439_g, lens1, this.type);
/* 580 */                 Common.INSTANCE
/* 581 */                   .sendToServer((IMessage)new LensChangeMessage(lens1, ((Integer)lensSlot.get(key)).intValue(), this.type));
/*     */               } 
/*     */               break;
/*     */             } 
/*     */           } else {
/* 586 */             this.lensHover.put(key, Boolean.valueOf(false));
/*     */           } 
/* 588 */         }  key = foci.higherKey(key);
/*     */       } 
/* 590 */       GL11.glPopMatrix();
/* 591 */       if (tt != null)
/* 592 */         UtilsFX.drawCustomTooltip(mc.field_71462_r, mc.field_71466_p, tt
/* 593 */             .func_82840_a((EntityPlayer)mc.field_71439_g, (ITooltipFlag)ITooltipFlag.TooltipFlags.ADVANCED), 0, 20, 11); 
/* 594 */       GL11.glDepthMask(true);
/* 595 */       GL11.glEnable(2929);
/* 596 */       GL11.glDisable(3042);
/* 597 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 598 */       GL11.glPopMatrix();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\libs\RenderEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */