/*     */ package fr.wind_blade.isorropia.common.lenses;
/*     */ import baubles.api.BaublesApi;
/*     */ import fr.wind_blade.isorropia.common.IsorropiaAPI;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import thaumcraft.api.items.IRevealer;
/*     */ 
/*     */ public class LensManager {
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static void putLens(EntityPlayer player, Lens lens, LENSSLOT type) {
/*  18 */     ItemStack revealer = getRevealer(player);
/*     */ 
/*     */     
/*  21 */     Lens old = revealer.func_77942_o() ? (Lens)IsorropiaAPI.lensRegistry.getValue(new ResourceLocation(revealer.func_77978_p().func_74779_i(type.getName()))) : null;
/*     */ 
/*     */     
/*  24 */     if (old != null)
/*  25 */       old.handleRemoval(player.field_70170_p, player); 
/*  26 */     setLens(getRevealer((EntityPlayer)(Minecraft.func_71410_x()).field_71439_g), lens, type);
/*     */   }
/*     */   
/*     */   public static Lens getLens(ItemStack revealer, LENSSLOT type) {
/*  30 */     if (revealer.func_77942_o() && revealer.func_77978_p().func_74764_b(type.getName()))
/*  31 */       return (Lens)IsorropiaAPI.lensRegistry
/*  32 */         .getValue(new ResourceLocation(revealer.func_77978_p().func_74779_i(type.getName()))); 
/*  33 */     return null;
/*     */   }
/*     */   
/*     */   public static void setLens(ItemStack revealer, Lens lens, LENSSLOT type) {
/*  37 */     if (lens == null)
/*     */       return; 
/*  39 */     if (!revealer.func_77942_o())
/*  40 */       revealer.func_77982_d(new NBTTagCompound()); 
/*  41 */     NBTTagCompound compound = revealer.func_77978_p();
/*  42 */     compound.func_74778_a(type.getName(), lens.getRegistryName().toString());
/*  43 */     revealer.func_77982_d(compound);
/*     */   }
/*     */   
/*     */   public static void removeLens(EntityPlayer player, ItemStack revealer, LENSSLOT type) {
/*  47 */     if (revealer.func_77942_o() && revealer.func_77978_p().func_74764_b(type.getName())) {
/*  48 */       String oldLens = revealer.func_77978_p().func_74779_i(type.getName());
/*  49 */       if (!oldLens.isEmpty()) {
/*  50 */         Lens lens2 = (Lens)IsorropiaAPI.lensRegistry.getValue(new ResourceLocation(oldLens));
/*  51 */         lens2.handleRemoval(player.field_70170_p, player);
/*  52 */         if (!player.field_71071_by.func_70441_a(new ItemStack((Item)lens2.getItemLens())))
/*  53 */           player.func_71019_a(new ItemStack((Item)lens2.getItemLens()), false); 
/*  54 */         revealer.func_77978_p().func_82580_o(type.getName());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean changeLens(EntityPlayer player, Lens lens, LENSSLOT type) {
/*  60 */     ItemStack revealer = getRevealer(player);
/*  61 */     if (!revealer.func_190926_b()) {
/*  62 */       removeLens(player, revealer, type);
/*  63 */       if (lens != null)
/*  64 */         setLens(revealer, lens, type); 
/*  65 */       return true;
/*     */     } 
/*  67 */     return false;
/*     */   }
/*     */   
/*     */   public static ItemStack getRevealer(EntityPlayer player) {
/*  71 */     boolean find = false;
/*  72 */     ItemStack revealer = ItemStack.field_190927_a;
/*  73 */     for (int i = 0; i < 7; i++) {
/*  74 */       revealer = BaublesApi.getBaubles(player).func_70301_a(i);
/*  75 */       if (revealer.func_77973_b() instanceof IRevealer && ((IRevealer)revealer
/*  76 */         .func_77973_b()).showNodes(revealer, (EntityLivingBase)player)) {
/*  77 */         find = true;
/*     */         break;
/*     */       } 
/*     */     } 
/*  81 */     if (!find) {
/*  82 */       for (ItemStack stack : player.func_184193_aE()) {
/*  83 */         if (stack.func_77973_b() instanceof IRevealer && ((IRevealer)stack.func_77973_b()).showNodes(stack, (EntityLivingBase)player)) {
/*  84 */           revealer = stack;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*  89 */     return revealer;
/*     */   }
/*     */   
/*     */   public enum LENSSLOT {
/*  93 */     LEFT("LeftLens", 42.0F), RIGHT("RightLens", -42.0F);
/*     */     
/*     */     private final float angle;
/*     */     private final String type;
/*     */     
/*     */     LENSSLOT(String type, float angle) {
/*  99 */       this.type = type;
/* 100 */       this.angle = angle;
/*     */     }
/*     */     
/*     */     public static LENSSLOT getByString(String name) {
/* 104 */       for (LENSSLOT slot : values()) {
/* 105 */         if (slot.getName().equals(name)) {
/* 106 */           return slot;
/*     */         }
/*     */       } 
/*     */       
/* 110 */       return LEFT;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 114 */       return this.type;
/*     */     }
/*     */     
/*     */     public float getAngle() {
/* 118 */       return this.angle;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\lenses\LensManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */