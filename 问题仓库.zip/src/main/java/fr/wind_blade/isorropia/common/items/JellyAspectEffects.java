 package fr.wind_blade.isorropia.common.items;
 
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.init.MobEffects;
 import net.minecraft.item.ItemStack;
 import net.minecraft.potion.PotionEffect;
 import net.minecraft.util.DamageSource;
 
 
 
 public class JellyAspectEffects
 {
   public static class DEFAULT_EFFECT
     implements IJellyAspectEffectProvider {}
   
   public static class MOTION_EFFECT
     implements IJellyAspectEffectProvider
   {
     public void onFoodEeaten(EntityPlayer player, ItemStack stack) {
/* 20 */       player.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 600, 2, false, false));
     }
   }
   
   public static class LIFE_EFFECT
     implements IJellyAspectEffectProvider {
     public void onFoodEeaten(EntityPlayer player, ItemStack stack) {
/* 27 */       player.func_70691_i(3.0F);
     }
   }
   
   public static class EXCHANGE_EFFECT
     implements IJellyAspectEffectProvider {
     public void onFoodEeaten(EntityPlayer player, ItemStack stack) {
/* 34 */       player.func_70097_a(DamageSource.field_76376_m, 3.0F);
     }
 
     
     public int getHungerReplinish(ItemStack stack) {
/* 39 */       return 7;
     }
   }
   
   public static class PROTECT_EFFECT
     implements IJellyAspectEffectProvider {
     public void onFoodEeaten(EntityPlayer player, ItemStack stack) {
/* 46 */       player.func_70690_d(new PotionEffect(MobEffects.field_76444_x, 200, 2, false, false));
     }
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\JellyAspectEffects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */