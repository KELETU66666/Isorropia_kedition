 package fr.wind_blade.isorropia.common.blocks;
 
 import net.minecraft.block.Block;
 import net.minecraft.block.SoundType;
 import net.minecraft.block.material.EnumPushReaction;
 import net.minecraft.block.material.Material;
 import net.minecraft.block.state.IBlockState;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.util.BlockRenderLayer;
 import net.minecraft.util.EnumFacing;
 import net.minecraft.util.math.BlockPos;
 import net.minecraft.world.IBlockAccess;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 
 public class BlockSoulAmber
   extends Block {
   public BlockSoulAmber() {
/* 19 */     super(Material.field_151592_s);
/* 20 */     func_149711_c(0.5F);
/* 21 */     func_149672_a(SoundType.field_185851_d);
   }
 
   
   public boolean isBeaconBase(IBlockAccess world, BlockPos pos, BlockPos beacon) {
/* 26 */     return true;
   }
 
   
   public boolean canHarvestBlock(IBlockAccess world, BlockPos pos, EntityPlayer player) {
/* 31 */     return true;
   }
   
   public EnumPushReaction getMobilityFlag(IBlockState state) {
/* 35 */     return EnumPushReaction.NORMAL;
   }
 
 
   
   @SideOnly(Side.CLIENT)
   public boolean func_176225_a(IBlockState blockState, IBlockAccess blockAccess, BlockPos pos, EnumFacing side) {
/* 42 */     IBlockState iblockstate = blockAccess.func_180495_p(pos.func_177972_a(side));
/* 43 */     Block block = iblockstate.func_177230_c();
/* 44 */     return (block == this) ? false : super.func_176225_a(blockState, blockAccess, pos, side);
   }
   
   @SideOnly(Side.CLIENT)
   public BlockRenderLayer getBlockLayer() {
/* 49 */     return BlockRenderLayer.TRANSLUCENT;
   }
 
   
   public boolean func_149662_c(IBlockState iblockstate) {
/* 54 */     return false;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockSoulAmber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */