 package fr.wind_blade.isorropia.common.items.misc;
 
 import fr.wind_blade.isorropia.common.lenses.Lens;
 import net.minecraft.item.Item;
 
 public class ItemLens
   extends Item {
   private Lens lens;
   
   public ItemLens() {
/* 11 */     func_77625_d(1);
   }
   
   public void setLens(Lens lensIn) {
/* 15 */     this.lens = lensIn;
   }
   
   public Lens getLens() {
/* 19 */     return this.lens;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\misc\ItemLens.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */