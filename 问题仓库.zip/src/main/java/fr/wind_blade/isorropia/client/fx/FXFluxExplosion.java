 package fr.wind_blade.isorropia.client.fx;
 
 import java.util.Random;
 import net.minecraft.client.particle.Particle;
 import net.minecraft.client.renderer.BufferBuilder;
 import net.minecraft.entity.Entity;
 import net.minecraft.util.math.MathHelper;
 import net.minecraft.world.World;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import thaumcraft.client.fx.ParticleEngine;
 import thaumcraft.client.fx.particles.FXGeneric;
 
 @SideOnly(Side.CLIENT)
 public class FXFluxExplosion
   extends Particle
 {
   public FXFluxExplosion(World world, double x, double y, double z) {
/* 19 */     super(world, x, y, z);
/* 20 */     for (int i = 0; i < 3; i++) {
/* 21 */       for (int j = 0; j < 180; j++) {
         
/* 23 */         boolean sp = (this.field_187136_p.nextFloat() < 0.2D);
         
/* 25 */         FXGeneric fb = new FXGeneric(world, x, y, z, getRandomSign(this.field_187136_p), getRandomSign(this.field_187136_p), getRandomSign(this.field_187136_p));
/* 26 */         fb.setRBGColorF(MathHelper.func_76131_a(384.0F, 0.0F, 1.0F), 0.0F, MathHelper.func_76131_a(384.0F, 0.0F, 1.0F), this.field_187136_p
/* 27 */             .nextFloat(), this.field_187136_p.nextFloat(), this.field_187136_p.nextFloat());
         
/* 29 */         fb.setLoop(true);
/* 30 */         fb.setLayer(0);
/* 31 */         fb.setSlowDown(0.955D);
/* 32 */         int age = 30 + this.field_187136_p.nextInt(20);
/* 33 */         fb.func_187114_a(age);
/* 34 */         float[] alphas = new float[6 + this.field_187136_p.nextInt(age / 3)];
/* 35 */         for (int a = 1; a < alphas.length - 1; a++)
/* 36 */           alphas[a] = this.field_187136_p.nextFloat(); 
/* 37 */         alphas[0] = 1.0F;
/* 38 */         fb.setAlphaF(alphas);
/* 39 */         fb.setParticles(sp ? 320 : 512, 16, 1);
/* 40 */         fb.setScale(new float[] { 0.5F, 0.125F });
/* 41 */         fb.setRandomMovementScale(0.0025F, 0.001F, 0.0025F);
         
/* 43 */         ParticleEngine.addEffectWithDelay(world, (Particle)fb, 2 + this.field_187136_p.nextInt(3));
       } 
     } 
   }
 
   
   public void func_189213_a() {
/* 50 */     super.func_189213_a();
   }
 
 
   
   public void func_180434_a(BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/* 56 */     super.func_180434_a(buffer, entityIn, partialTicks, rotationX, rotationZ, rotationYZ, rotationXY, rotationXZ);
   }
   
   public float getRandomSign(Random rand) {
/* 60 */     return (rand.nextBoolean() ? rand.nextFloat() : -rand.nextFloat()) / 1.5F;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\fx\FXFluxExplosion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */