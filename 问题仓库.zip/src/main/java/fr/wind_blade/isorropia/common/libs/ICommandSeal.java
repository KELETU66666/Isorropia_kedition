package fr.wind_blade.isorropia.common.libs;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public interface ICommandSeal {
  boolean canApplySeal(ICommandSeal paramICommandSeal, ItemStack paramItemStack, EntityLiving paramEntityLiving, EntityPlayer paramEntityPlayer);
  
  void applySeal(ICommandSeal paramICommandSeal, ItemStack paramItemStack, EntityLiving paramEntityLiving, EntityPlayer paramEntityPlayer);
  
  boolean removeSeal(ICommandSeal paramICommandSeal, EntityLiving paramEntityLiving, EntityPlayer paramEntityPlayer);
}


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\ICommandSeal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */