 package fr.wind_blade.isorropia.client.renderer.entities;
 import fr.wind_blade.isorropia.client.renderer.entities.layers.LayerTaintPigBorder;
 import fr.wind_blade.isorropia.common.entities.EntityTaintPig;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.model.ModelBase;
 import net.minecraft.client.model.ModelPig;
 import net.minecraft.client.renderer.entity.RenderLiving;
 import net.minecraft.client.renderer.entity.RenderManager;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLiving;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.util.ResourceLocation;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import org.lwjgl.opengl.GL11;
 import thaumcraft.client.lib.UtilsFX;
 
 @SideOnly(Side.CLIENT)
 public class RenderTaintPig extends RenderLiving<EntityTaintPig> {
/* 20 */   private static final ResourceLocation PIG_TEXTURES = new ResourceLocation("isorropia", "textures/entity/taintfeeder.png");
   
/* 22 */   public static final ResourceLocation nodetex = new ResourceLocation("isorropia", "textures/misc/nodes.png");
   
   public RenderTaintPig(RenderManager renderManagerIn) {
/* 25 */     super(renderManagerIn, (ModelBase)new ModelPig(), 0.5F);
/* 26 */     func_177094_a((LayerRenderer)new LayerTaintPigBorder(this));
   }
 
   
   protected ResourceLocation getEntityTexture(EntityTaintPig entity) {
/* 31 */     return PIG_TEXTURES;
   }
 
   
   public void doRender(EntityTaintPig entity, double x, double y, double z, float entityYaw, float partialTicks) {
/* 36 */     super.func_76986_a((EntityLiving)entity, x, y, z, entityYaw, partialTicks);
/* 37 */     GL11.glPushMatrix();
/* 38 */     GL11.glAlphaFunc(516, 0.003921569F);
/* 39 */     GL11.glEnable(3042);
/* 40 */     GL11.glBlendFunc(770, 1);
/* 41 */     GL11.glPushMatrix();
/* 42 */     GL11.glDepthMask(false);
/* 43 */     GL11.glDisable(2884);
/* 44 */     int i = entity.field_70173_aa % 32;
/* 45 */     (Minecraft.func_71410_x()).field_71446_o.func_110577_a(nodetex);
/* 46 */     UtilsFX.renderFacingQuad(entity.field_70165_t, entity.field_70163_u + entity.field_70131_O / 1.75D, entity.field_70161_v, 32, 32, 192 + i, 2.0F, 11197951, 1.0F, 1, partialTicks);
     
/* 48 */     GL11.glEnable(2884);
/* 49 */     GL11.glDepthMask(true);
/* 50 */     GL11.glPopMatrix();
/* 51 */     GL11.glDisable(3042);
/* 52 */     GL11.glAlphaFunc(516, 0.1F);
/* 53 */     GL11.glPopMatrix();
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\entities\RenderTaintPig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */