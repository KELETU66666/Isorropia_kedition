 package fr.wind_blade.isorropia.client.renderer;
 
 import fr.wind_blade.isorropia.client.libs.RenderEventHandler;
 import fr.wind_blade.isorropia.common.blocks.BlocksIS;
 import net.minecraft.block.Block;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.renderer.GlStateManager;
 import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
 import net.minecraft.client.renderer.texture.TextureMap;
 import net.minecraft.client.renderer.tileentity.TileEntityItemStackRenderer;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 
 @SideOnly(Side.CLIENT)
 public class RenderCustomItem extends TileEntityItemStackRenderer {
/* 18 */   public ItemCameraTransforms.TransformType transform = ItemCameraTransforms.TransformType.GUI;
 
   
   public void func_179022_a(ItemStack stack) {
/* 22 */     super.func_179022_a(stack);
/* 23 */     if (stack.func_77973_b() == Item.func_150898_a((Block)BlocksIS.blockJarSoul)) {
/* 24 */       GlStateManager.func_179094_E();
/* 25 */       GlStateManager.func_179137_b(0.5D, 0.5D, 0.4D);
/* 26 */       Minecraft.func_71410_x().func_110434_K().func_110577_a(TextureMap.field_110575_b);
/* 27 */       Minecraft.func_71410_x().func_175599_af().func_180454_a(stack, RenderEventHandler.jar_soul);
/* 28 */       GlStateManager.func_179121_F();
     } 
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\RenderCustomItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */