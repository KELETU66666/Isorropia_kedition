 package fr.wind_blade.isorropia.common.entities;
 
 import net.minecraft.entity.passive.EntitySheep;
 import net.minecraft.item.EnumDyeColor;
 import net.minecraft.world.World;
 
 
 
 
 public class EntityChromaticSheep
   extends EntitySheep
 {
   public EntityChromaticSheep(World world) {
/* 14 */     super(world);
   }
 
   
   public void func_70636_d() {
/* 19 */     if (!this.field_70170_p.field_72995_K && this.field_70173_aa % 30 == 0) {
/* 20 */       EnumDyeColor color = func_175509_cj();
/* 21 */       if (color.func_176765_a() >= 15) {
/* 22 */         color = EnumDyeColor.func_176764_b(0);
       } else {
/* 24 */         color = EnumDyeColor.func_176764_b(color.func_176765_a() + 1);
       } 
/* 26 */       func_175512_b(color);
     } 
/* 28 */     super.func_70636_d();
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityChromaticSheep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */