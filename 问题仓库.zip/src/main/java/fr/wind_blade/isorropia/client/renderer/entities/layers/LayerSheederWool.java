 package fr.wind_blade.isorropia.client.renderer.entities.layers;
 
 import fr.wind_blade.isorropia.client.renderer.entities.RenderSheeder;
 import fr.wind_blade.isorropia.common.entities.EntitySheeder;
 import net.minecraft.client.renderer.GlStateManager;
 import net.minecraft.client.renderer.entity.layers.LayerRenderer;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.util.ResourceLocation;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 
 @SideOnly(Side.CLIENT)
 public class LayerSheederWool implements LayerRenderer<EntitySheeder> {
/* 15 */   public static final ResourceLocation SPIDER_EYES = new ResourceLocation("isorropia", "textures/entity/sheederoverlay.png");
   
   private final RenderSheeder sheederRenderer;
   
   public LayerSheederWool(RenderSheeder sheederRendererIn) {
/* 20 */     this.sheederRenderer = sheederRendererIn;
   }
 
 
   
   public void doRenderLayer(EntitySheeder sheeder, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 26 */     if (!sheeder.getSheared()) {
/* 27 */       if (sheeder.func_82150_aj()) {
/* 28 */         GlStateManager.func_179132_a(false);
       } else {
/* 30 */         GlStateManager.func_179132_a(true);
       } 
       
/* 33 */       GlStateManager.func_179137_b(0.0D, -0.01D, -0.01D);
/* 34 */       GlStateManager.func_179139_a(1.01D, 1.01D, 1.02D);
/* 35 */       this.sheederRenderer.func_110776_a(SPIDER_EYES);
/* 36 */       this.sheederRenderer.func_177087_b().func_78088_a((Entity)sheeder, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
     } 
   }
 
 
   
   public boolean func_177142_b() {
/* 43 */     return true;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\entities\layers\LayerSheederWool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */