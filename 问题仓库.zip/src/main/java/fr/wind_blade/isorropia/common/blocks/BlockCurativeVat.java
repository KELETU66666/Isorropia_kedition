/*     */ package fr.wind_blade.isorropia.common.blocks;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.tiles.TileVat;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileVatConnector;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyEnum;
/*     */ import net.minecraft.block.state.BlockStateContainer;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.IStringSerializable;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockCurativeVat
/*     */   extends Block
/*     */   implements ITileEntityProvider, IBlockRegistry {
/*  28 */   public static final PropertyEnum<Type> VARIANT = PropertyEnum.func_177709_a("variant", Type.class);
/*     */   
/*     */   public BlockCurativeVat() {
/*  31 */     super(Material.field_151575_d);
/*  32 */     this.field_149784_t = 8;
/*  33 */     func_149711_c(2.0F);
/*     */   }
/*     */   
/*     */   public static TileVat getMaster(World world, BlockPos pos) {
/*  37 */     return getMaster(world, world.func_180495_p(pos), pos);
/*     */   }
/*     */   
/*     */   public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
/*     */     TileVat tileVat;
/*  42 */     TileEntity tile = worldIn.func_175625_s(pos);
/*     */     
/*  44 */     switch (func_176201_c(state)) {
/*     */       case 1:
/*  46 */         if (!(tile instanceof TileVat)) {
/*     */           break;
/*     */         }
/*  49 */         ((TileVat)tile).destroyMultiBlock();
/*     */         break;
/*     */       
/*     */       case 2:
/*  53 */         tile = worldIn.func_175625_s(pos.func_177981_b(3));
/*  54 */         if (!(tile instanceof TileVat)) {
/*     */           break;
/*     */         }
/*  57 */         ((TileVat)tile).destroyMultiBlock();
/*     */         break;
/*     */       
/*     */       default:
/*  61 */         tileVat = getMaster(worldIn, state, pos);
/*  62 */         if (!(tileVat instanceof TileVat)) {
/*     */           break;
/*     */         }
/*  65 */         if (tileVat != null)
/*  66 */           tileVat.destroyMultiBlock(); 
/*     */         break;
/*     */     } 
/*  69 */     super.func_180663_b(worldIn, pos, state);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
/*  76 */     if (hand != EnumHand.MAIN_HAND) {
/*  77 */       return super.func_180639_a(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
/*     */     }
/*  79 */     TileEntity te = worldIn.func_175625_s(pos);
/*  80 */     if (te instanceof TileVat) {
/*  81 */       TileVat tileVat = (TileVat)worldIn.func_175625_s(pos);
/*  82 */       return tileVat.onBlockRigthClick(playerIn, facing, true);
/*     */     } 
/*  84 */     TileVat vat = getMaster(worldIn, pos);
/*  85 */     if (vat != null) {
/*  86 */       return vat.onBlockRigthClick(playerIn, facing, false);
/*     */     }
/*     */     
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Item func_180660_a(IBlockState state, Random rand, int fortune) {
/*  94 */     return Items.field_190931_a;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World worldIn, int meta) {
/*  99 */     switch (meta) {
/*     */       case 1:
/* 101 */         return (TileEntity)new TileVat();
/*     */       case 3:
/* 103 */         return (TileEntity)new TileVatConnector();
/*     */     } 
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/* 111 */     return func_176223_P().func_177226_a((IProperty)VARIANT, Type.getStateFromMeta(meta));
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 116 */     return ((Type)state.func_177229_b((IProperty)VARIANT)).getMetadata();
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockStateContainer func_180661_e() {
/* 121 */     return new BlockStateContainer(this, new IProperty[] { (IProperty)VARIANT });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176225_a(IBlockState state, IBlockAccess blockAccess, BlockPos pos, EnumFacing side) {
/* 126 */     return !(func_176201_c(state) == Type.PLACEHOLDER.getMetadata() || 
/* 127 */       func_176201_c(state) == Type.CONNECTOR.getMetadata());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRenderInLayer(IBlockState state, BlockRenderLayer layer) {
/* 132 */     return (layer == BlockRenderLayer.TRANSLUCENT || layer == BlockRenderLayer.SOLID);
/*     */   }
/*     */   
/*     */   public boolean isFullyOpaque(IBlockState state) {
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149721_r(IBlockState state) {
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c(IBlockState state) {
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149637_q(IBlockState state) {
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149730_j(IBlockState state) {
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149751_l(IBlockState state) {
/* 161 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isVisuallyOpaque() {
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d(IBlockState state) {
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static TileVat getMaster(World world, IBlockState state, BlockPos pos) {
/* 176 */     for (BlockPos pos2 : BlockPos.func_191531_b(pos.func_177958_n() - 1, pos.func_177956_o(), pos.func_177952_p() - 1, pos.func_177958_n() + 1, pos
/* 177 */         .func_177956_o(), pos.func_177952_p() + 1)) {
/* 178 */       IBlockState state2 = world.func_180495_p(pos2);
/* 179 */       if (state2.func_177230_c() instanceof BlockLiquidVat) {
/* 180 */         state2 = world.func_180495_p(pos2.func_177984_a());
/* 181 */         TileEntity te = world.func_175625_s(pos2.func_177984_a());
/* 182 */         if (te instanceof TileVat) {
/* 183 */           return (TileVat)te;
/*     */         }
/* 185 */         state2 = world.func_180495_p(pos2.func_177981_b(2));
/* 186 */         te = world.func_175625_s(pos2.func_177981_b(2));
/* 187 */         if (te instanceof TileVat)
/* 188 */           return (TileVat)te; 
/*     */         continue;
/*     */       } 
/* 191 */       if (state2.func_177230_c() instanceof BlockCurativeVat) {
/* 192 */         if (((BlockCurativeVat)state2.func_177230_c()).func_176201_c(state2) == 1) {
/* 193 */           TileEntity te = world.func_175625_s(pos2);
/* 194 */           if (te instanceof TileVat)
/* 195 */             return (TileVat)te;  continue;
/*     */         } 
/* 197 */         if (((BlockCurativeVat)state2.func_177230_c()).func_176201_c(state2) == 2) {
/* 198 */           TileEntity te = world.func_175625_s(pos2.func_177981_b(3));
/* 199 */           if (te instanceof TileVat) {
/* 200 */             return (TileVat)te;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInCreativeTabs() {
/* 210 */     return false;
/*     */   }
/*     */   
/*     */   public enum Type
/*     */     implements IStringSerializable {
/* 215 */     PLACEHOLDER(0, "placeholder"), TOP(1, "top"), BOTTOM(2, "bottom"), CONNECTOR(3, "connector"); private final int metadata;
/*     */     private final String name;
/* 217 */     private static final Type[] METADATA = new Type[(values()).length];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/* 249 */       Type[] var0 = values();
/* 250 */       int var1 = var0.length;
/*     */       
/* 252 */       for (int var2 = 0; var2 < var1; var2++) {
/* 253 */         Type var3 = var0[var2];
/* 254 */         METADATA[var3.getMetadata()] = var3;
/*     */       } 
/*     */     }
/*     */     
/*     */     Type(int metadata, String name) {
/*     */       this.metadata = metadata;
/*     */       this.name = name;
/*     */     }
/*     */     
/*     */     public String func_176610_l() {
/*     */       return this.name;
/*     */     }
/*     */     
/*     */     public int getMetadata() {
/*     */       return this.metadata;
/*     */     }
/*     */     
/*     */     public String toString() {
/*     */       return this.name;
/*     */     }
/*     */     
/*     */     public static Type getStateFromMeta(int metadata) {
/*     */       if (metadata < 0 || metadata >= METADATA.length)
/*     */         metadata = 0; 
/*     */       return METADATA[metadata];
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockCurativeVat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */