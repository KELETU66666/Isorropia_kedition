 package fr.wind_blade.isorropia.client.renderer.entities.layers;
 
 import fr.wind_blade.isorropia.client.renderer.entities.RenderTaintPig;
 import fr.wind_blade.isorropia.common.entities.EntityTaintPig;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.model.ModelPig;
 import net.minecraft.client.renderer.entity.layers.LayerRenderer;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.util.ResourceLocation;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import org.lwjgl.opengl.GL11;
 
 @SideOnly(Side.CLIENT)
 public class LayerTaintPigBorder
   implements LayerRenderer<EntityTaintPig> {
/* 18 */   private static final ResourceLocation pigEyesTextures = new ResourceLocation("isorropia", "textures/entity/taintfeeder_eyes.png");
   
/* 20 */   private static final ModelPig border = new ModelPig(0.5F);
   private final RenderTaintPig taintRender;
   
   public LayerTaintPigBorder(RenderTaintPig renderTaintPig) {
/* 24 */     this.taintRender = renderTaintPig;
   }
 
 
   
   public void doRenderLayer(EntityTaintPig entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 30 */     float f = (float)Math.sin(Math.toRadians((entitylivingbaseIn.field_70173_aa % 45)) * 8.0D);
/* 31 */     (Minecraft.func_71410_x()).field_71446_o.func_110577_a(pigEyesTextures);
/* 32 */     GL11.glEnable(3042);
/* 33 */     GL11.glDisable(3008);
/* 34 */     GL11.glBlendFunc(770, 771);
     
/* 36 */     if (entitylivingbaseIn.func_82150_aj()) {
/* 37 */       GL11.glDepthMask(false);
     } else {
/* 39 */       GL11.glDepthMask(true);
     } 
/* 41 */     char c0 = '';
/* 42 */     int j = 61680;
/* 43 */     int k = 0;
/* 44 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.32F + 0.32F * f);
/* 45 */     border.func_178686_a(this.taintRender.func_177087_b());
/* 46 */     border.func_78088_a((Entity)entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
/* 47 */     GL11.glDisable(3042);
/* 48 */     GL11.glEnable(3008);
   }
 
   
   public boolean func_177142_b() {
/* 53 */     return true;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\entities\layers\LayerTaintPigBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */