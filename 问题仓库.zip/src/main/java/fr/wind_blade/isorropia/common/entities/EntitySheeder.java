/*     */ package fr.wind_blade.isorropia.common.entities;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAIEatGrass;
/*     */ import net.minecraft.entity.ai.EntityAILeapAtTarget;
/*     */ import net.minecraft.entity.ai.EntityAILookIdle;
/*     */ import net.minecraft.entity.ai.EntityAIPanic;
/*     */ import net.minecraft.entity.ai.EntityAISwimming;
/*     */ import net.minecraft.entity.ai.EntityAITempt;
/*     */ import net.minecraft.entity.ai.EntityAIWander;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.monster.EntitySpider;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ 
/*     */ public class EntitySheeder
/*     */   extends EntitySpider
/*     */   implements IShearable {
/*     */   private int sheepTimer;
/*  34 */   private static final DataParameter<Boolean> SHEER = EntityDataManager.func_187226_a(EntitySheeder.class, DataSerializers.field_187198_h);
/*     */ 
/*     */   
/*     */   public EntitySheeder(World p_i1743_1_) {
/*  38 */     super(p_i1743_1_);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70088_a() {
/*  43 */     super.func_70088_a();
/*  44 */     this.field_70180_af.func_187214_a(SHEER, Boolean.valueOf(false));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  49 */     this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/*  50 */     this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIPanic((EntityCreature)this, 0.5D));
/*  51 */     this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAITempt((EntityCreature)this, 0.44D, Items.field_151015_O, false));
/*  52 */     this.field_70714_bg.func_75776_a(3, (EntityAIBase)new EntityAIEatGrass((EntityLiving)this));
/*  53 */     this.field_70714_bg.func_75776_a(4, (EntityAIBase)new EntityAILeapAtTarget((EntityLiving)this, 0.4F));
/*  54 */     this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIWander((EntityCreature)this, 0.8D));
/*  55 */     this.field_70714_bg.func_75776_a(6, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 8.0F));
/*  56 */     this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/*  61 */     super.func_70071_h_();
/*  62 */     if (this.field_70128_L && !this.field_70170_p.field_72995_K && this.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL && 
/*  63 */       func_110143_aJ() > 0.0F) {
/*  64 */       this.field_70128_L = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70636_d() {
/*  70 */     if (this.field_70170_p.field_72995_K) {
/*  71 */       this.sheepTimer = Math.max(0, this.sheepTimer - 1);
/*     */     }
/*  73 */     super.func_70636_d();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ItemStack> onSheared(ItemStack item, IBlockAccess world, BlockPos pos, int fortune) {
/*  78 */     ArrayList<ItemStack> ret = new ArrayList<>();
/*  79 */     setSheared(true);
/*  80 */     for (int i = 2 + this.field_70146_Z.nextInt(4), j = 0; j < i; j++)
/*  81 */       ret.add(new ItemStack(Items.field_151007_F, 1, 0)); 
/*  82 */     func_184185_a(SoundEvents.field_187763_eJ, 1.0F, 1.0F);
/*  83 */     return ret;
/*     */   }
/*     */   
/*     */   public void setSheared(boolean isShearing) {
/*  87 */     this.field_70180_af.func_187227_b(SHEER, Boolean.valueOf(isShearing));
/*     */   }
/*     */   
/*     */   public boolean getSheared() {
/*  91 */     return ((Boolean)this.field_70180_af.func_187225_a(SHEER)).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70615_aA() {
/*  96 */     setSheared(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShearable(ItemStack item, IBlockAccess world, BlockPos pos) {
/* 101 */     return (!item.func_190926_b() && item.func_77973_b() == Items.field_151097_aZ && !getSheared());
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntitySheeder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */