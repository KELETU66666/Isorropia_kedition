 package fr.wind_blade.isorropia.common.libs.research.recipes;
 
 import fr.wind_blade.isorropia.Isorropia;
 import fr.wind_blade.isorropia.common.Common;
 import fr.wind_blade.isorropia.common.IsorropiaAPI;
 import fr.wind_blade.isorropia.common.capabilities.LivingBaseCapability;
 import fr.wind_blade.isorropia.common.tiles.TileVat;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.item.ItemStack;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.util.ResourceLocation;
 import net.minecraftforge.fml.common.FMLCommonHandler;
 
 public class OrganCurativeInfusionRecipe
   extends CurativeInfusionRecipe {
   protected final Organ organTarget;
   
   public OrganCurativeInfusionRecipe(Builder<? extends Builder<?>> builder) {
/* 20 */     super(builder);
/* 21 */     this.organTarget = builder.organTarget;
/* 22 */     if (this.organTarget == null) {
/* 23 */       Isorropia.logger.error("Organ Curative Infusion Recipe can't have a null organ target");
/* 24 */       FMLCommonHandler.instance().exitJava(1, false);
     } 
   }
 
   
   public void applyWithCheat(EntityPlayer player, EntityLivingBase target, ItemStack stack) {
/* 30 */     super.applyWithCheat(player, target, stack);
/* 31 */     LivingBaseCapability cap = Common.getCap(target);
/* 32 */     NBTTagCompound tag = (NBTTagCompound)cap.infusions.get(new ResourceLocation("isorropia", "organs"));
     
/* 34 */     tag = (tag == null) ? new NBTTagCompound() : tag;
/* 35 */     tag.func_74778_a(this.organTarget.registryName.toString(), ((ResourceLocation)IsorropiaAPI.creatureInfusionRecipesLocal.get(this)).toString());
/* 36 */     cap.infusions.put(new ResourceLocation("isorropia", "organs"), tag);
   }
 
   
   public void onInfusionFinish(TileVat vat) {
/* 41 */     super.onInfusionFinish(vat);
/* 42 */     LivingBaseCapability cap = Common.getCap(vat.getEntityContained());
/* 43 */     NBTTagCompound tag = (NBTTagCompound)cap.infusions.get(new ResourceLocation("isorropia", "organs"));
     
/* 45 */     tag = (tag == null) ? new NBTTagCompound() : tag;
/* 46 */     tag.func_74778_a(this.organTarget.registryName.toString(), ((ResourceLocation)IsorropiaAPI.creatureInfusionRecipesLocal.get(vat.getRecipe())).toString());
/* 47 */     cap.infusions.put(new ResourceLocation("isorropia", "organs"), tag);
   }
   
   public Organ getOrganTarget() {
/* 51 */     return this.organTarget;
   }
 
   
   public static class Organ
   {
     public final ResourceLocation registryName;
/* 58 */     public static Organ HEART = new Organ(new ResourceLocation("isorropia", "heart"));
/* 59 */     public static Organ SKIN = new Organ(new ResourceLocation("isorropia", "skin"));
     
     public Organ(ResourceLocation registryName) {
/* 62 */       this.registryName = registryName;
     }
   }
   
   public static class Builder<T extends Builder<T>>
     extends CurativeInfusionRecipe.Builder<T> {
/* 68 */     protected OrganCurativeInfusionRecipe.Organ organTarget = null;
     
     public T withOrganTarget(OrganCurativeInfusionRecipe.Organ organTarget) {
/* 71 */       this.organTarget = organTarget;
/* 72 */       return self();
     }
 
     
     public CurativeInfusionRecipe build() {
/* 77 */       return new OrganCurativeInfusionRecipe(this);
     }
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\research\recipes\OrganCurativeInfusionRecipe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */