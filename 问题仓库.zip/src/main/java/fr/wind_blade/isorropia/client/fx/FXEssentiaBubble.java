 package fr.wind_blade.isorropia.client.fx;
 
 import java.awt.Color;
 import net.minecraft.client.particle.Particle;
 import net.minecraft.client.renderer.BufferBuilder;
 import net.minecraft.entity.Entity;
 import net.minecraft.util.math.MathHelper;
 import net.minecraft.world.World;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import org.lwjgl.opengl.GL11;
 
 
 @SideOnly(Side.CLIENT)
 public class FXEssentiaBubble
   extends Particle
 {
/* 18 */   private int count = 0;
/* 19 */   private int delay = 0;
/* 20 */   public int particle = 24;
 
   
   public FXEssentiaBubble(World par1World, double par2, double par4, double par6, int count, int color, float scale, int delay) {
/* 24 */     super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
/* 25 */     this.particleBlue = 0.6F;
/* 26 */     this.particleGreen = 0.6F;
/* 27 */     this.particleRed = 0.6F;
/* 28 */     this.field_70544_f = (MathHelper.func_76126_a(count / 2.0F) * 0.1F + 1.0F) * scale;
/* 29 */     this.delay = delay;
/* 30 */     this.count = count;
/* 31 */     this.field_70547_e = 20 + this.field_187136_p.nextInt(20);
/* 32 */     this.field_187130_j = (0.025F + MathHelper.func_76126_a(count / 3.0F) * 0.002F);
/* 33 */     this.field_187131_k = 0.0D;
/* 34 */     this.field_187129_i = 0.0D;
/* 35 */     Color c = new Color(color);
/* 36 */     float mr = c.getRed() / 255.0F * 0.2F;
/* 37 */     float mg = c.getGreen() / 255.0F * 0.2F;
/* 38 */     float mb = c.getBlue() / 255.0F * 0.2F;
/* 39 */     this.particleRed = c.getRed() / 255.0F - mr + this.field_187136_p.nextFloat() * mr;
/* 40 */     this.particleGreen = c.getGreen() / 255.0F - mg + this.field_187136_p.nextFloat() * mg;
/* 41 */     this.particleBlue = c.getBlue() / 255.0F - mb + this.field_187136_p.nextFloat() * mb;
/* 42 */     this.field_70545_g = 0.2F;
/* 43 */     this.field_190017_n = false;
   }
 
 
   
   public void func_180434_a(BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
/* 49 */     if (this.delay > 0) {
       return;
     }
     
/* 53 */     float t2 = 0.5625F;
/* 54 */     float t3 = 0.625F;
/* 55 */     float t4 = 0.0625F;
/* 56 */     float t5 = 0.125F;
/* 57 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
/* 58 */     int part = this.particle + this.field_70546_d % 16;
/* 59 */     float s = MathHelper.func_76126_a((this.field_70546_d - this.count) / 5.0F) * 0.25F + 1.0F;
/* 60 */     float var12 = 0.1F * this.field_70544_f * s;
/* 61 */     float var13 = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * partialTicks - field_70556_an);
/* 62 */     float var14 = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * partialTicks - field_70554_ao);
/* 63 */     float var15 = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * partialTicks - field_70555_ap);
/* 64 */     float var16 = 1.0F;
     
/* 66 */     buffer.func_181666_a(this.particleRed * var16, this.particleGreen * var16, this.particleBlue * var16, 0.5F);
     
/* 68 */     buffer.func_181662_b((var13 - rotationX * var12 - rotationXY * var12), (var14 - rotationZ * var12), (var15 - rotationYZ * var12 - rotationXZ * var12))
/* 69 */       .func_187315_a(t2, t5).func_181675_d();
/* 70 */     buffer.func_181662_b((var13 - rotationX * var12 + rotationXY * var12), (var14 + rotationZ * var12), (var15 - rotationYZ * var12 + rotationXZ * var12))
/* 71 */       .func_187315_a(t3, t5).func_181675_d();
/* 72 */     buffer.func_181662_b((var13 + rotationX * var12 + rotationXY * var12), (var14 + rotationZ * var12), (var15 + rotationYZ * var12 + rotationXZ * var12))
/* 73 */       .func_187315_a(t2, t4).func_181675_d();
/* 74 */     buffer.func_181662_b((var13 + rotationX * var12 - rotationXY * var12), (var14 - rotationZ * var12), (var15 + rotationXY * var12 - rotationXZ * var12))
/* 75 */       .func_187315_a(t2, t4).func_181675_d();
   }
 
   
   public int func_70537_b() {
/* 80 */     return 1;
   }
 
   
   public void func_189213_a() {
/* 85 */     this.field_187123_c = this.field_187126_f;
/* 86 */     this.field_187124_d = this.field_187127_g;
/* 87 */     this.field_187125_e = this.field_187128_h;
/* 88 */     if (this.delay > 0) {
/* 89 */       this.delay--;
       return;
     } 
/* 92 */     if (this.field_70546_d++ >= this.field_70547_e) {
/* 93 */       func_187112_i();
       return;
     } 
/* 96 */     this.field_187130_j += 0.00125D;
/* 97 */     this.field_70544_f *= 1.05F;
/* 98 */     func_187110_a(this.field_187129_i, this.field_187130_j, this.field_187131_k);
/* 99 */     this.field_187130_j *= 0.985D;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\fx\FXEssentiaBubble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */