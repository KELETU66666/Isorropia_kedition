 package fr.wind_blade.isorropia.common.network;
 import fr.wind_blade.isorropia.common.IsorropiaAPI;
 import fr.wind_blade.isorropia.common.lenses.Lens;
 import io.netty.buffer.ByteBuf;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.entity.EntityPlayerSP;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
 import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import net.minecraftforge.registries.IForgeRegistryEntry;
 
 public class LensRemoveMessage implements IMessage {
/* 16 */   private Lens rightLens = null;
/* 17 */   private Lens leftLens = null;
 
 
 
 
   
   public LensRemoveMessage(Lens rightLens, Lens leftLens) {
/* 24 */     this.rightLens = rightLens;
/* 25 */     this.leftLens = leftLens;
   }
 
   
   public void fromBytes(ByteBuf buf) {
/* 30 */     if (buf.readBoolean())
/* 31 */       this.rightLens = (Lens)IsorropiaAPI.lensRegistry.getValue(buf.readInt()); 
/* 32 */     if (buf.readBoolean()) {
/* 33 */       this.leftLens = (Lens)IsorropiaAPI.lensRegistry.getValue(buf.readInt());
     }
   }
 
   
   public void toBytes(ByteBuf buf) {
/* 39 */     buf.writeBoolean((this.rightLens != null));
/* 40 */     if (this.rightLens != null)
/* 41 */       buf.writeInt(IsorropiaAPI.lensRegistry.getID((IForgeRegistryEntry)this.rightLens)); 
/* 42 */     buf.writeBoolean((this.leftLens != null));
/* 43 */     if (this.leftLens != null)
/* 44 */       buf.writeInt(IsorropiaAPI.lensRegistry.getID((IForgeRegistryEntry)this.leftLens)); 
   }
   
   public LensRemoveMessage() {}
   
   public static class Handler
     implements IMessageHandler<LensRemoveMessage, IMessage>
   {
     @SideOnly(Side.CLIENT)
     public IMessage onMessage(LensRemoveMessage message, MessageContext ctx) {
/* 54 */       Minecraft.func_71410_x().func_152344_a(() -> {
             EntityPlayerSP player = (Minecraft.func_71410_x()).field_71439_g;
             if (message.rightLens != null)
               message.rightLens.handleRemoval(player.field_70170_p, (EntityPlayer)player); 
             if (message.leftLens != null)
               message.leftLens.handleRemoval(player.field_70170_p, (EntityPlayer)player); 
           });
/* 61 */       return null;
     }
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\network\LensRemoveMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */