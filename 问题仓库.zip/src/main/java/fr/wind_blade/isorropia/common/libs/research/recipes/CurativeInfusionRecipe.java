/*     */ package fr.wind_blade.isorropia.common.libs.research.recipes;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.IsorropiaAPI;
/*     */ import fr.wind_blade.isorropia.common.capabilities.LivingBaseCapability;
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import fr.wind_blade.isorropia.common.libs.celestial.CelestialBody;
/*     */ import fr.wind_blade.isorropia.common.libs.celestial.ICelestialBody;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileVat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.passive.EntityTameable;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.RecipeMatcher;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ import thaumcraft.api.ThaumcraftInvHelper;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.capabilities.ThaumcraftCapabilities;
/*     */ import thaumcraft.api.crafting.InfusionRecipe;
/*     */ 
/*     */ public class CurativeInfusionRecipe
/*     */   extends InfusionRecipe
/*     */ {
/*     */   protected final Predicate<EntityLivingBase> predicate;
/*     */   protected final ICelestialBody celestialBody;
/*     */   protected final int celestialAura;
/*     */   protected final float vis;
/*     */   protected final float fluxRejection;
/*     */   protected final NBTTagCompound informationNBT;
/*     */   protected final NonNullList<Ingredient> optionalComponents;
/*     */   
/*     */   protected CurativeInfusionRecipe(Builder builder) {
/*  41 */     super(builder.knwoledgeRequirement, builder.fakeItemOuput, builder.instability, builder.aspects, builder.fakeItemInput, builder.components
/*  42 */         .toArray());
/*     */     
/*  44 */     this.predicate = builder.predicate;
/*  45 */     this.aspects = builder.aspects;
/*  46 */     this.instability = builder.instability;
/*  47 */     this.celestialBody = builder.celestialBody;
/*  48 */     this.celestialAura = builder.celestialAura;
/*  49 */     this.vis = builder.aura;
/*  50 */     this.fluxRejection = builder.fluxRejection;
/*  51 */     this.informationNBT = builder.informationNBT;
/*  52 */     this.optionalComponents = builder.optionalComponents;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(List<ItemStack> input, EntityLivingBase entity, World world, EntityPlayer player, TileVat vat) {
/*  58 */     if (!this.research.isEmpty() && !ThaumcraftCapabilities.knowsResearch(player, new String[] { this.research })) {
/*  59 */       return false;
/*     */     }
/*  61 */     if (!this.predicate.test(entity)) {
/*  62 */       return false;
/*     */     }
/*  64 */     return (RecipeMatcher.findMatches(input, (List)getComponents()) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean areItemStacksEqual(ItemStack stack0, ItemStack stack1, boolean fuzzy) {
/*  84 */     if (stack0.func_190926_b() && stack1.func_190926_b()) {
/*  85 */       return true;
/*     */     }
/*     */     
/*  88 */     if (stack0.func_190926_b() || stack1.func_190926_b()) {
/*  89 */       return false;
/*     */     }
/*     */     
/*  92 */     boolean t1 = ThaumcraftInvHelper.areItemStackTagsEqualForCrafting(stack0, stack1);
/*  93 */     if (!t1) {
/*  94 */       return false;
/*     */     }
/*  96 */     if (fuzzy) {
/*  97 */       int[] od = OreDictionary.getOreIDs(stack0);
/*  98 */       if (od.length > 0) {
/*  99 */         List<ItemStack> ores = new ArrayList<>();
/* 100 */         List<String> oresName = new ArrayList<>();
/*     */         
/* 102 */         for (int id : od) {
/* 103 */           oresName.add(OreDictionary.getOreName(id));
/*     */         }
/* 105 */         if (ThaumcraftInvHelper.containsMatch(false, new ItemStack[] { stack1 }, ores)) {
/* 106 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 110 */     boolean damage = (stack0.func_77952_i() == stack1.func_77952_i() || stack1.func_77952_i() == 32767);
/* 111 */     return (stack0.func_77973_b() == stack1.func_77973_b() && damage && stack0.func_190916_E() <= stack0.func_77976_d());
/*     */   }
/*     */ 
/*     */   
/*     */   public AspectList getCurrentAspect(EntityPlayer infuser, World worldIn, EntityLivingBase base, float stability, float totalInstability, List<Ingredient> optionalsIngredientsInfused) {
/* 116 */     return getAspects();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyWithCheat(EntityPlayer player, EntityLivingBase target, ItemStack stack) {
/* 123 */     if (target instanceof EntityTameable)
/* 124 */       ((EntityTameable)target).func_193101_c(player); 
/* 125 */     if (getInformationNBT() != null) {
/* 126 */       LivingBaseCapability cap = Common.getCap(target);
/*     */       
/* 128 */       cap.infusions.put(IsorropiaAPI.creatureInfusionRecipesLocal.get(this), getInformationNBT());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onInfusionFinish(TileVat vat) {
/* 133 */     EntityLivingBase entity = vat.getEntityContained();
/*     */     
/* 135 */     if (entity instanceof EntityTameable)
/* 136 */       ((EntityTameable)entity).func_193101_c(vat.getRecipePlayer()); 
/* 137 */     if (vat.getRecipe().getInformationNBT() != null) {
/* 138 */       LivingBaseCapability cap = Common.getCap(entity);
/*     */       
/* 140 */       cap.infusions.put(IsorropiaAPI.creatureInfusionRecipesLocal.get(this), getInformationNBT());
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getInstability() {
/* 145 */     return this.instability;
/*     */   }
/*     */   
/*     */   public ICelestialBody getCelestialBody() {
/* 149 */     return this.celestialBody;
/*     */   }
/*     */   
/*     */   public float getVis() {
/* 153 */     return this.vis;
/*     */   }
/*     */   
/*     */   public float getFluxRejection() {
/* 157 */     return this.fluxRejection;
/*     */   }
/*     */   
/*     */   public Predicate<EntityLivingBase> getPredicate() {
/* 161 */     return this.predicate;
/*     */   }
/*     */   
/*     */   public NBTTagCompound getInformationNBT() {
/* 165 */     return this.informationNBT;
/*     */   }
/*     */   
/*     */   public int getCelestialAura() {
/* 169 */     return this.celestialAura;
/*     */   }
/*     */   
/*     */   public NonNullList<Ingredient> getOptionalComponents() {
/* 173 */     return this.optionalComponents;
/*     */   }
/*     */   
/*     */   public static class Builder<T extends Builder<T>> {
/*     */     protected static final Predicate<EntityLivingBase> DEFAULT_PREDICATE;
/* 178 */     protected static final Ingredient DEFAULT_FAKE_INGREDIENT = Ingredient.func_193367_a(ItemsIS.itemCat); static {
/* 179 */       DEFAULT_PREDICATE = (entity -> entity instanceof EntityLivingBase);
/*     */     }
/* 181 */     protected Predicate<EntityLivingBase> predicate = DEFAULT_PREDICATE;
/*     */     protected String knwoledgeRequirement;
/*     */     protected AspectList aspects;
/*     */     protected int instability;
/*     */     protected NonNullList<Ingredient> components;
/* 186 */     protected ICelestialBody celestialBody = CelestialBody.NONE;
/*     */     
/*     */     protected int celestialAura;
/*     */     protected float aura;
/*     */     protected float fluxRejection;
/*     */     protected NBTTagCompound informationNBT;
/*     */     protected NonNullList<Ingredient> optionalComponents;
/* 193 */     protected Ingredient fakeItemInput = DEFAULT_FAKE_INGREDIENT;
/* 194 */     protected ItemStack fakeItemOuput = new ItemStack(ItemsIS.itemCat);
/*     */     
/*     */     public Builder() {
/* 197 */       this.knwoledgeRequirement = "WIP_CREATUREINFUSION";
/* 198 */       this.aspects = new AspectList();
/* 199 */       this.components = NonNullList.func_191196_a();
/* 200 */       this.optionalComponents = NonNullList.func_191196_a();
/* 201 */       this.informationNBT = null;
/*     */     }
/*     */     
/*     */     public T withKnowledgeRequirement(String knowledge) {
/* 205 */       this.knwoledgeRequirement = knowledge;
/* 206 */       return self();
/*     */     }
/*     */     
/*     */     public T withPredicate(Predicate<EntityLivingBase> predicate) {
/* 210 */       if (predicate != null)
/* 211 */         this.predicate = predicate; 
/* 212 */       return self();
/*     */     }
/*     */     
/*     */     public T withAspects(AspectList aspects) {
/* 216 */       this.aspects = aspects;
/* 217 */       return self();
/*     */     }
/*     */     
/*     */     public T withInstability(int instability) {
/* 221 */       this.instability = instability;
/* 222 */       return self();
/*     */     }
/*     */     
/*     */     public T withComponents(Ingredient... components) {
/* 226 */       this.components.addAll(Arrays.asList(components));
/* 227 */       return self();
/*     */     }
/*     */     
/*     */     public T withOptionalsComponents(Ingredient... components) {
/* 231 */       this.optionalComponents.addAll(Arrays.asList(components));
/* 232 */       return self();
/*     */     }
/*     */     
/*     */     public T withFakeIngredients(Ingredient io) {
/* 236 */       return withFakeIngredients(io, io.func_193365_a()[0]);
/*     */     }
/*     */     
/*     */     public T withFakeIngredients(Ingredient fakeInput, ItemStack fakeOutput) {
/* 240 */       this.fakeItemInput = fakeInput;
/* 241 */       this.fakeItemOuput = fakeOutput;
/* 242 */       return self();
/*     */     }
/*     */     
/*     */     public T withCelestialAura(ICelestialBody celestialBody, int auraAmount) {
/* 246 */       this.celestialBody = celestialBody;
/* 247 */       this.celestialAura = auraAmount;
/* 248 */       return self();
/*     */     }
/*     */     
/*     */     public T withFluxRejection(float fluxRejection) {
/* 252 */       this.fluxRejection = fluxRejection;
/* 253 */       return self();
/*     */     }
/*     */     
/*     */     public T withInformationNBT(NBTTagCompound nbt) {
/* 257 */       this.informationNBT = nbt;
/* 258 */       return self();
/*     */     }
/*     */     
/*     */     public T withVis(float visNeeded) {
/* 262 */       this.aura = visNeeded;
/* 263 */       return self();
/*     */     }
/*     */ 
/*     */     
/*     */     protected T self() {
/* 268 */       return (T)this;
/*     */     }
/*     */     
/*     */     public CurativeInfusionRecipe build() {
/* 272 */       return new CurativeInfusionRecipe(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\research\recipes\CurativeInfusionRecipe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */