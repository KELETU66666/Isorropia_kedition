 package fr.wind_blade.isorropia.common.entities.ai;
 
 import java.util.List;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLiving;
 import net.minecraft.entity.ai.EntityAIBase;
 import net.minecraft.entity.item.EntityItem;
 import net.minecraft.init.Blocks;
 import net.minecraft.init.Items;
 import net.minecraft.init.SoundEvents;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.util.math.AxisAlignedBB;
 
 
 
 
 
 public class EntityAIEatStone<T extends EntityLiving & IEatStone>
   extends EntityAIBase
 {
   private T eater;
   private Entity targetEntity;
   int count;
   
   public EntityAIEatStone(T eater) {
/* 27 */     this.count = 0;
/* 28 */     this.eater = eater;
   }
 
   
   public boolean func_75250_a() {
/* 33 */     return findItem();
   }
   
   private boolean findItem() {
/* 37 */     float dmod = 16.0F;
/* 38 */     List<Entity> targets = ((EntityLiving)this.eater).field_70170_p.func_72839_b((Entity)this.eater, new AxisAlignedBB(((EntityLiving)this.eater).field_70165_t - 16.0D, ((EntityLiving)this.eater).field_70163_u - 16.0D, ((EntityLiving)this.eater).field_70161_v - 16.0D, ((EntityLiving)this.eater).field_70165_t + 16.0D, ((EntityLiving)this.eater).field_70163_u + 16.0D, ((EntityLiving)this.eater).field_70161_v + 16.0D));
 
     
/* 41 */     if (targets.size() == 0) {
/* 42 */       return false;
     }
/* 44 */     for (Entity e : targets) {
/* 45 */       if (e instanceof EntityItem && ((EntityItem)e)
/* 46 */         .func_92059_d().func_77973_b() == Item.func_150898_a(Blocks.field_150347_e)) {
/* 47 */         double distance2 = e.func_70092_e(((EntityLiving)this.eater).field_70165_t, ((EntityLiving)this.eater).field_70163_u, ((EntityLiving)this.eater).field_70161_v);
/* 48 */         if (distance2 >= 256.0D) {
           continue;
         }
/* 51 */         this.targetEntity = e;
         break;
       } 
     } 
/* 55 */     return (this.targetEntity != null);
   }
   
   public boolean continueExecuting() {
/* 59 */     return (this.count-- > 0 && !this.eater.func_70661_as().func_75500_f() && this.targetEntity.func_70089_S());
   }
 
   
   public void func_75251_c() {
/* 64 */     this.count = 0;
/* 65 */     this.targetEntity = null;
/* 66 */     this.eater.func_70661_as().func_75499_g();
   }
 
   
   public void func_75246_d() {
/* 71 */     this.eater.func_70671_ap().func_75651_a(this.targetEntity, 30.0F, 30.0F);
/* 72 */     double dist = this.eater.func_70068_e(this.targetEntity);
/* 73 */     if (dist <= 2.0D) {
/* 74 */       pickUp();
     } else {
/* 76 */       this.eater.func_70661_as().func_75497_a(this.targetEntity, (this.eater.func_70689_ay() + 1.0F));
     } 
   }
   
   private void pickUp() {
/* 81 */     if (this.targetEntity instanceof EntityItem) {
/* 82 */       ItemStack entityItem = ((EntityItem)this.targetEntity).func_92059_d();
/* 83 */       if (!entityItem.func_190926_b() && entityItem.func_77973_b() != Items.field_190931_a) {
/* 84 */         ((IEatStone)this.eater).eatStone();
/* 85 */         entityItem.func_190918_g(1);
/* 86 */         if (((EntityItem)this.targetEntity).func_92059_d().func_190916_E() <= 0) {
/* 87 */           this.targetEntity.func_70106_y();
         }
/* 89 */         this.eater.func_184185_a(SoundEvents.field_187739_dZ, 0.2F, ((((EntityLiving)this.eater).field_70170_p.field_73012_v
/* 90 */             .nextFloat() - ((EntityLiving)this.eater).field_70170_p.field_73012_v.nextFloat()) * 0.7F + 1.0F) * 2.0F);
       } 
     } 
   }
 
   
   public void func_75249_e() {
/* 97 */     this.count = 500;
/* 98 */     this.eater.func_70661_as().func_75497_a(this.targetEntity, (this.eater.func_70689_ay() + 1.0F));
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\ai\EntityAIEatStone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */