 package fr.wind_blade.isorropia.common.libs.helpers;
 
 import net.minecraft.entity.Entity;
 
 
 
 
 
 public class IRMathHelper
 {
   public static double getEuclidean(double posX, double posY, double posZ, double targetX, double targetY, double targetZ) {
/* 12 */     return Math.sqrt(Math.pow(posX - targetX, 2.0D) + Math.pow(posY - targetY, 2.0D));
   }
   
   public static double getTchebychevDistance(Entity entity, Entity target) {
/* 16 */     return getTchebychevDistance(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, target.field_70165_t, target.field_70163_u, target.field_70161_v);
   }
 
 
   
   public static double getTchebychevDistance(double posX, double posY, double posZ, double targetX, double targetY, double targetZ) {
/* 22 */     return Math.max(Math.abs(posX - targetX), Math.max(Math.abs(posY - targetY), Math.abs(posZ - targetZ)));
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\helpers\IRMathHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */