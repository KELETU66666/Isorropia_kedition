/*     */ package fr.wind_blade.isorropia.common.blocks;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.tiles.TileStatue;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockHorizontal;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyDirection;
/*     */ import net.minecraft.block.state.BlockStateContainer;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.EnumBlockRenderType;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockStatue extends Block implements ITileEntityProvider, IItemBlockProvider {
/*  28 */   public static PropertyDirection FACING = BlockHorizontal.field_185512_D;
/*     */   
/*     */   public BlockStatue(Material materialIn) {
/*  31 */     super(materialIn);
/*  32 */     func_149711_c(2.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_180642_a(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
/*  38 */     return func_176223_P().func_177226_a((IProperty)FACING, (Comparable)placer.func_174811_aO().func_176734_d());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess source, BlockPos pos) {
/*  44 */     if ((Minecraft.func_71410_x()).field_71441_e != null) {
/*  45 */       TileEntity te = (Minecraft.func_71410_x()).field_71441_e.func_175625_s(pos);
/*  46 */       if (te instanceof TileStatue && ((TileStatue)te).getEntityData() != null) {
/*  47 */         return ((TileStatue)te).getAABB();
/*     */       }
/*     */     } 
/*     */     
/*  51 */     return field_185505_j;
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_180646_a(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
/*  56 */     TileEntity te = worldIn.func_175625_s(pos);
/*  57 */     if (te instanceof TileStatue && ((TileStatue)te).getEntityData() != null) {
/*  58 */       return ((TileStatue)te).getAABB();
/*     */     }
/*     */     
/*  61 */     return field_185505_j;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180633_a(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
/*  67 */     super.func_180633_a(worldIn, pos, state, placer, stack);
/*  68 */     TileEntity te = worldIn.func_175625_s(pos);
/*  69 */     if (!(te instanceof TileStatue)) {
/*     */       return;
/*     */     }
/*  72 */     stack.func_77982_d(stack.func_77942_o() ? stack.func_77978_p() : new NBTTagCompound());
/*  73 */     ((TileStatue)te).setEntityData(stack.func_77978_p());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
/*  79 */     ItemStack stack = playerIn.func_184586_b(hand);
/*  80 */     if (!stack.func_190926_b() && Block.func_149634_a(stack.func_77973_b()) instanceof BlockJarSoul) {
/*  81 */       TileStatue statue = (TileStatue)worldIn.func_175625_s(pos);
/*  82 */       statue.unpetrificate();
/*     */     } 
/*  84 */     return super.func_180639_a(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_176208_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer player) {
/*  89 */     if (!player.func_184812_l_()) {
/*  90 */       TileEntity te = worldIn.func_175625_s(pos);
/*  91 */       if (te instanceof TileStatue) {
/*  92 */         ItemStack drop = new ItemStack(this);
/*  93 */         drop.func_77982_d(((TileStatue)te).getEntityData());
/*  94 */         func_180635_a(worldIn, pos, drop);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World worldIn, int meta) {
/* 101 */     return (TileEntity)new TileStatue();
/*     */   }
/*     */ 
/*     */   
/*     */   public EnumBlockRenderType func_149645_b(IBlockState state) {
/* 106 */     return EnumBlockRenderType.MODEL;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/* 112 */     return func_176223_P().func_177226_a((IProperty)FACING, (Comparable)EnumFacing.func_176731_b(meta));
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 117 */     return ((EnumFacing)state.func_177229_b((IProperty)FACING)).func_176745_a();
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockStateContainer func_180661_e() {
/* 122 */     return new BlockStateContainer(this, new IProperty[] { (IProperty)FACING });
/*     */   }
/*     */   
/*     */   public boolean isFullyOpaque(IBlockState state) {
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149721_r(IBlockState state) {
/* 131 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c(IBlockState state) {
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149637_q(IBlockState state) {
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149730_j(IBlockState state) {
/* 146 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isVisuallyOpaque() {
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d(IBlockState state) {
/* 155 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemBlock getItemBlock() {
/* 160 */     return new BlockStatueItem(this);
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockStatue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */