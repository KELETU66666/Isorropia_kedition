 package fr.wind_blade.isorropia.common.blocks.material;
 
 import net.minecraft.block.material.MapColor;
 import net.minecraft.block.material.Material;
 import net.minecraft.block.material.MaterialLiquid;
 
 
 
 
 
 public class MaterialIR
 {
/* 13 */   public static final Material LIQUID_VAT = (Material)new MaterialLiquid(MapColor.field_151662_n);
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\material\MaterialIR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */