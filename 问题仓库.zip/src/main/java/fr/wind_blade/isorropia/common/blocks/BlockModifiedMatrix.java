 package fr.wind_blade.isorropia.common.blocks;
 
 import fr.wind_blade.isorropia.common.tiles.TileModifiedMatrix;
 import fr.wind_blade.isorropia.common.tiles.TileVat;
 import net.minecraft.block.Block;
 import net.minecraft.block.ITileEntityProvider;
 import net.minecraft.block.SoundType;
 import net.minecraft.block.material.Material;
 import net.minecraft.block.state.BlockFaceShape;
 import net.minecraft.block.state.IBlockState;
 import net.minecraft.tileentity.TileEntity;
 import net.minecraft.util.EnumBlockRenderType;
 import net.minecraft.util.EnumFacing;
 import net.minecraft.util.math.BlockPos;
 import net.minecraft.world.IBlockAccess;
 import net.minecraft.world.World;
 
 public class BlockModifiedMatrix
   extends Block implements ITileEntityProvider {
   public BlockModifiedMatrix() {
/* 21 */     super(Material.field_151576_e);
/* 22 */     func_149672_a(SoundType.field_185851_d);
/* 23 */     func_149711_c(2.0F);
/* 24 */     func_149752_b(20.0F);
   }
 
   
   public boolean func_149662_c(IBlockState state) {
/* 29 */     return false;
   }
 
   
   public boolean func_149686_d(IBlockState state) {
/* 34 */     return false;
   }
 
   
   public BlockFaceShape func_193383_a(IBlockAccess worldIn, IBlockState state, BlockPos pos, EnumFacing face) {
/* 39 */     return BlockFaceShape.UNDEFINED;
   }
 
   
   public EnumBlockRenderType func_149645_b(IBlockState state) {
/* 44 */     return EnumBlockRenderType.INVISIBLE;
   }
 
   
   public TileEntity func_149915_a(World worldIn, int meta) {
/* 49 */     return (TileEntity)new TileModifiedMatrix();
   }
 
   
   public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
/* 54 */     TileEntity te = worldIn.func_175625_s(pos.func_177977_b());
/* 55 */     if (te instanceof TileVat) {
/* 56 */       TileVat vat = (TileVat)te;
/* 57 */       if (vat.isInfusing()) {
/* 58 */         vat.destroyMultiBlock();
       }
/* 60 */       vat.setActive(false);
/* 61 */       vat.setStartUp(0.0F);
/* 62 */       vat.syncTile(false);
     } 
/* 64 */     super.func_180663_b(worldIn, pos, state);
   }
 
   
   public boolean func_176196_c(World worldIn, BlockPos pos) {
/* 69 */     return worldIn.func_175625_s(pos.func_177977_b()) instanceof TileVat;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockModifiedMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */