/*     */ package fr.wind_blade.isorropia.common.entities;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.passive.EntityRabbit;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.DifficultyInstance;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IShearable;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.aura.AuraHelper;
/*     */ 
/*     */ public class EntityJellyRabbit
/*     */   extends EntityRabbit implements IShearable {
/*  33 */   private static final DataParameter<String> aspect = EntityDataManager.func_187226_a(EntityJellyRabbit.class, DataSerializers.field_187194_d);
/*     */   
/*  35 */   private static final DataParameter<Integer> jelly = EntityDataManager.func_187226_a(EntityJellyRabbit.class, DataSerializers.field_187192_b);
/*     */   
/*     */   private static final int JELLY_BY_TICKS = 8000;
/*     */   
/*     */   private static final int AURA_BY_JELLY = 100;
/*     */   
/*     */   private static final int cooldown = 80;
/*     */   
/*     */   private int count;
/*     */   
/*  45 */   private Color color = new Color(Aspect.ORDER.getColor());
/*     */   
/*     */   public EntityJellyRabbit(World worldIn) {
/*  48 */     super(worldIn);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  53 */     super.func_70088_a();
/*  54 */     this.field_70180_af.func_187214_a(aspect, Aspect.ORDER.getTag());
/*  55 */     this.field_70180_af.func_187214_a(jelly, Integer.valueOf(0));
/*     */   }
/*     */ 
/*     */   
/*     */   public IEntityLivingData func_180482_a(DifficultyInstance difficulty, IEntityLivingData livingdata) {
/*  60 */     Aspect[] displayAspects = (Aspect[])Aspect.aspects.values().toArray((Object[])new Aspect[0]);
/*  61 */     setAspect(displayAspects[this.field_70170_p.field_73012_v.nextInt(displayAspects.length)]);
/*  62 */     setJellySize(2);
/*  63 */     return super.func_180482_a(difficulty, livingdata);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70636_d() {
/*  68 */     super.func_70636_d();
/*  69 */     this.field_70143_R = 0.0F;
/*     */     
/*  71 */     if (this.field_70170_p.field_72995_K || getJellySize() > 8) {
/*     */       return;
/*     */     }
/*  74 */     if (this.count % 80 == 0) {
/*  75 */       if (getAspect() == Aspect.FLUX) {
/*  76 */         if (AuraHelper.getFlux(func_130014_f_(), func_180425_c()) > 0.0F) {
/*  77 */           AuraHelper.addVis(this.field_70170_p, func_180425_c(), AuraHelper.drainFlux(this.field_70170_p, func_180425_c(), 10.0F, false));
/*     */         }
/*     */       } else {
/*  80 */         AuraHelper.drainVis(func_130014_f_(), func_180425_c(), 100.0F, false);
/*     */       } 
/*     */     }
/*     */     
/*  84 */     if (this.count >= 8000) {
/*  85 */       setJellySize(getJellySize() + 1);
/*  86 */       this.count = 0;
/*     */     } 
/*     */     
/*  89 */     this.count++;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70097_a(DamageSource source, float amount) {
/*  94 */     if (getJellySize() > 0 && source != DamageSource.field_76380_i) {
/*     */       
/*  96 */       Entity entity = source.func_76346_g();
/*  97 */       if (entity != null) {
/*  98 */         double d1 = entity.field_70165_t - this.field_70165_t;
/*     */         
/*     */         double d0;
/* 101 */         for (d0 = entity.field_70161_v - this.field_70161_v; d1 * d1 + d0 * d0 < 1.0E-4D; d0 = (Math.random() - Math.random()) * 0.01D)
/*     */         {
/* 103 */           d1 = (Math.random() - Math.random()) * 0.01D;
/*     */         }
/*     */         
/* 106 */         this.field_70739_aP = (float)(MathHelper.func_181159_b(d0, d1) * 57.29577951308232D - this.field_70177_z);
/* 107 */         func_70653_a(entity, 0.4F, d1, d0);
/*     */         
/* 109 */         if (entity instanceof EntityLivingBase) {
/* 110 */           func_70604_c((EntityLivingBase)entity);
/*     */         }
/*     */       } 
/* 113 */       func_184185_a((getJellySize() > 0) ? SoundEvents.field_187880_fp : SoundEvents.field_187822_em, 1.0F, 
/* 114 */           func_70647_i());
/*     */       
/* 116 */       if (!this.field_70170_p.field_72995_K) {
/* 117 */         func_70099_a(getJelly(), 0.0F);
/*     */       }
/*     */       
/* 120 */       return false;
/*     */     } 
/* 122 */     return super.func_70097_a(source, amount);
/*     */   }
/*     */   
/*     */   public ItemStack getJelly() {
/* 126 */     ItemStack stack = new ItemStack((Item)ItemsIS.itemJelly);
/* 127 */     Aspect apsect = getAspect();
/*     */     
/* 129 */     if (apsect != null) {
/* 130 */       ItemsIS.itemJelly.setAspects(stack, (new AspectList()).add(apsect, 5));
/*     */     }
/*     */     
/* 133 */     setJellySize(getJellySize() - 1);
/* 134 */     return stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_70005_c_() {
/* 139 */     if (func_145818_k_()) {
/* 140 */       return func_95999_t();
/*     */     }
/* 142 */     String tag = (String)this.field_70180_af.func_187225_a(aspect);
/* 143 */     String s = EntityList.func_75621_b((Entity)this);
/* 144 */     String name = "";
/*     */     
/* 146 */     if (s == null)
/* 147 */       s = "generic"; 
/* 148 */     if (tag == null || tag.isEmpty()) {
/* 149 */       name = I18n.func_135052_a("entity." + s + ".name", new Object[0]);
/*     */     }
/*     */     else {
/*     */       
/* 153 */       name = I18n.func_188566_a("entity." + s + "." + tag + ".name") ? I18n.func_135052_a("entity." + s + "." + tag + ".name", new Object[0]) : I18n.func_135052_a("entity." + s + ".aspect.name", new Object[] { tag });
/* 154 */     }  return name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound compound) {
/* 160 */     super.func_70014_b(compound);
/* 161 */     Aspect aspect = getAspect();
/* 162 */     compound.func_74778_a("tag", (aspect != null) ? aspect.getTag() : "");
/* 163 */     compound.func_74768_a("jelly", ((Integer)this.field_70180_af.func_187225_a(jelly)).intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound compound) {
/* 168 */     super.func_70037_a(compound);
/* 169 */     setAspect(Aspect.getAspect(compound.func_74779_i("tag")));
/* 170 */     this.field_70180_af.func_187227_b(jelly, Integer.valueOf(compound.func_74762_e("jelly")));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShearable(ItemStack item, IBlockAccess world, BlockPos pos) {
/* 175 */     return (getJellySize() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ItemStack> onSheared(ItemStack item, IBlockAccess world, BlockPos pos, int fortune) {
/* 180 */     List<ItemStack> stacks = new ArrayList<>();
/* 181 */     stacks.add(getJelly());
/* 182 */     return stacks;
/*     */   }
/*     */   
/*     */   public void setAspect(Aspect jellyAspect) {
/* 186 */     this.field_70180_af.func_187227_b(aspect, jellyAspect.getTag());
/*     */     
/* 188 */     if (this.field_70170_p.field_72995_K) {
/* 189 */       this.color = new Color(jellyAspect.getColor());
/*     */     }
/*     */   }
/*     */   
/*     */   public Aspect getAspect() {
/* 194 */     return Aspect.getAspect((String)this.field_70180_af.func_187225_a(aspect));
/*     */   }
/*     */   
/*     */   public int getJellySize() {
/* 198 */     return ((Integer)this.field_70180_af.func_187225_a(jelly)).intValue();
/*     */   }
/*     */   
/*     */   public void setJellySize(int newJellySize) {
/* 202 */     this.field_70180_af.func_187227_b(jelly, Integer.valueOf(newJellySize));
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 207 */     return this.color;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityJellyRabbit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */