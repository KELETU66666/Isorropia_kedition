 package fr.wind_blade.isorropia.client.fx;
 
 import java.util.Random;
 import net.minecraft.client.particle.Particle;
 import net.minecraft.util.math.MathHelper;
 import net.minecraft.world.World;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import thaumcraft.client.fx.ParticleEngine;
 import thaumcraft.client.fx.particles.FXGeneric;
 
 @SideOnly(Side.CLIENT)
 public class FXElementalWisp
   extends Particle
 {
   public FXElementalWisp(World worldIn, double x, double y, double z) {
/* 17 */     super(worldIn, x, y, z);
     
/* 19 */     for (int i = 0; i < 10; i++) {
       
/* 21 */       float a = getRandomSign(this.field_187136_p);
/* 22 */       float b = getRandomSign(this.field_187136_p);
/* 23 */       float c = getRandomSign(this.field_187136_p);
/* 24 */       float slow = 20.0F;
/* 25 */       FXGeneric fb = new FXGeneric(this.field_187122_b, x + a, y + b, z + c, (-a / slow), (-b / slow), (-c / slow));
/* 26 */       fb.func_70538_b(MathHelper.func_76131_a(384.0F, 0.0F, 1.0F), 0.0F, MathHelper.func_76131_a(384.0F, 0.0F, 1.0F));
/* 27 */       boolean sp = (this.field_187136_p.nextFloat() < 0.2D);
/* 28 */       int age = 30 + this.field_187136_p.nextInt(20);
/* 29 */       fb.func_187114_a(age);
/* 30 */       fb.setParticles(sp ? 320 : 512, 16, 1);
/* 31 */       fb.setScale(new float[] { 0.5F, 0.125F });
/* 32 */       ParticleEngine.addEffect(this.field_187122_b, (Particle)fb);
     } 
   }
   
   public float getRandomSign(Random rand) {
/* 37 */     return rand.nextBoolean() ? rand.nextFloat() : -rand.nextFloat();
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\fx\FXElementalWisp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */