 package fr.wind_blade.isorropia.client.fx;
 
 import net.minecraft.client.particle.Particle;
 import net.minecraft.client.renderer.BufferBuilder;
 import net.minecraft.entity.Entity;
 import net.minecraft.world.World;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import thaumcraft.client.fx.ParticleEngine;
 import thaumcraft.client.fx.particles.FXGeneric;
 
 @SideOnly(Side.CLIENT)
 public class FXCelestialAbsorption
   extends Particle {
/* 15 */   public int blendmode = 1;
/* 16 */   public float length = 1.0F;
/* 17 */   public int particle = 16;
 
   
   public FXCelestialAbsorption(World par1World, double x, double y, double z, float red, float green, float blue, boolean absorb) {
/* 21 */     super(par1World, x, y, z, 0.0D, 0.0D, 0.0D);
/* 22 */     this.particleRed = red;
/* 23 */     this.particleGreen = green;
/* 24 */     this.particleBlue = blue;
/* 25 */     func_187115_a(0.02F, 0.02F);
/* 26 */     this.field_187129_i = 0.0D;
/* 27 */     this.field_187130_j = 0.0D;
/* 28 */     this.field_187131_k = 0.0D;
/* 29 */     this.field_70547_e = 3;
/* 30 */     int c = 0;
/* 31 */     while (c < 50) {
       FXGeneric fb;
/* 33 */       boolean sp = (this.field_187136_p.nextFloat() < 0.2D);
       
/* 35 */       if (absorb) {
/* 36 */         fb = new FXGeneric(par1World, x, y, z, 0.0D, 0.0D, 0.0D);
/* 37 */         fb.setLoop(true);
/* 38 */         fb.setGravity(sp ? 0.0F : 0.125F);
/* 39 */         fb.setLayer(0);
/* 40 */         fb.setSlowDown(0.995D);
       } else {
/* 42 */         fb = new FXGeneric(par1World, x + this.field_187136_p.nextFloat() - 0.5D, y, z - this.field_187136_p.nextFloat() + 0.5D, 0.0D, 0.0D, 0.0D);
         
/* 44 */         fb.setParticles(sp ? 320 : 512, 16, 1);
/* 45 */         fb.setGravity(-0.1F);
/* 46 */         fb.setSlowDown(0.95D);
       } 
       
/* 49 */       int age = 30 + this.field_187136_p.nextInt(20);
/* 50 */       fb.func_187114_a(age);
/* 51 */       fb.func_70538_b(red, blue, green);
 
 
 
 
       
/* 57 */       float[] alphas = new float[6 + this.field_187136_p.nextInt(age / 3)];
/* 58 */       for (int a = 1; a < alphas.length - 1; a++)
/* 59 */         alphas[a] = this.field_187136_p.nextFloat(); 
/* 60 */       alphas[0] = 1.0F;
/* 61 */       fb.setAlphaF(alphas);
/* 62 */       fb.setParticles(sp ? 320 : 512, 16, 1);
/* 63 */       fb.setScale(new float[] { 0.5F, 0.125F });
/* 64 */       fb.setRandomMovementScale(0.0025F, 0.001F, 0.0025F);
       
/* 66 */       ParticleEngine.addEffectWithDelay(par1World, (Particle)fb, 2 + this.field_187136_p.nextInt(3));
/* 67 */       c++;
     } 
   }
 
   
   public void func_189213_a() {
/* 73 */     this.field_187123_c = this.field_187126_f;
/* 74 */     this.field_187124_d = this.field_187127_g;
/* 75 */     this.field_187125_e = this.field_187128_h;
/* 76 */     if (this.field_70546_d++ >= this.field_70547_e) {
/* 77 */       func_187112_i();
     }
   }
   
   public void setRGB(float r, float g, float b) {
/* 82 */     this.particleRed = r;
/* 83 */     this.particleGreen = g;
/* 84 */     this.particleBlue = b;
   }
   
   public void func_180434_a(BufferBuilder wr, Entity entity, float partialTicks, float rotX, float rotY, float rotZ, float f4, float f5) {}
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\fx\FXCelestialAbsorption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */