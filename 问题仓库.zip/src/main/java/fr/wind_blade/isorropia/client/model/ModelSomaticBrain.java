 package fr.wind_blade.isorropia.client.model;
 
 import net.minecraft.client.model.ModelBase;
 import net.minecraft.client.model.ModelBox;
 import net.minecraft.client.model.ModelRenderer;
 import net.minecraft.entity.Entity;
 import net.minecraft.util.ResourceLocation;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import thaumcraft.client.renderers.models.gear.ModelCustomArmor;
 
 @SideOnly(Side.CLIENT)
 public class ModelSomaticBrain
   extends ModelCustomArmor {
/* 15 */   public static ModelSomaticBrain INSTANCE = new ModelSomaticBrain();
/* 16 */   public static ResourceLocation TEX = new ResourceLocation("isorropia", "textures/models/somatic_brain.png");
   
   public ModelSomaticBrain() {
/* 19 */     super(1.0F, 0, 32, 32);
/* 20 */     this.field_78090_t = 32;
/* 21 */     this.field_78089_u = 32;
/* 22 */     this.field_78116_c = new ModelRenderer((ModelBase)this);
/* 23 */     this.field_78116_c.func_78793_a(0.0F, 24.0F, 0.0F);
/* 24 */     this.field_78116_c.field_78804_l.add(new ModelBox(this.field_78116_c, 0, 21, -2.5F, -2.0F, -2.0F, 5, 2, 4, 0.0F, false));
/* 25 */     this.field_78116_c.field_78804_l.add(new ModelBox(this.field_78116_c, 0, 12, -3.0F, -3.0F, -3.0F, 6, 3, 6, 0.0F, false));
/* 26 */     this.field_78116_c.field_78804_l.add(new ModelBox(this.field_78116_c, 0, 0, -4.0F, -4.0F, -4.0F, 8, 4, 8, 0.0F, false));
   }
 
   
   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 31 */     this.field_78116_c.func_78785_a(0.0625F);
   }
   
   public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
/* 35 */     modelRenderer.field_78795_f = x;
/* 36 */     modelRenderer.field_78796_g = y;
/* 37 */     modelRenderer.field_78808_h = z;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\model\ModelSomaticBrain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */