 package fr.wind_blade.isorropia.common.entities;
 
 import fr.wind_blade.isorropia.common.entities.projectile.EntityEmber;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.passive.EntityWolf;
 import net.minecraft.world.World;
 
 
 
 public class EntityHellHound
   extends EntityWolf
 {
   long soundDelay;
   
   public EntityHellHound(World worldIn) {
/* 17 */     super(worldIn);
/* 18 */     this.soundDelay = 0L;
/* 19 */     this.field_70178_ae = true;
   }
 
   
   public void func_70636_d() {
/* 24 */     super.func_70636_d();
/* 25 */     EntityLivingBase target = null;
/* 26 */     if (func_70638_az() != null) {
/* 27 */       target = func_70638_az();
     }
/* 29 */     if (func_70638_az() != null) {
/* 30 */       target = func_70638_az();
     }
 
     
/* 34 */     float scatter = 8.0F;
/* 35 */     EntityEmber orb = new EntityEmber(this.field_70170_p, (EntityLivingBase)this, scatter);
/* 36 */     orb.damage = 1.0F;
/* 37 */     orb.firey = 1;
/* 38 */     this.field_70170_p.func_72838_d((Entity)orb);
/* 39 */     orb.field_70165_t += orb.field_70159_w;
/* 40 */     orb.field_70163_u += orb.field_70181_x;
/* 41 */     orb.field_70161_v += orb.field_70179_y;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityHellHound.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */