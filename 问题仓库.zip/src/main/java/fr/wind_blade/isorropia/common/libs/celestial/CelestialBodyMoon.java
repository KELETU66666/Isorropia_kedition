 package fr.wind_blade.isorropia.common.libs.celestial;
 
 import java.util.function.BiPredicate;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.util.ResourceLocation;
 import net.minecraft.world.World;
 
 public class CelestialBodyMoon
   extends CelestialBody
 {
   public final int moonPhase;
   
   public CelestialBodyMoon(ResourceLocation registryName, ResourceLocation tex, int moonPhase) {
/* 14 */     this(registryName, tex, (player, worldIn) -> (!worldIn.func_72896_J() && CelestialBody.isNight(worldIn) && (moonPhase == -1 || worldIn.func_72853_d() == moonPhase)), moonPhase);
   }
 
 
   
   public CelestialBodyMoon(ResourceLocation registryName, ResourceLocation tex, BiPredicate<EntityPlayer, World> biPredicate, int moonPhase) {
/* 20 */     super(registryName, tex, biPredicate);
/* 21 */     this.moonPhase = moonPhase;
   }
 
   
   public boolean isAuraEquals(EntityPlayer player, World worldIn, ICelestialBody newCelestialBody) {
/* 26 */     return (newCelestialBody instanceof CelestialBodyMoon && this != CelestialBody.MOON && newCelestialBody == CelestialBody.MOON);
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\celestial\CelestialBodyMoon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */