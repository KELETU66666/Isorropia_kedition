 package fr.wind_blade.isorropia.common.items.misc;
 
 import fr.wind_blade.isorropia.common.Common;
 import fr.wind_blade.isorropia.common.IsorropiaAPI;
 import fr.wind_blade.isorropia.common.items.ItemsIS;
 import fr.wind_blade.isorropia.common.research.recipes.CurativeInfusionRecipe;
 import net.minecraft.creativetab.CreativeTabs;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.util.ActionResult;
 import net.minecraft.util.EnumHand;
 import net.minecraft.util.IStringSerializable;
 import net.minecraft.util.NonNullList;
 import net.minecraft.util.ResourceLocation;
 import net.minecraft.world.World;
 import thaumcraft.common.lib.utils.EntityUtils;
 
 public class ItemCat extends Item {
   public ItemCat() {
/* 23 */     func_77627_a(true);
   }
 
   
   public void func_150895_a(CreativeTabs tab, NonNullList<ItemStack> items) {
/* 28 */     if (tab != Common.isorropiaCreativeTabs)
/* 29 */       return;  for (EnumCat cat : EnumCat.values()) {
/* 30 */       if (cat.recipe != null) {
/* 31 */         items.add(new ItemStack(this, 1, cat.getID()));
       }
     } 
   }
   
   public static ItemStack createCat(EnumCat type, String name) {
/* 37 */     ItemStack stack = new ItemStack(ItemsIS.itemCat, 1, type.getID());
     
/* 39 */     return stack.func_151001_c(name);
   }
   
   public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
/* 43 */     ItemStack stack = playerIn.func_184586_b(handIn);
/* 44 */     EnumCat cat = EnumCat.values()[stack.func_77960_j()];
/* 45 */     Entity entity = EntityUtils.getPointedEntity(worldIn, (Entity)playerIn, 1.0D, 5.0D, 5.0F, true);
     
/* 47 */     if (cat.getRecipe() != null)
/* 48 */       ((CurativeInfusionRecipe)IsorropiaAPI.creatureInfusionRecipes.get(new ResourceLocation(cat.getRecipe()))).applyWithCheat(playerIn, (entity instanceof EntityLivingBase) ? (EntityLivingBase)entity : (EntityLivingBase)playerIn, stack); 
/* 49 */     return super.func_77659_a(worldIn, playerIn, handIn);
   }
   
   public enum EnumCat
     implements IStringSerializable {
/* 54 */     PIG(0, "pig"), SHEEP(1, "sheep"), COW(2, "cow"), OCELOT(3, "ocelot"), CHICKEN(4, "chicken"),
/* 55 */     RABBIT(5, "rabbit"), WOLF(6, "wolf"), LOVE(7, "love", "isorropia:instilledfidelity"),
/* 56 */     SELFSHEARING(8, "selfshearing", "isorropia:selfshearing"),
/* 57 */     ENDERHEART(9, "enderheart", "isorropia:enderheart"),
/* 58 */     SHOCK(10, "shockskin", "isorropia:shockskin"),
/* 59 */     AWAKENED_BLOOD(11, "awakened_blood", "isorropia:awakened_blood"),
/* 60 */     DIAMOND_SKIN(12, "diamond_skin", "isorropia:diamond_skin"),
/* 61 */     QUICKSILVER_LIMBS(13, "quicksilver_limbs", "isorropia:quicksilver_limbs");
 
 
     
/* 65 */     private String recipe = null; private final int id;
     
     EnumCat(int id, String name) {
/* 68 */       this.id = id;
/* 69 */       this.name = name;
     }
     private final String name;
     
     EnumCat(int id, String name, String recipe) {
/* 74 */       this.recipe = recipe;
     }
     
     public int getID() {
/* 78 */       return this.id;
     }
 
     
     public String func_176610_l() {
/* 83 */       return this.name;
     }
     
     public String getRecipe() {
/* 87 */       return this.recipe;
     }
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\misc\ItemCat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */