 package fr.wind_blade.isorropia.client.renderer;
 
 import net.minecraft.client.model.ModelBase;
 import net.minecraft.client.renderer.GlStateManager;
 import net.minecraft.client.renderer.entity.Render;
 import net.minecraft.client.renderer.entity.RenderManager;
 import net.minecraft.entity.Entity;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 
 @SideOnly(Side.CLIENT)
 public abstract class RenderEntity<T extends Entity>
   extends Render<T> {
   protected ModelBase mainModel;
   
   public RenderEntity(RenderManager renderManagerIn, ModelBase modelBaseIn, float shadowSizeIn) {
/* 17 */     super(renderManagerIn);
/* 18 */     this.mainModel = modelBaseIn;
/* 19 */     this.field_76989_e = shadowSizeIn;
   }
 
   
   public void func_76986_a(T entity, double x, double y, double z, float entityYaw, float partialTicks) {
/* 24 */     GlStateManager.func_179094_E();
/* 25 */     GlStateManager.func_179109_b((float)x, (float)y + 1.5F, (float)z);
/* 26 */     GlStateManager.func_179114_b(180.0F - entityYaw, 0.0F, 1.0F, 0.0F);
/* 27 */     GlStateManager.func_179152_a(-1.0F, -1.0F, 1.0F);
     
/* 29 */     if (this.field_188301_f) {
/* 30 */       GlStateManager.func_179142_g();
/* 31 */       GlStateManager.func_187431_e(func_188298_c((Entity)entity));
     } 
     
/* 34 */     func_180548_c((Entity)entity);
/* 35 */     ModelBase model = this.mainModel;
 
     
/* 38 */     float pitch = -((float)Math.toRadians((((Entity)entity).field_70127_C + (((Entity)entity).field_70125_A - ((Entity)entity).field_70127_C) * partialTicks)));
     
/* 40 */     model.func_78088_a((Entity)entity, 0.0F, 0.0F, ((Entity)entity).field_70173_aa + partialTicks, 0.0F, pitch, 0.0625F);
     
/* 42 */     if (this.field_188301_f) {
/* 43 */       GlStateManager.func_187417_n();
/* 44 */       GlStateManager.func_179119_h();
     } 
     
/* 47 */     GlStateManager.func_179121_F();
     
/* 49 */     super.func_76986_a((Entity)entity, x, y, z, entityYaw, partialTicks);
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\RenderEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */