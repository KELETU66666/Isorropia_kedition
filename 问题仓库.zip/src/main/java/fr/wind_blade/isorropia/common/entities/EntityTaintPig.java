/*     */ package fr.wind_blade.isorropia.common.entities;
/*     */ 
/*     */ import com.google.common.collect.Sets;
/*     */ import fr.wind_blade.isorropia.common.entities.ai.EntityAIEatTaint;
/*     */ import fr.wind_blade.isorropia.common.entities.ai.EntityAITaintTempt;
/*     */ import java.util.Set;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIAttackMelee;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAILookIdle;
/*     */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
/*     */ import net.minecraft.entity.ai.EntityAIPanic;
/*     */ import net.minecraft.entity.ai.EntityAISwimming;
/*     */ import net.minecraft.entity.ai.EntityAIWander;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.passive.EntityPig;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EntityDamageSource;
/*     */ import net.minecraft.world.World;
/*     */ import thaumcraft.api.damagesource.DamageSourceThaumcraft;
/*     */ import thaumcraft.api.items.ItemsTC;
/*     */ import thaumcraft.api.potions.PotionFluxTaint;
/*     */ import thaumcraft.api.potions.PotionVisExhaust;
/*     */ import thaumcraft.common.entities.monster.tainted.EntityTaintCrawler;
/*     */ import thaumcraft.common.lib.potions.PotionInfectiousVisExhaust;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityTaintPig
/*     */   extends EntityPig
/*     */ {
/*  39 */   private static final Set<Item> TEMPTATION_ITEMS = Sets.newHashSet((Object[])new Item[] { ItemsTC.bottleTaint });
/*     */   
/*     */   public EntityTaintPig(World worldIn) {
/*  42 */     super(worldIn);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  47 */     this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/*  48 */     this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIPanic((EntityCreature)this, 1.25D));
/*  49 */     this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAIAttackMelee((EntityCreature)this, 1.0D, false));
/*  50 */     this.field_70714_bg.func_75776_a(3, (EntityAIBase)new EntityAIEatTaint((EntityLiving)this));
/*  51 */     this.field_70714_bg.func_75776_a(4, (EntityAIBase)new EntityAITaintTempt((EntityCreature)this, 1.2D, false, TEMPTATION_ITEMS));
/*  52 */     this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIWander((EntityCreature)this, 1.0D));
/*  53 */     this.field_70714_bg.func_75776_a(6, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 6.0F));
/*  54 */     this.field_70714_bg.func_75776_a(7, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
/*  55 */     this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityTaintCrawler.class, true));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/*  61 */     super.func_110147_ax();
/*  62 */     func_110140_aT().func_111150_b(SharedMonsterAttributes.field_111264_e).func_111128_a(4.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70619_bc() {
/*  67 */     super.func_70619_bc();
/*     */     
/*  69 */     if (func_70644_a(PotionFluxTaint.instance))
/*  70 */       func_184589_d(PotionFluxTaint.instance); 
/*  71 */     if (func_70644_a(PotionVisExhaust.instance))
/*  72 */       func_184589_d(PotionVisExhaust.instance); 
/*  73 */     if (func_70644_a(PotionInfectiousVisExhaust.instance)) {
/*  74 */       func_184589_d(PotionInfectiousVisExhaust.instance);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean func_70652_k(Entity entityIn) {
/*  79 */     func_130011_c(entityIn);
/*     */     
/*  81 */     boolean flag = entityIn.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), 
/*  82 */         (float)func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e());
/*     */     
/*  84 */     if (flag) {
/*  85 */       func_174815_a((EntityLivingBase)this, entityIn);
/*     */     }
/*     */     
/*  88 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180431_b(DamageSource source) {
/*  94 */     if (source instanceof EntityDamageSource) {
/*  95 */       Entity entity = ((EntityDamageSource)source).func_76346_g();
/*     */       
/*  97 */       if (entity instanceof thaumcraft.api.entities.ITaintedMob) {
/*  98 */         return true;
/*     */       }
/* 100 */     } else if (source instanceof DamageSourceThaumcraft && ((DamageSourceThaumcraft)source).field_76373_n
/* 101 */       .equals("taint")) {
/* 102 */       return true;
/*     */     } 
/*     */     
/* 105 */     return super.func_180431_b(source);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70880_s() {
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70877_b(ItemStack stack) {
/* 115 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityTaintPig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */