/*     */ package fr.wind_blade.isorropia.common.items.misc;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.IsorropiaAPI;
/*     */ import fr.wind_blade.isorropia.common.items.IJellyAspectEffectProvider;
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemFood;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ActionResult;
/*     */ import net.minecraft.util.EnumActionResult;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.aspects.IEssentiaContainerItem;
/*     */ 
/*     */ public class ItemJelly extends ItemFood implements IEssentiaContainerItem {
/*     */   private static final int ASPECT_SIZE = 5;
/*     */   
/*     */   public ItemJelly() {
/*  29 */     super(0, false);
/*  30 */     setNoRepair();
/*  31 */     func_77627_a(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_150895_a(CreativeTabs tab, NonNullList<ItemStack> items) {
/*  36 */     if (tab == Common.isorropiaCreativeTabs || tab == CreativeTabs.field_78027_g) {
/*  37 */       items.add(new ItemStack((Item)this));
/*  38 */       for (Aspect tag : Aspect.aspects.values()) {
/*  39 */         ItemStack i = new ItemStack((Item)this);
/*  40 */         setAspects(i, (new AspectList()).add(tag, 5));
/*  41 */         items.add(i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public String func_77653_i(ItemStack stack) {
/*  49 */     return (getAspects(stack) != null && !(getAspects(stack)).aspects.isEmpty()) ? (
/*  50 */       (getAspects(stack).getAspects()[0] == Aspect.FLUX) ? 
/*  51 */       I18n.func_135052_a(func_77667_c(stack) + ".vitium.name", new Object[0]) : 
/*  52 */       String.format(super.func_77653_i(stack), new Object[] {
/*  53 */           getAspects(stack).getAspects()[0].getName()
/*  54 */         })) : I18n.func_135052_a(func_77667_c(stack) + ".default.name", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public AspectList getAspects(ItemStack itemstack) {
/*  59 */     if (itemstack.func_77942_o()) {
/*  60 */       AspectList aspects = new AspectList();
/*  61 */       aspects.readFromNBT(itemstack.func_77978_p());
/*  62 */       return (aspects.size() > 0) ? aspects : null;
/*     */     } 
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAspects(ItemStack itemstack, AspectList aspects) {
/*  69 */     if (!itemstack.func_77942_o()) {
/*  70 */       itemstack.func_77982_d(new NBTTagCompound());
/*     */     }
/*  72 */     aspects.writeToNBT(itemstack.func_77978_p());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean ignoreContainedAspects() {
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
/*  82 */     ItemStack itemstack = playerIn.func_184586_b(handIn);
/*     */     
/*  84 */     if (getProvider(itemstack).canBeEaten(playerIn, itemstack)) {
/*  85 */       playerIn.func_184598_c(handIn);
/*  86 */       return new ActionResult(EnumActionResult.SUCCESS, itemstack);
/*     */     } 
/*  88 */     return new ActionResult(EnumActionResult.FAIL, itemstack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_77849_c(ItemStack stack, World worldIn, EntityPlayer player) {
/*  94 */     getProvider(stack).onFoodEeaten(player, stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_77626_a(ItemStack stack) {
/*  99 */     return getProvider(stack).getEatDuration(stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_150905_g(ItemStack stack) {
/* 104 */     return getProvider(stack).getHungerReplinish(stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public float func_150906_h(ItemStack stack) {
/* 109 */     return getProvider(stack).getSaturationReplinish(stack);
/*     */   }
/*     */   
/*     */   private static IJellyAspectEffectProvider getProvider(ItemStack stack) {
/* 113 */     AspectList aspects = ItemsIS.itemJelly.getAspects(stack);
/*     */     
/* 115 */     IJellyAspectEffectProvider provider = IsorropiaAPI.getJellyAspectEffect((aspects == null) ? null : aspects.getAspects()[0]);
/* 116 */     return (provider == null) ? IsorropiaAPI.getJellyAspectEffect(null) : provider;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\misc\ItemJelly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */