package fr.wind_blade.isorropia.common.libs.celestial;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public interface ICelestialBody {
  boolean canBeSeen(EntityPlayer paramEntityPlayer, World paramWorld);
  
  boolean canBeDrained(EntityPlayer paramEntityPlayer, World paramWorld);
  
  boolean isAuraEquals(EntityPlayer paramEntityPlayer, World paramWorld, ICelestialBody paramICelestialBody);
  
  float auraDrainedFactor(EntityPlayer paramEntityPlayer, World paramWorld);
  
  ResourceLocation getRegistryName();
  
  ResourceLocation getTex();
}


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\celestial\ICelestialBody.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */