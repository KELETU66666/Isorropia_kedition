package fr.wind_blade.isorropia.common.blocks;

import net.minecraft.item.ItemBlock;

public interface IItemBlockProvider {
  ItemBlock getItemBlock();
}


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\IItemBlockProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */