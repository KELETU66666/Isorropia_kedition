 package fr.wind_blade.isorropia.common.entities.projectile;
 
 import fr.wind_blade.isorropia.common.items.ItemsIS;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.passive.EntityChicken;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.entity.projectile.EntityEgg;
 import net.minecraft.entity.projectile.EntityThrowable;
 import net.minecraft.item.Item;
 import net.minecraft.util.DamageSource;
 import net.minecraft.util.EnumParticleTypes;
 import net.minecraft.util.datafix.DataFixer;
 import net.minecraft.util.math.RayTraceResult;
 import net.minecraft.world.World;
 
 
 public class EntityIncubatedEgg
   extends EntityEgg
 {
   public EntityIncubatedEgg(World worldIn) {
/* 22 */     super(worldIn);
   }
   
   public EntityIncubatedEgg(World worldIn, EntityPlayer playerIn) {
/* 26 */     super(worldIn, (EntityLivingBase)playerIn);
   }
   
   public static void registerFixesEgg(DataFixer fixer) {
/* 30 */     EntityThrowable.func_189661_a(fixer, "ThrownEgg");
   }
 
   
   protected void func_70184_a(RayTraceResult result) {
/* 35 */     if (result.field_72308_g != null) {
/* 36 */       result.field_72308_g.func_70097_a(DamageSource.func_76356_a((Entity)this, (Entity)func_85052_h()), 0.0F);
     }
/* 38 */     if (!this.field_70170_p.field_72995_K) {
/* 39 */       EntityChicken entitychicken = new EntityChicken(this.field_70170_p);
/* 40 */       entitychicken.func_70873_a(-24000);
/* 41 */       entitychicken.func_70012_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, this.field_70177_z, 0.0F);
/* 42 */       this.field_70170_p.func_72838_d((Entity)entitychicken);
     } 
     
/* 45 */     for (int i = 0; i < 8; i++) {
/* 46 */       this.field_70170_p.func_175688_a(EnumParticleTypes.ITEM_CRACK, this.field_70165_t, this.field_70163_u, this.field_70161_v, (this.field_70146_Z
/* 47 */           .nextFloat() - 0.5D) * 0.08D, (this.field_70146_Z.nextFloat() - 0.5D) * 0.08D, (this.field_70146_Z
/* 48 */           .nextFloat() - 0.5D) * 0.08D, new int[] { Item.func_150891_b(ItemsIS.itemIncubatedEgg) });
     } 
     
/* 51 */     if (!this.field_70170_p.field_72995_K)
/* 52 */       func_70106_y(); 
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\projectile\EntityIncubatedEgg.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */