/*     */ package fr.wind_blade.isorropia.common.entities;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityHanging;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.network.ByteBufUtils;
/*     */ import net.minecraftforge.fml.common.registry.IEntityAdditionalSpawnData;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.AspectList;
/*     */ import thaumcraft.api.aspects.IEssentiaContainerItem;
/*     */ import thaumcraft.api.items.ItemsTC;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityHangingLabel
/*     */   extends EntityHanging
/*     */   implements IEntityAdditionalSpawnData
/*     */ {
/*     */   private Aspect aspect;
/*     */   
/*     */   public EntityHangingLabel(World worldIn) {
/*  30 */     super(worldIn);
/*  31 */     this.aspect = null;
/*     */   }
/*     */   
/*     */   public EntityHangingLabel(World world, boolean b, BlockPos offset, EnumFacing face, Aspect aspectIn) {
/*  35 */     super(world, offset);
/*  36 */     func_174859_a(face);
/*  37 */     this.aspect = aspectIn;
/*     */   }
/*     */   
/*     */   public Aspect getAspect() {
/*  41 */     return this.aspect;
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_82329_d() {
/*  46 */     return 16;
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_82330_g() {
/*  51 */     return 16;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_110128_b(Entity brokenEntity) {
/*  56 */     func_184523_o();
/*     */     
/*  58 */     if (this.field_70170_p.func_82736_K().func_82766_b("doEntityDrops")) {
/*  59 */       ItemStack stack = new ItemStack(ItemsTC.label);
/*  60 */       if (this.aspect != null) {
/*  61 */         ((IEssentiaContainerItem)ItemsTC.label).setAspects(stack, (new AspectList()).add(this.aspect, 1));
/*  62 */         stack.func_77964_b(1);
/*     */       } 
/*  64 */       func_70099_a(stack, 0.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_184523_o() {
/*  70 */     BlockPos hangingBlock = this.field_174861_a.func_177972_a(this.field_174860_b.func_176734_d());
/*  71 */     IBlockState state = this.field_70170_p.func_180495_p(hangingBlock);
/*  72 */     func_184185_a(state.func_177230_c().getSoundType(state, this.field_70170_p, hangingBlock, (Entity)this).func_185846_f(), 1.5F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public float func_70111_Y() {
/*  77 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_70112_a(double distance) {
/*  83 */     double d0 = 16.0D;
/*  84 */     d0 = d0 * 64.0D * func_184183_bd();
/*  85 */     return (distance < d0 * d0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeSpawnData(ByteBuf buffer) {
/*  90 */     buffer.writeInt(this.field_174860_b.func_176736_b());
/*  91 */     ByteBufUtils.writeUTF8String(buffer, (this.aspect != null) ? this.aspect.getTag() : "");
/*     */   }
/*     */ 
/*     */   
/*     */   public void readSpawnData(ByteBuf additionalData) {
/*  96 */     func_174859_a(EnumFacing.func_176731_b(additionalData.readInt()));
/*  97 */     String tag = ByteBufUtils.readUTF8String(additionalData);
/*  98 */     if (!tag.isEmpty()) {
/*  99 */       this.aspect = Aspect.getAspect(tag);
/*     */     }
/*     */   }
/*     */   
/*     */   public void func_70014_b(NBTTagCompound compound) {
/* 104 */     super.func_70014_b(compound);
/* 105 */     compound.func_74778_a("aspect", (this.aspect != null) ? this.aspect.getTag() : "");
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound compound) {
/* 110 */     super.func_70037_a(compound);
/* 111 */     String tag = compound.func_74779_i("aspect");
/* 112 */     if (!tag.isEmpty())
/* 113 */       this.aspect = Aspect.getAspect(tag); 
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityHangingLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */