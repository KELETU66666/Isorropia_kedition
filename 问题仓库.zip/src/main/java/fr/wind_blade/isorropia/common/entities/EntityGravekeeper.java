 package fr.wind_blade.isorropia.common.entities;
 
 import fr.wind_blade.isorropia.common.entities.ai.EntityAINearestUndeadAttackableTarget;
 import java.util.List;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityCreature;
 import net.minecraft.entity.EntityLiving;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.ai.EntityAIAttackMelee;
 import net.minecraft.entity.ai.EntityAIBase;
 import net.minecraft.entity.ai.EntityAIFollowOwner;
 import net.minecraft.entity.ai.EntityAILeapAtTarget;
 import net.minecraft.entity.ai.EntityAIOcelotAttack;
 import net.minecraft.entity.ai.EntityAIOcelotSit;
 import net.minecraft.entity.ai.EntityAISit;
 import net.minecraft.entity.ai.EntityAISwimming;
 import net.minecraft.entity.ai.EntityAITargetNonTamed;
 import net.minecraft.entity.ai.EntityAIWander;
 import net.minecraft.entity.ai.EntityAIWatchClosest;
 import net.minecraft.entity.passive.EntityChicken;
 import net.minecraft.entity.passive.EntityOcelot;
 import net.minecraft.entity.passive.EntityTameable;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.util.DamageSource;
 import net.minecraft.util.math.AxisAlignedBB;
 import net.minecraft.world.World;
 import thaumcraft.client.fx.FXDispatcher;
 
 public class EntityGravekeeper
   extends EntityOcelot
 {
   public EntityGravekeeper(World world) {
/* 33 */     super(world);
   }
 
   
   protected void func_184651_r() {
/* 38 */     this.field_70911_d = new EntityAISit((EntityTameable)this);
/* 39 */     this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/* 40 */     this.field_70714_bg.func_75776_a(2, (EntityAIBase)this.field_70911_d);
/* 41 */     this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIFollowOwner((EntityTameable)this, 1.0D, 10.0F, 5.0F));
/* 42 */     this.field_70714_bg.func_75776_a(6, (EntityAIBase)new EntityAIOcelotSit(this, 0.8D));
/* 43 */     this.field_70714_bg.func_75776_a(7, (EntityAIBase)new EntityAILeapAtTarget((EntityLiving)this, 0.3F));
/* 44 */     this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAIOcelotAttack((EntityLiving)this));
/* 45 */     this.field_70714_bg.func_75776_a(9, (EntityAIBase)new EntityAIWander((EntityCreature)this, 0.8D));
/* 46 */     this.field_70714_bg.func_75776_a(10, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 10.0F));
/* 47 */     this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAITargetNonTamed((EntityTameable)this, EntityChicken.class, false, null));
/* 48 */     this.field_70715_bh.func_75776_a(3, (EntityAIBase)new EntityAINearestUndeadAttackableTarget((EntityCreature)this, 1, false, false));
/* 49 */     this.field_70715_bh.func_75776_a(4, (EntityAIBase)new EntityAIAttackMelee((EntityCreature)this, 1.4D, false));
   }
 
   
   public boolean func_70652_k(Entity target) {
/* 54 */     return ((target instanceof EntityLivingBase && ((EntityLivingBase)target).func_70662_br()) || target
/* 55 */       .func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), 2.0F));
   }
 
   
   public void func_70071_h_() {
/* 60 */     super.func_70071_h_();
/* 61 */     List<EntityLivingBase> critters = this.field_70170_p.func_72872_a(EntityLivingBase.class, new AxisAlignedBB(this.field_70165_t - 5.0D, this.field_70163_u - 5.0D, this.field_70161_v - 5.0D, this.field_70165_t + 5.0D, this.field_70163_u + 5.0D, this.field_70161_v + 5.0D));
     
/* 63 */     for (EntityLivingBase ent : critters) {
/* 64 */       if (ent.func_70662_br()) {
/* 65 */         ent.func_70015_d(1);
         
/* 67 */         if (this.field_70170_p.field_72995_K)
/* 68 */           FXDispatcher.INSTANCE.beamBore(this.field_70165_t, this.field_70163_u + (this.field_70131_O / 2.0F), this.field_70161_v, ent.field_70165_t, ent.field_70163_u + (ent.field_70131_O / 2.0F), ent.field_70161_v, 0, 16773444, false, 2.5F, 
/* 69 */               Integer.valueOf(1), 1); 
       } 
     } 
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityGravekeeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */