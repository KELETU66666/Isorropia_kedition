/*     */ package fr.wind_blade.isorropia.client.libs;
/*     */ 
/*     */ import net.minecraft.client.renderer.texture.DynamicTexture;
/*     */ import net.minecraft.client.renderer.texture.ITextureObject;
/*     */ import net.minecraft.client.renderer.texture.ITickableTextureObject;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.resources.IResourceManager;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class CombinedTextureManager
/*     */   extends TextureManager
/*     */ {
/*  16 */   public static ResourceLocation COBBLESTONE_LOCATION = new ResourceLocation("textures/blocks/cobblestone.png");
/*  17 */   public static ResourceLocation PLACEHOLDER_LOCATION = new ResourceLocation("isorropia", "textures/blocks/statue.png");
/*     */   
/*     */   protected final TextureManager textureManager;
/*     */   
/*  21 */   protected ResourceLocation materialLocation = COBBLESTONE_LOCATION;
/*     */   protected int progression;
/*     */   protected int max;
/*     */   
/*     */   public CombinedTextureManager(TextureManager textureManager, ResourceLocation material) {
/*  26 */     this(textureManager, material, 100, 100);
/*     */   }
/*     */   
/*     */   public CombinedTextureManager(TextureManager textureManager, ResourceLocation material, int progression, int max) {
/*  30 */     super(null);
/*  31 */     this.textureManager = checkManager(textureManager);
/*  32 */     this.progression = progression;
/*  33 */     this.max = max;
/*     */   }
/*     */   
/*     */   private TextureManager checkManager(TextureManager textureManager) {
/*  37 */     return (textureManager instanceof CombinedTextureManager) ? 
/*  38 */       checkManager(((CombinedTextureManager)textureManager).textureManager) : textureManager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_110577_a(ResourceLocation resource) {
/*  44 */     this.textureManager.func_110579_a(PLACEHOLDER_LOCATION, (ITextureObject)new CombinedLayeredColorMaskTexture(resource, this.materialLocation, this.progression, this.max, resource
/*  45 */           .func_110623_a().startsWith("skins/")));
/*  46 */     this.textureManager.func_110577_a(PLACEHOLDER_LOCATION);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_110580_a(ResourceLocation textureLocation, ITickableTextureObject textureObj) {
/*  51 */     return this.textureManager.func_110580_a(textureLocation, textureObj);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_110579_a(ResourceLocation textureLocation, ITextureObject textureObj) {
/*  56 */     return this.textureManager.func_110579_a(textureLocation, textureObj);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITextureObject func_110581_b(ResourceLocation textureLocation) {
/*  61 */     return this.textureManager.func_110581_b(textureLocation);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceLocation func_110578_a(String name, DynamicTexture texture) {
/*  66 */     return this.textureManager.func_110578_a(name, texture);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_110550_d() {
/*  71 */     this.textureManager.func_110550_d();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_147645_c(ResourceLocation textureLocation) {
/*  76 */     this.textureManager.func_147645_c(textureLocation);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_110549_a(IResourceManager resourceManager) {
/*  81 */     this.textureManager.func_110549_a(resourceManager);
/*     */   }
/*     */   
/*     */   public ResourceLocation getMaterialLocation() {
/*  85 */     return this.materialLocation;
/*     */   }
/*     */   
/*     */   public void setMaterialLocation(ResourceLocation materialLocation) {
/*  89 */     this.materialLocation = materialLocation;
/*     */   }
/*     */   
/*     */   public TextureManager getTextureManager() {
/*  93 */     return this.textureManager;
/*     */   }
/*     */   
/*     */   public int getProgression() {
/*  97 */     return this.progression;
/*     */   }
/*     */   
/*     */   public void setProgression(int progression) {
/* 101 */     this.progression = progression;
/*     */   }
/*     */   
/*     */   public int getMax() {
/* 105 */     return this.max;
/*     */   }
/*     */   
/*     */   public void setMax(int max) {
/* 109 */     this.max = max;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\libs\CombinedTextureManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */