 package fr.wind_blade.isorropia.common.research;
 
 import java.util.UUID;
 import net.minecraft.entity.passive.EntityTameable;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.util.text.ITextComponent;
 import net.minecraft.util.text.TextComponentString;
 import net.minecraft.util.text.TextComponentTranslation;
 import net.minecraft.util.text.TextFormatting;
 import thaumcraft.api.capabilities.ThaumcraftCapabilities;
 import thaumcraft.api.research.IScanThing;
 
 public class ScanTameable implements IScanThing {
   public boolean checkThing(EntityPlayer var1, Object obj) {
/* 15 */     if (!(obj instanceof EntityTameable) || 
/* 16 */       !ThaumcraftCapabilities.getKnowledge(var1).isResearchKnown("INSTILLEDFIDELITY")) {
/* 17 */       return false;
     }
/* 19 */     EntityTameable tame = (EntityTameable)obj;
     
/* 21 */     if (tame.func_70909_n() && ScanFidelity.memory.containsKey(var1.func_110124_au()) && ((UUID)ScanFidelity.memory
/* 22 */       .get(var1.func_110124_au())).equals(tame.func_110124_au()))
/* 23 */       return true; 
/* 24 */     return false;
   }
 
   
   public void onSuccess(EntityPlayer player, Object object) {
/* 29 */     player.func_145747_a((ITextComponent)new TextComponentString(TextFormatting.DARK_PURPLE + (new TextComponentTranslation("scan.pretame", new Object[0]))
/* 30 */           .func_150254_d()));
/* 31 */     ScanFidelity.memory.remove(player.func_110124_au());
   }
 
   
   public String getResearchKey(EntityPlayer var1, Object var2) {
/* 36 */     return "!scan.fidelity";
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\research\ScanTameable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */