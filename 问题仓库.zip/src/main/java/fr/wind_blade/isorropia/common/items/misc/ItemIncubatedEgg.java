 package fr.wind_blade.isorropia.common.items.misc;
 
 import fr.wind_blade.isorropia.common.entities.projectile.EntityIncubatedEgg;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.init.SoundEvents;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemEgg;
 import net.minecraft.item.ItemStack;
 import net.minecraft.stats.StatList;
 import net.minecraft.util.ActionResult;
 import net.minecraft.util.EnumActionResult;
 import net.minecraft.util.EnumHand;
 import net.minecraft.util.SoundCategory;
 import net.minecraft.world.World;
 
 
 
 public class ItemIncubatedEgg
   extends ItemEgg
 {
   public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
/* 23 */     ItemStack stack = playerIn.func_184586_b(handIn);
/* 24 */     if (!playerIn.field_71075_bZ.field_75098_d) {
/* 25 */       stack.func_190918_g(1);
     }
     
/* 28 */     worldIn.func_184148_a((EntityPlayer)null, playerIn.field_70165_t, playerIn.field_70163_u, playerIn.field_70161_v, SoundEvents.field_187511_aA, SoundCategory.NEUTRAL, 0.5F, 0.4F / (field_77697_d
/* 29 */         .nextFloat() * 0.4F + 0.8F));
     
/* 31 */     if (!worldIn.field_72995_K) {
/* 32 */       EntityIncubatedEgg entityegg = new EntityIncubatedEgg(worldIn, playerIn);
/* 33 */       entityegg.func_184538_a((Entity)playerIn, playerIn.field_70125_A, playerIn.field_70177_z, 0.0F, 1.5F, 1.0F);
/* 34 */       worldIn.func_72838_d((Entity)entityegg);
/* 35 */       playerIn.func_71029_a(StatList.func_188057_b((Item)this));
     } 
/* 37 */     return new ActionResult(EnumActionResult.SUCCESS, stack);
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\misc\ItemIncubatedEgg.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */