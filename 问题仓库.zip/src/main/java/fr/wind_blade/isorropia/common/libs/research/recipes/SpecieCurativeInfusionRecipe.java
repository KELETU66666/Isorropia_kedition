 package fr.wind_blade.isorropia.common.libs.research.recipes;
 
 import fr.wind_blade.isorropia.Isorropia;
 import fr.wind_blade.isorropia.common.Common;
 import fr.wind_blade.isorropia.common.capabilities.LivingCapability;
 import fr.wind_blade.isorropia.common.tiles.TileVat;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityLiving;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.item.ItemStack;
 import net.minecraftforge.fml.common.FMLCommonHandler;
 import net.minecraftforge.fml.common.registry.EntityRegistry;
 
 public class SpecieCurativeInfusionRecipe extends CurativeInfusionRecipe {
   protected final Class<? extends EntityLiving> result;
   
   public SpecieCurativeInfusionRecipe(Builder<? extends Builder<?>> builder) {
/* 19 */     super(builder);
/* 20 */     this.result = builder.result;
/* 21 */     if (this.result == null) {
/* 22 */       Isorropia.logger.error("Specie Infusion Recipe can't have a null result");
/* 23 */       FMLCommonHandler.instance().exitJava(1, false);
     } 
   }
 
   
   public void applyWithCheat(EntityPlayer player, EntityLivingBase old, ItemStack stack) {
/* 29 */     EntityLiving entity = (EntityLiving)EntityRegistry.getEntry(this.result).newInstance(old.field_70170_p);
     
/* 31 */     if (entity == null)
       return; 
/* 33 */     ((LivingCapability)Common.getCap((EntityLivingBase)entity)).uuidOwner = player.func_110124_au();
/* 34 */     entity.func_70080_a(old.field_70165_t, old.field_70163_u, old.field_70165_t, old.field_70177_z, old.field_70125_A);
/* 35 */     old.field_70170_p.func_72838_d((Entity)entity);
/* 36 */     old.field_70170_p.func_72900_e((Entity)old);
/* 37 */     super.applyWithCheat(player, (EntityLivingBase)entity, stack);
   }
 
 
 
   
   public void onInfusionFinish(TileVat vat) {
/* 44 */     EntityLivingBase old = vat.getEntityContained();
/* 45 */     EntityLiving entity = (EntityLiving)EntityRegistry.getEntry(this.result).newInstance(vat.func_145831_w());
     
/* 47 */     if (entity == null)
       return; 
/* 49 */     ((LivingCapability)Common.getCap((EntityLivingBase)entity)).uuidOwner = vat.getRecipePlayer().func_110124_au();
/* 50 */     entity.func_70080_a(old.field_70165_t, old.field_70163_u, old.field_70165_t, old.field_70177_z, old.field_70125_A);
/* 51 */     vat.func_145831_w().func_72838_d((Entity)entity);
/* 52 */     vat.func_145831_w().func_72900_e((Entity)vat.setEntityContained((EntityLivingBase)entity, old.field_70177_z));
/* 53 */     super.onInfusionFinish(vat);
   }
   
   public Class<? extends EntityLiving> getResult() {
/* 57 */     return this.result;
   }
   
   public static class Builder<T extends Builder<T>> extends CurativeInfusionRecipe.Builder<T> {
/* 61 */     protected Class<? extends EntityLiving> result = null;
     
     public T withResult(Class<? extends EntityLiving> result) {
/* 64 */       this.result = result;
/* 65 */       return self();
     }
 
     
     public CurativeInfusionRecipe build() {
/* 70 */       return new SpecieCurativeInfusionRecipe(this);
     }
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\research\recipes\SpecieCurativeInfusionRecipe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */