/*     */ package fr.wind_blade.isorropia.common;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.celestial.CelestialBody;
/*     */ import fr.wind_blade.isorropia.common.celestial.ICelestialBody;
/*     */ import fr.wind_blade.isorropia.common.curative.ICurativeEffectProvider;
/*     */ import fr.wind_blade.isorropia.common.items.IJellyAspectEffectProvider;
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import fr.wind_blade.isorropia.common.lenses.Lens;
/*     */ import fr.wind_blade.isorropia.common.research.recipes.CurativeInfusionRecipe;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileVat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.common.FMLLog;
/*     */ import net.minecraftforge.registries.ForgeRegistry;
/*     */ import thaumcraft.api.ThaumcraftApi;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IsorropiaAPI
/*     */ {
/*  30 */   public static final Ingredient DEFAULT_INFUSION_FAKE = Ingredient.func_193367_a(ItemsIS.itemCat);
/*     */   
/*  32 */   public static final Aspect HUNGER = new Aspect("fames", 10093317, new Aspect[] { Aspect.LIFE, Aspect.VOID }, new ResourceLocation("isorropia", "textures/aspects/fames.png"), 1);
/*     */   
/*  34 */   public static final Aspect FLESH = new Aspect("corpus", 15615885, new Aspect[] { Aspect.DEATH, Aspect.BEAST }, new ResourceLocation("isorropia", "textures/aspects/corpus.png"), 1);
/*     */   
/*  36 */   public static final Aspect ENVY = new Aspect("invidia", 47616, new Aspect[] { Aspect.SENSES, HUNGER }, new ResourceLocation("isorropia", "textures/aspects/invidia.png"), 1);
/*     */   
/*  38 */   public static final Aspect GLUTTONY = new Aspect("gula", 13999174, new Aspect[] { HUNGER, Aspect.VOID }, new ResourceLocation("isorropia", "textures/aspects/gula.png"), 1);
/*     */ 
/*     */   
/*  41 */   public static final Aspect LUST = new Aspect("luxuria", 16761294, new Aspect[] { FLESH, HUNGER }, new ResourceLocation("isorropia", "textures/aspects/luxuria.png"), 1);
/*     */ 
/*     */   
/*  44 */   public static final Aspect NETHER = new Aspect("infernus", 16711680, new Aspect[] { Aspect.FIRE, Aspect.MAGIC }, new ResourceLocation("isorropia", "textures/aspects/infernus.png"), 771);
/*     */   
/*  46 */   public static final Aspect PRIDE = new Aspect("superbia", 9845247, new Aspect[] { Aspect.FLIGHT, Aspect.VOID }, new ResourceLocation("isorropia", "textures/aspects/superbia.png"), 1);
/*     */   
/*  48 */   public static final Aspect SLOTH = new Aspect("desidia", 7237230, new Aspect[] { Aspect.TRAP, Aspect.SOUL }, new ResourceLocation("isorropia", "textures/aspects/desidia.png"), 771);
/*     */   
/*  50 */   public static final Aspect WRATH = new Aspect("ira", 8848388, new Aspect[] { Aspect.AVERSION, Aspect.FIRE }, new ResourceLocation("isorropia", "textures/aspects/ira.png"), 771);
/*     */   
/*     */   public static Lens air_lens;
/*     */   
/*     */   public static Lens fire_lens;
/*     */   
/*     */   public static Lens ordo_lens;
/*  57 */   public static Map<ResourceLocation, Lens> lens = new HashMap<>(); public static Lens lust_lens; public static Lens envy_lens; public static Lens gluttony_lens; public static ForgeRegistry<Lens> lensRegistry;
/*  58 */   public static Map<ResourceLocation, CurativeInfusionRecipe> creatureInfusionRecipes = new HashMap<>();
/*  59 */   public static Map<CurativeInfusionRecipe, ResourceLocation> creatureInfusionRecipesLocal = new HashMap<>();
/*  60 */   private static final HashMap<ResourceLocation, ICelestialBody> registryCelestialBody = new HashMap<>();
/*     */   
/*  62 */   public static final List<ICurativeEffectProvider> curativeEffects = new ArrayList<>();
/*  63 */   private static final Map<Aspect, IJellyAspectEffectProvider> jellyEffects = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void registerLens(Lens lens, ResourceLocation registryName) {
/*  79 */     IsorropiaAPI.lens.put(registryName, lens);
/*     */   }
/*     */   
/*     */   public static void registerCelestialBody(ResourceLocation registryName, ICelestialBody celestialBody) {
/*  83 */     if (registryName == null || celestialBody == null) {
/*  84 */       FMLLog.log.debug("Skipping automatic mod {} celestial body registration, celestial body or his registry name can't be null {} class {}", registryName
/*     */           
/*  86 */           .func_110623_a(), registryName, celestialBody.getClass());
/*     */     } else {
/*  88 */       registryCelestialBody.put(registryName, celestialBody);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerCreatureInfusionRecipe(ResourceLocation registryLocation, CurativeInfusionRecipe recipeIn) {
/* 103 */     if (!creatureInfusionRecipes.containsKey(registryLocation)) {
/* 104 */       creatureInfusionRecipes.put(registryLocation, recipeIn);
/* 105 */       creatureInfusionRecipesLocal.put(recipeIn, registryLocation);
/* 106 */       ThaumcraftApi.addFakeCraftingRecipe(registryLocation, recipeIn);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void registerCurativeEffect(ICurativeEffectProvider effect) {
/* 111 */     if (!curativeEffects.contains(effect)) {
/* 112 */       curativeEffects.add(effect);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void bindJellyAspectEffect(Aspect aspect, IJellyAspectEffectProvider provider) {
/* 117 */     jellyEffects.put(aspect, provider);
/*     */   }
/*     */   
/*     */   public static IJellyAspectEffectProvider getJellyAspectEffect(Aspect aspect) {
/* 121 */     return jellyEffects.get(aspect);
/*     */   }
/*     */   
/*     */   public static CurativeInfusionRecipe findMatchingCreatureInfusionRecipe(EntityLivingBase entityContained, ArrayList<ItemStack> components, EntityPlayer player, TileVat vat) {
/*     */     CurativeInfusionRecipe recipe;
/* 126 */     Iterator<CurativeInfusionRecipe> var3 = creatureInfusionRecipes.values().iterator();
/*     */ 
/*     */     
/*     */     do {
/* 130 */       if (!var3.hasNext()) {
/* 131 */         return null;
/*     */       }
/*     */       
/* 134 */       recipe = var3.next();
/* 135 */     } while (!recipe.matches(components, entityContained, player.field_70170_p, player, vat));
/*     */     
/* 137 */     return recipe;
/*     */   }
/*     */   
/*     */   public static ICelestialBody getCelestialBodyByRegistryName(ResourceLocation registryName) {
/* 141 */     return registryCelestialBody.values().stream().filter(body -> body.getRegistryName().equals(registryName))
/* 142 */       .findFirst().orElse(CelestialBody.NONE);
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\IsorropiaAPI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */