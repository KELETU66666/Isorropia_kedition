 package fr.wind_blade.isorropia.common.network;
 
 import io.netty.buffer.ByteBuf;
 import net.minecraft.block.Block;
 import net.minecraft.entity.player.EntityPlayerMP;
 import net.minecraft.item.ItemStack;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.util.math.BlockPos;
 import net.minecraft.world.World;
 import net.minecraftforge.common.DimensionManager;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
 import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
 import thaumcraft.api.blocks.BlocksTC;
 
 
 
 
 
 
 
 public class MirrorMessage
   implements IMessage
 {
   private BlockPos pos;
   
   public MirrorMessage() {}
   
   public MirrorMessage(BlockPos pos) {
/* 30 */     this.pos = pos;
   }
 
   
   public void fromBytes(ByteBuf buf) {
/* 35 */     this.pos = BlockPos.func_177969_a(buf.readLong());
   }
 
   
   public void toBytes(ByteBuf buf) {
/* 40 */     buf.writeLong(this.pos.func_177986_g());
   }
 
   
   public static class MirrorMessageHandler
     implements IMessageHandler<MirrorMessage, IMessage>
   {
     public IMessage onMessage(final MirrorMessage message, final MessageContext ctx) {
/* 48 */       final EntityPlayerMP player = (ctx.getServerHandler()).field_147369_b;
/* 49 */       player.func_71121_q().func_152344_a(new Runnable()
           {
             public void run() {
/* 52 */               if (!(ctx.getServerHandler()).field_147369_b.field_70170_p.func_175697_a(message.pos, 1))
/* 53 */                 return;  World worldIn = player.field_70170_p;
/* 54 */               ItemStack stack = player.field_71071_by.func_70448_g();
/* 55 */               if (!(stack.func_77973_b() instanceof fr.wind_blade.isorropia.common.items.baubles.ItemBaubleMirror))
                 return; 
/* 57 */               Block block = worldIn.func_180495_p(message.pos).func_177230_c();
/* 58 */               if (block == BlocksTC.mirror) {
/* 59 */                 NBTTagCompound compound = new NBTTagCompound();
/* 60 */                 compound.func_74768_a("linkX", message.pos.func_177958_n());
/* 61 */                 compound.func_74768_a("linkY", message.pos.func_177956_o());
/* 62 */                 compound.func_74768_a("linkZ", message.pos.func_177952_p());
/* 63 */                 compound.func_74768_a("linkDim", worldIn.field_73011_w.getDimension());
/* 64 */                 compound.func_74778_a("dimname", DimensionManager.getProvider(worldIn.field_73011_w.getDimension())
/* 65 */                     .func_186058_p().func_186065_b());
/* 66 */                 stack.func_77982_d(compound);
/* 67 */                 player.field_71069_bz.func_75142_b();
               } 
             }
           });
/* 71 */       return null;
     }
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\network\MirrorMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */