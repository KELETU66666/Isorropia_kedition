/*     */ package fr.wind_blade.isorropia.client.renderer.tiles;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.tiles.TileCelestialMagnet;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.fml.client.FMLClientHandler;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.renderers.models.ModelCube;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderCelestialMagnet
/*     */   extends TileEntitySpecialRenderer<TileCelestialMagnet>
/*     */ {
/*  27 */   private ModelCube model = new ModelCube(0);
/*  28 */   private ModelCube center = new ModelCube(0);
/*  29 */   private ModelCube model_over = new ModelCube(32);
/*     */   
/*  31 */   private static final ResourceLocation tex1 = new ResourceLocation("thaumcraft", "textures/blocks/infuser_normal.png");
/*     */   
/*  33 */   private static final ResourceLocation[] tex2 = new ResourceLocation[10];
/*     */   
/*     */   static {
/*  36 */     for (int i = 0; i < 10; i++) {
/*  37 */       tex2[i] = new ResourceLocation("isorropia", "textures/blocks/balanced_crystal_" + (i + 1) + ".png");
/*     */     }
/*     */   }
/*     */   
/*     */   private void drawHalo(TileEntity is, double x, double y, double z, float par8, int count) {
/*  42 */     GL11.glPushMatrix();
/*  43 */     GL11.glTranslated(x + 0.5D, y + 0.5D, z + 0.5D);
/*  44 */     int q = !(FMLClientHandler.instance().getClient()).field_71474_y.field_74347_j ? 10 : 20;
/*  45 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  46 */     RenderHelper.func_74518_a();
/*  47 */     float f1 = count / 500.0F;
/*  48 */     float f2 = 0.0F;
/*  49 */     Random random = new Random(245L);
/*  50 */     GL11.glDisable(3553);
/*  51 */     GL11.glShadeModel(7425);
/*  52 */     GL11.glEnable(3042);
/*  53 */     GL11.glBlendFunc(770, 1);
/*  54 */     GL11.glDisable(3008);
/*  55 */     GL11.glEnable(2884);
/*  56 */     GL11.glDepthMask(false);
/*  57 */     GL11.glPushMatrix();
/*  58 */     for (int i = 0; i < q; i++) {
/*  59 */       GL11.glRotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
/*  60 */       GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
/*  61 */       GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 0.0F, 1.0F);
/*  62 */       GL11.glRotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
/*  63 */       GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
/*  64 */       GL11.glRotatef(random.nextFloat() * 360.0F + f1 * 360.0F, 0.0F, 0.0F, 1.0F);
/*  65 */       tessellator.func_178180_c().func_181668_a(6, DefaultVertexFormats.field_181706_f);
/*  66 */       float fa = random.nextFloat() * 20.0F + 5.0F + f2 * 10.0F;
/*  67 */       float f4 = random.nextFloat() * 2.0F + 1.0F + f2 * 2.0F;
/*  68 */       tessellator.func_178180_c().func_181662_b(0.0D, 0.0D, 0.0D).func_181669_b(255, 255, 255, (int)(255.0F * (1.0F - f1))).func_181675_d();
/*  69 */       tessellator.func_178180_c().func_181662_b(-0.866D * f4, (fa /= 20.0F / Math.min(count, 50) / 50.0F), (-0.5F * (f4 /= 20.0F / 
/*  70 */           Math.min(count, 50) / 50.0F))).func_181669_b(255, 0, 255, 0).func_181675_d();
/*  71 */       tessellator.func_178180_c().func_181662_b(0.866D * f4, fa, (-0.5F * f4)).func_181669_b(255, 0, 255, 0).func_181675_d();
/*  72 */       tessellator.func_178180_c().func_181662_b(0.0D, fa, (1.0F * f4)).func_181669_b(255, 0, 255, 0).func_181675_d();
/*  73 */       tessellator.func_178180_c().func_181662_b(-0.866D * f4, fa, (-0.5F * f4)).func_181669_b(255, 0, 255, 0).func_181675_d();
/*  74 */       tessellator.func_78381_a();
/*     */     } 
/*  76 */     GL11.glPopMatrix();
/*  77 */     GL11.glDepthMask(true);
/*  78 */     GL11.glDisable(2884);
/*  79 */     GL11.glDisable(3042);
/*  80 */     GL11.glShadeModel(7424);
/*  81 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  82 */     GL11.glEnable(3553);
/*  83 */     GL11.glEnable(3008);
/*  84 */     RenderHelper.func_74519_b();
/*  85 */     GL11.glBlendFunc(770, 771);
/*  86 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderMatrix(TileCelestialMagnet te, double par2, double par4, double par6, float par8, int destroyStage) {
/*  95 */     GL11.glPushMatrix();
/*  96 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4 + 0.5F, (float)par6 + 0.5F);
/*     */     
/*  98 */     float ticks = (Minecraft.func_71410_x().func_175606_aa()).field_70173_aa + par8;
/*  99 */     float inst = 1.0F;
/* 100 */     int craftcount = 3;
/* 101 */     float startup = 3.0F;
/* 102 */     boolean active = true;
/* 103 */     boolean crafting = true;
/* 104 */     func_147499_a(tex1);
/*     */     
/* 106 */     if (destroyStage >= 0) {
/* 107 */       func_147499_a(field_178460_a[destroyStage]);
/* 108 */       GlStateManager.func_179128_n(5890);
/* 109 */       GlStateManager.func_179094_E();
/* 110 */       GlStateManager.func_179152_a(4.0F, 4.0F, 1.0F);
/* 111 */       GlStateManager.func_179109_b(0.0625F, 0.0625F, 0.0625F);
/* 112 */       GlStateManager.func_179128_n(5888);
/*     */     } 
/* 114 */     float instability = Math.min(6.0F, 1.0F + ((inst < 0.0F) ? (-inst * 0.66F) : 1.0F) * 
/* 115 */         Math.min(craftcount, 50) / 50.0F);
/* 116 */     float b1 = 0.0F;
/* 117 */     float b2 = 0.0F;
/* 118 */     float b3 = 0.0F;
/* 119 */     int aa = 0;
/* 120 */     int bb = 0;
/* 121 */     int cc = 0;
/*     */     
/* 123 */     GL11.glRotatef(ticks % 360.0F * startup, 0.0F, 1.0F, 0.0F);
/* 124 */     GL11.glRotatef(35.0F * startup, 1.0F, 0.0F, 0.0F);
/* 125 */     GL11.glRotatef(45.0F * startup, 0.0F, 0.0F, 1.0F);
/*     */     int a;
/* 127 */     for (a = 0; a < 2; a++) {
/* 128 */       for (int b = 0; b < 2; b++) {
/* 129 */         for (int c = 0; c < 2; c++) {
/* 130 */           if (active) {
/* 131 */             b1 = MathHelper.func_76126_a((ticks + (a * 10)) / 15.0F) * 0.01F * startup * instability;
/* 132 */             b2 = MathHelper.func_76126_a((ticks + (b * 10)) / 14.0F) * 0.01F * startup * instability;
/* 133 */             b3 = MathHelper.func_76126_a((ticks + (c * 10)) / 13.0F) * 0.01F * startup * instability;
/*     */           } 
/* 135 */           aa = (a == 0) ? -1 : 1;
/* 136 */           bb = (b == 0) ? -1 : 1;
/* 137 */           cc = (c == 0) ? -1 : 1;
/* 138 */           GL11.glPushMatrix();
/* 139 */           GL11.glTranslatef(b1 + aa * 0.25F, b2 + bb * 0.25F, b3 + cc * 0.25F);
/* 140 */           if (a > 0) {
/* 141 */             GL11.glRotatef(90.0F, a, 0.0F, 0.0F);
/*     */           }
/* 143 */           if (b > 0) {
/* 144 */             GL11.glRotatef(90.0F, 0.0F, b, 0.0F);
/*     */           }
/* 146 */           if (c > 0) {
/* 147 */             GL11.glRotatef(90.0F, 0.0F, 0.0F, c);
/*     */           }
/* 149 */           GL11.glScaled(0.2D, 0.2D, 0.2D);
/* 150 */           this.model.render();
/* 151 */           GL11.glPopMatrix();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 157 */     if (!active) {
/* 158 */       GL11.glPushMatrix();
/* 159 */       GL11.glAlphaFunc(516, 0.003921569F);
/* 160 */       GL11.glEnable(3042);
/* 161 */       GL11.glBlendFunc(770, 1);
/* 162 */       for (a = 0; a < 2; a++) {
/* 163 */         for (int b = 0; b < 2; b++) {
/* 164 */           for (int c = 0; c < 2; c++) {
/* 165 */             b1 = MathHelper.func_76126_a((ticks + (a * 10)) / 15.0F) * 0.01F * startup * instability;
/* 166 */             b2 = MathHelper.func_76126_a((ticks + (b * 10)) / 14.0F) * 0.01F * startup * instability;
/* 167 */             b3 = MathHelper.func_76126_a((ticks + (c * 10)) / 13.0F) * 0.01F * startup * instability;
/* 168 */             aa = (a == 0) ? -1 : 1;
/* 169 */             bb = (b == 0) ? -1 : 1;
/* 170 */             cc = (c == 0) ? -1 : 1;
/* 171 */             GL11.glPushMatrix();
/* 172 */             GL11.glTranslatef(b1 + aa * 0.25F, b2 + bb * 0.25F, b3 + cc * 0.25F);
/* 173 */             if (a > 0) {
/* 174 */               GL11.glRotatef(90.0F, a, 0.0F, 0.0F);
/*     */             }
/* 176 */             if (b > 0) {
/* 177 */               GL11.glRotatef(90.0F, 0.0F, b, 0.0F);
/*     */             }
/* 179 */             if (c > 0) {
/* 180 */               GL11.glRotatef(90.0F, 0.0F, 0.0F, c);
/*     */             }
/* 182 */             GL11.glScaled(0.45D, 0.45D, 0.45D);
/* 183 */             int j = 15728880;
/* 184 */             int k = j % 65536;
/* 185 */             int l = j / 65536;
/* 186 */             OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, k / 1.0F, l / 1.0F);
/* 187 */             GL11.glColor4f(0.8F, 0.1F, 1.0F, (
/* 188 */                 MathHelper.func_76126_a((ticks + (a * 2) + (b * 3) + (c * 4)) / 4.0F) * 0.1F + 0.2F) * startup);
/* 189 */             this.model_over.render();
/* 190 */             GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 191 */             GL11.glPopMatrix();
/*     */           } 
/*     */         } 
/*     */       } 
/* 195 */       GL11.glBlendFunc(770, 771);
/* 196 */       GL11.glDisable(3042);
/* 197 */       GL11.glAlphaFunc(516, 0.1F);
/* 198 */       GL11.glPopMatrix();
/*     */     } 
/* 200 */     if (destroyStage >= 0) {
/* 201 */       GlStateManager.func_179128_n(5890);
/* 202 */       GlStateManager.func_179121_F();
/* 203 */       GlStateManager.func_179128_n(5888);
/*     */     } 
/* 205 */     GL11.glPopMatrix();
/* 206 */     if (crafting) {
/* 207 */       drawHalo((TileEntity)te, par2, par4, par6, par8, craftcount);
/*     */     }
/*     */     
/* 210 */     GL11.glPushMatrix();
/* 211 */     func_147499_a(tex2[(int)(ticks % 10.0F)]);
/* 212 */     GL11.glAlphaFunc(516, 0.003921569F);
/* 213 */     GL11.glEnable(3042);
/* 214 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4 + 0.5F, (float)par6 + 0.5F);
/* 215 */     GL11.glTranslatef(b1, b2, b3);
/* 216 */     GL11.glRotatef(ticks % 360.0F * startup, 0.0F, 1.0F, 0.0F);
/* 217 */     GL11.glRotatef(35.0F * startup, 1.0F, 0.0F, 0.0F);
/* 218 */     GL11.glRotatef(45.0F * startup, 0.0F, 0.0F, 1.0F);
/* 219 */     GL11.glScaled(0.5D, 0.5D, 0.5D);
/* 220 */     this.center.render();
/* 221 */     GL11.glDisable(3042);
/* 222 */     GL11.glAlphaFunc(516, 0.1F);
/* 223 */     GL11.glPopMatrix();
/* 224 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(TileCelestialMagnet te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
/* 230 */     super.func_192841_a((TileEntity)te, x, y, z, partialTicks, destroyStage, alpha);
/* 231 */     renderMatrix(te, x, y, z, partialTicks, destroyStage);
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\tiles\RenderCelestialMagnet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */