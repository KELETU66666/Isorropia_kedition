package fr.wind_blade.isorropia.common.entities.ai;

public interface IEatStone {
  void eatStone();
}


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\ai\IEatStone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */