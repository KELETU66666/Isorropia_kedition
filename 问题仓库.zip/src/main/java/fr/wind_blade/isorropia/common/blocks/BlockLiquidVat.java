/*     */ package fr.wind_blade.isorropia.common.blocks;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.blocks.material.MaterialIR;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileVat;
/*     */ import net.minecraft.block.BlockLiquid;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.EnumBlockRenderType;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockLiquidVat
/*     */   extends BlockLiquid implements IBlockRegistry {
/*     */   public BlockLiquidVat() {
/*  24 */     super(MaterialIR.LIQUID_VAT);
/*  25 */     func_149711_c(3.0F);
/*  26 */     func_149752_b(15.0F);
/*  27 */     this.field_149784_t = 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176200_f(IBlockAccess worldIn, BlockPos pos) {
/*  32 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
/*  37 */     TileVat tile = getMaster(worldIn, state, pos);
/*     */     
/*  39 */     if (tile != null) {
/*  40 */       tile.destroyMultiBlock();
/*     */     }
/*     */     
/*  43 */     super.func_180663_b(worldIn, pos, state);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
/*  49 */     TileVat vat = BlockCurativeVat.getMaster(worldIn, pos);
/*     */     
/*  51 */     if (vat != null && vat.getEntityContained() == playerIn) {
/*  52 */       vat.onBlockRigthClick(playerIn, facing, false);
/*     */     }
/*     */     
/*  55 */     return super.func_180639_a(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isEntityInsideMaterial(IBlockAccess world, BlockPos blockpos, IBlockState iblockstate, Entity entity, double yToTest, Material materialIn, boolean testingHead) {
/*  61 */     if (materialIn == MaterialIR.LIQUID_VAT || materialIn == Material.field_151586_h)
/*  62 */       return Boolean.valueOf(true); 
/*  63 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   public TileVat getMaster(World worldIn, IBlockState state, BlockPos pos) {
/*  67 */     for (int i = 1; i <= 2; i++) {
/*  68 */       TileEntity te = worldIn.func_175625_s(pos.func_177981_b(i));
/*     */       
/*  70 */       if (te instanceof TileVat) {
/*  71 */         return (TileVat)te;
/*     */       }
/*     */     } 
/*     */     
/*  75 */     return null;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BlockRenderLayer getBlockLayer() {
/*  80 */     return BlockRenderLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public EnumBlockRenderType func_149645_b(IBlockState state) {
/*  85 */     return EnumBlockRenderType.INVISIBLE;
/*     */   }
/*     */   
/*     */   public boolean isFullyOpaque(IBlockState state) {
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149721_r(IBlockState state) {
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c(IBlockState state) {
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149637_q(IBlockState state) {
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149730_j(IBlockState state) {
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149751_l(IBlockState state) {
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isVisuallyOpaque() {
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d(IBlockState state) {
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInCreativeTabs() {
/* 128 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockLiquidVat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */