/*     */ package fr.wind_blade.isorropia.client.renderer.tiles;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.minecraft.MinecraftProfileTexture;
/*     */ import fr.wind_blade.isorropia.common.blocks.BlockStatue;
/*     */ import fr.wind_blade.isorropia.common.libs.IsorropiaCache;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileStatue;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelPlayer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.client.resources.DefaultPlayerSkin;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.nbt.NBTUtil;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderStatue
/*     */   extends TileEntitySpecialRenderer<TileStatue>
/*     */ {
/*  34 */   public static final ModelPlayer steveModel = new ModelPlayer(0.03125F, false);
/*  35 */   public static final ModelPlayer alexModel = new ModelPlayer(0.03125F, true);
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(TileStatue statue, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
/*  40 */     if (statue.getEntityData() == null) {
/*     */       return;
/*     */     }
/*  43 */     if (statue.getEntityData().func_74779_i("ENTITY_ID").equals("PLAYER")) {
/*  44 */       GlStateManager.func_179094_E();
/*  45 */       TextureManager textureManager = this.field_147501_a.field_147553_e;
/*  46 */       this.field_147501_a.field_147553_e = (TextureManager)IsorropiaCache.loadStatueTextureManager(textureManager);
/*  47 */       renderPlayer(statue, x, y, z, 
/*  48 */           NBTUtil.func_152459_a(statue.getEntityData().func_74775_l("ENTITY_DATA")), destroyStage);
/*     */       
/*  50 */       GlStateManager.func_179121_F();
/*  51 */       this.field_147501_a.field_147553_e = textureManager;
/*  52 */     } else if (statue.getEntityData().func_74779_i("ENTITY_ID").equals("LIVING") && statue
/*  53 */       .getEntity() != null) {
/*     */       
/*  55 */       Render<Entity> render = Minecraft.func_71410_x().func_175598_ae().func_78713_a(statue.getEntity());
/*  56 */       if (render != null) {
/*  57 */         RenderManager manager = Minecraft.func_71410_x().func_175598_ae();
/*  58 */         TextureManager textureManager = manager.field_78724_e;
/*  59 */         manager.field_78724_e = (TextureManager)IsorropiaCache.loadStatueTextureManager(textureManager);
/*     */         
/*  61 */         GlStateManager.func_179094_E();
/*  62 */         GlStateManager.func_179137_b(x + 0.5D, y, z + 0.5D);
/*  63 */         GlStateManager.func_179114_b((((EnumFacing)statue.func_145831_w().func_180495_p(statue.func_174877_v()).func_177229_b((IProperty)BlockStatue.FACING))
/*  64 */             .func_176736_b() * -90 + 180), 0.0F, 1.0F, 0.0F);
/*  65 */         render.func_76986_a(statue.getEntity(), 0.0D, 0.0D, 0.0D, 0.0F, 0.0F);
/*  66 */         manager.field_78724_e = textureManager;
/*  67 */         GlStateManager.func_179121_F();
/*     */       } 
/*     */     } 
/*  70 */     super.func_192841_a((TileEntity)statue, x, y, z, partialTicks, destroyStage, alpha);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderPlayer(TileStatue statue, double x, double y, double z, @Nullable GameProfile profile, int destroyStage) {
/*  76 */     ResourceLocation skinlocation = DefaultPlayerSkin.func_177335_a();
/*  77 */     ModelPlayer playerModel = steveModel;
/*     */     
/*  79 */     GlStateManager.func_179137_b(x + 0.5D, y + 1.401D, z + 0.5D);
/*  80 */     GlStateManager.func_179114_b((((EnumFacing)statue
/*  81 */         .func_145831_w().func_180495_p(statue.func_174877_v()).func_177229_b((IProperty)BlockStatue.FACING)).func_176736_b() * -90 + 180), 0.0F, 1.0F, 0.0F);
/*     */ 
/*     */ 
/*     */     
/*  85 */     if (destroyStage >= 0) {
/*  86 */       func_147499_a(field_178460_a[destroyStage]);
/*  87 */       GlStateManager.func_179128_n(5890);
/*  88 */       GlStateManager.func_179152_a(4.0F, 4.0F, 1.0F);
/*  89 */       GlStateManager.func_179109_b(0.0625F, 0.0625F, 0.0625F);
/*  90 */       GlStateManager.func_179128_n(5888);
/*     */     } else {
/*  92 */       if (profile != null) {
/*  93 */         Minecraft minecraft = Minecraft.func_71410_x();
/*  94 */         Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> map = minecraft.func_152342_ad().func_152788_a(profile);
/*     */         
/*  96 */         if (map.containsKey(MinecraftProfileTexture.Type.SKIN)) {
/*  97 */           skinlocation = minecraft.func_152342_ad().func_152789_a(map.get(MinecraftProfileTexture.Type.SKIN), MinecraftProfileTexture.Type.SKIN, null);
/*     */         } else {
/*  99 */           UUID uuid = EntityPlayer.func_146094_a(profile);
/* 100 */           skinlocation = DefaultPlayerSkin.func_177334_a(uuid);
/*     */         } 
/*     */         
/* 103 */         if ((profile.getId().hashCode() & 0x1) == 1) {
/* 104 */           playerModel = alexModel;
/*     */         }
/*     */       } 
/*     */       
/* 108 */       func_147499_a(skinlocation);
/*     */     } 
/*     */     
/* 111 */     GlStateManager.func_179129_p();
/* 112 */     GlStateManager.func_179091_B();
/* 113 */     GlStateManager.func_179152_a(-1.875F, -1.875F, 1.875F);
/* 114 */     GlStateManager.func_179141_d();
/* 115 */     GlStateManager.func_187408_a(GlStateManager.Profile.PLAYER_SKIN);
/* 116 */     playerModel.field_78091_s = false;
/* 117 */     playerModel.field_78115_e.func_78785_a(0.03125F);
/* 118 */     playerModel.field_78116_c.func_78785_a(0.03125F);
/* 119 */     playerModel.field_178724_i.func_78785_a(0.03125F);
/* 120 */     playerModel.field_178723_h.func_78785_a(0.03125F);
/* 121 */     playerModel.field_178722_k.func_78785_a(0.03125F);
/* 122 */     playerModel.field_178721_j.func_78785_a(0.03125F);
/* 123 */     playerModel.field_178730_v.func_78785_a(0.03125F);
/* 124 */     playerModel.field_178720_f.func_78785_a(0.03125F);
/* 125 */     playerModel.field_178734_a.func_78785_a(0.03125F);
/* 126 */     playerModel.field_178732_b.field_82907_q = -0.3125F;
/* 127 */     playerModel.field_178732_b.func_78785_a(0.03125F);
/* 128 */     playerModel.field_178733_c.func_78785_a(0.03125F);
/* 129 */     playerModel.field_178731_d.func_78785_a(0.03125F);
/*     */     
/* 131 */     if (destroyStage >= 0) {
/* 132 */       GlStateManager.func_179128_n(5890);
/* 133 */       GlStateManager.func_179128_n(5888);
/*     */     } 
/*     */     
/* 136 */     GlStateManager.func_187440_b(GlStateManager.Profile.PLAYER_SKIN);
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\renderer\tiles\RenderStatue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */