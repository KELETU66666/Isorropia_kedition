/*     */ package fr.wind_blade.isorropia.client.gui;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.network.MagnetMessage;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileCelestialMagnet;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderItem;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.client.gui.plugins.GuiImageButton;
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiCelestialMagnet
/*     */   extends GuiScreen
/*     */ {
/*  30 */   ResourceLocation tex = new ResourceLocation("isorropia", "textures/gui/gui_magnet.png");
/*     */   
/*     */   private final TileCelestialMagnet magnet;
/*     */   private GuiImageButton mob;
/*     */   private GuiImageButton areaLeft;
/*     */   private GuiImageButton areaRight;
/*     */   private GuiButton item;
/*     */   private GuiButton aspect;
/*     */   
/*     */   public GuiCelestialMagnet(TileCelestialMagnet magnetIn) {
/*  40 */     this.magnet = magnetIn;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_73866_w_() {
/*  45 */     int k = this.field_146294_l;
/*  46 */     int l = this.field_146295_m;
/*  47 */     int i = 0;
/*  48 */     int j = 0;
/*  49 */     for (Aspect aspect : Aspect.aspects.values()) {
/*  50 */       int x = k / 2 + i * 17 - 68;
/*  51 */       int y = l / 2 + 0 - 80 + 16 * j;
/*  52 */       GuiCelestialAspectButton button = new GuiCelestialAspectButton(i, x, y, aspect, null);
/*  53 */       if (this.magnet.hasFilter(aspect))
/*  54 */         button.active = true; 
/*  55 */       this.field_146292_n.add(button);
/*  56 */       i++;
/*  57 */       if (i != 0 && i % 8 == 0) {
/*  58 */         j++;
/*  59 */         i = 0;
/*     */       } 
/*     */     } 
/*  62 */     this.mob = new GuiImageButton(this, 0, k / 2 + 84, l / 2 - 80, 16, 16, null, null, this.tex, 240, 16, 16, 16)
/*     */       {
/*     */         public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
/*  65 */           if (mouseX >= this.field_146128_h - this.field_146120_f / 2 && mouseY >= this.field_146129_i - this.field_146121_g / 2 && mouseX < this.field_146128_h - this.field_146120_f / 2 + this.field_146120_f && mouseY < this.field_146129_i - this.field_146121_g / 2 + this.field_146121_g) {
/*     */ 
/*     */             
/*  68 */             this.active = !this.active;
/*  69 */             GuiCelestialMagnet.this.magnet.setFilter(this.active ? (
/*  70 */                 (GuiCelestialMagnet.this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.item) ? TileCelestialMagnet.EntityFilter.both : TileCelestialMagnet.EntityFilter.mob) : (
/*     */ 
/*     */                 
/*  73 */                 (GuiCelestialMagnet.this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.both) ? TileCelestialMagnet.EntityFilter.item : TileCelestialMagnet.EntityFilter.none));
/*     */ 
/*     */             
/*  76 */             Common.INSTANCE.sendToServer((IMessage)new MagnetMessage(GuiCelestialMagnet.this.magnet.func_174877_v(), null, GuiCelestialMagnet.this.magnet.getEntityFilter(), 
/*  77 */                   GuiCelestialMagnet.this.magnet.aspectFilter, GuiCelestialMagnet.this.magnet.area));
/*  78 */             return true;
/*     */           } 
/*  80 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/*  85 */           GlStateManager.func_179094_E();
/*  86 */           GlStateManager.func_179147_l();
/*  87 */           GlStateManager.func_179120_a(770, 771, 1, 0);
/*  88 */           GlStateManager.func_179112_b(770, 771);
/*  89 */           Color c = new Color(this.color);
/*  90 */           GlStateManager.func_179131_c(c.getRed() / 255.0F, c.getGreen() / 255.0F, c.getBlue() / 255.0F, 1.0F);
/*  91 */           mc.func_110434_K().func_110577_a(GuiCelestialMagnet.this.tex);
/*  92 */           func_73729_b(this.field_146128_h - 8, this.field_146129_i - 8, 240, 16, 16, 16);
/*  93 */           GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*  94 */           if (!this.active) {
/*  95 */             GL11.glAlphaFunc(516, 0.003921569F);
/*  96 */             GL11.glEnable(3042);
/*  97 */             GL11.glBlendFunc(770, 771);
/*  98 */             func_73729_b(this.field_146128_h - 8, this.field_146129_i - 8, 240, 0, 16, 16);
/*     */           } 
/* 100 */           GlStateManager.func_179121_F();
/* 101 */           func_146119_b(mc, mouseX, mouseY);
/*     */         }
/*     */       };
/* 104 */     this.item = new GuiButton(1, k / 2 + 76, l / 2 - 72, 14, 14, null)
/*     */       {
/*     */         public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/* 107 */           GlStateManager.func_179094_E();
/* 108 */           GL11.glAlphaFunc(516, 0.003921569F);
/* 109 */           GL11.glEnable(3042);
/* 110 */           GL11.glBlendFunc(770, 771);
/* 111 */           RenderItem ri = Minecraft.func_71410_x().func_175599_af();
/* 112 */           ri.func_175042_a(new ItemStack(Items.field_151108_aI), this.field_146128_h, this.field_146129_i);
/* 113 */           if (!this.field_146124_l) {
/* 114 */             mc.func_110434_K().func_110577_a(GuiCelestialMagnet.this.tex);
/* 115 */             func_73729_b(this.field_146128_h, this.field_146129_i + 1, 240, 0, 16, 16);
/*     */           } 
/* 117 */           GlStateManager.func_179121_F();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
/* 122 */           if (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g) {
/*     */             
/* 124 */             this.field_146124_l = !this.field_146124_l;
/* 125 */             GuiCelestialMagnet.this.magnet.setFilter(this.field_146124_l ? (
/* 126 */                 (GuiCelestialMagnet.this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.mob) ? TileCelestialMagnet.EntityFilter.both : TileCelestialMagnet.EntityFilter.item) : (
/*     */ 
/*     */                 
/* 129 */                 (GuiCelestialMagnet.this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.both) ? TileCelestialMagnet.EntityFilter.mob : TileCelestialMagnet.EntityFilter.none));
/*     */ 
/*     */             
/* 132 */             Common.INSTANCE.sendToServer((IMessage)new MagnetMessage(GuiCelestialMagnet.this.magnet.func_174877_v(), null, GuiCelestialMagnet.this.magnet.getEntityFilter(), 
/* 133 */                   GuiCelestialMagnet.this.magnet.aspectFilter, GuiCelestialMagnet.this.magnet.area));
/* 134 */             return true;
/*     */           } 
/* 136 */           return false;
/*     */         }
/*     */       };
/*     */     
/* 140 */     this.aspect = new GuiButton(0, k / 2 + 76, l / 2 - 56, 16, 16, null)
/*     */       {
/*     */         public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
/* 143 */           if (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g) {
/*     */             
/* 145 */             this.field_146124_l = !this.field_146124_l;
/* 146 */             GuiCelestialMagnet.this.magnet.aspectFilter = this.field_146124_l;
/* 147 */             Common.INSTANCE.sendToServer((IMessage)new MagnetMessage(GuiCelestialMagnet.this.magnet.func_174877_v(), null, this.field_146124_l, GuiCelestialMagnet.this.magnet.area));
/* 148 */             return true;
/*     */           } 
/* 150 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/* 155 */           Color color = new Color(Aspect.EARTH.getColor());
/* 156 */           GL11.glPushMatrix();
/* 157 */           GL11.glAlphaFunc(516, 0.003921569F);
/* 158 */           GL11.glEnable(3042);
/* 159 */           GL11.glBlendFunc(770, 771);
/* 160 */           float alpha = this.field_146124_l ? 0.9F : 0.3F;
/* 161 */           Minecraft.func_71410_x().func_110434_K().func_110577_a(Aspect.EARTH.getImage());
/* 162 */           Tessellator tessellator = Tessellator.func_178181_a();
/* 163 */           BufferBuilder buffer = tessellator.func_178180_c();
/* 164 */           buffer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
/* 165 */           buffer.func_178994_b(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, (int)alpha);
/*     */           
/* 167 */           buffer.func_181662_b(this.field_146128_h, this.field_146129_i, 0.0D).func_187315_a(0.0D, 0.0D)
/* 168 */             .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha)
/* 169 */             .func_181675_d();
/* 170 */           buffer.func_181662_b(this.field_146128_h, (this.field_146129_i + 16), 0.0D).func_187315_a(0.0D, 1.0D)
/* 171 */             .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha)
/* 172 */             .func_181675_d();
/* 173 */           buffer.func_181662_b((this.field_146128_h + 16), (this.field_146129_i + 16), 0.0D).func_187315_a(1.0D, 1.0D)
/* 174 */             .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha)
/* 175 */             .func_181675_d();
/* 176 */           buffer.func_181662_b((this.field_146128_h + 16), this.field_146129_i, 0.0D).func_187315_a(1.0D, 0.0D)
/* 177 */             .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha)
/* 178 */             .func_181675_d();
/* 179 */           tessellator.func_78381_a();
/* 180 */           func_146119_b(mc, mouseX, mouseY);
/* 181 */           GL11.glPopMatrix();
/*     */         }
/*     */       };
/* 184 */     this.areaLeft = new GuiImageButton(this, 0, k / 2 + 84, l / 2 + 80, 7, 10, null, null, this.tex, 227, 0, 7, 10)
/*     */       {
/*     */         public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
/* 187 */           if (mouseX >= this.field_146128_h - this.field_146120_f / 2 && mouseY >= this.field_146129_i - this.field_146121_g / 2 && mouseX < this.field_146128_h - this.field_146120_f / 2 + this.field_146120_f && mouseY < this.field_146129_i - this.field_146121_g / 2 + this.field_146121_g && 
/*     */             
/* 189 */             GuiCelestialMagnet.this.magnet.area > 0) {
/* 190 */             GuiCelestialMagnet.this.magnet.area--;
/* 191 */             Common.INSTANCE.sendToServer((IMessage)new MagnetMessage(GuiCelestialMagnet.this.magnet.func_174877_v(), null, this.field_146124_l, GuiCelestialMagnet.this.magnet.area));
/* 192 */             return true;
/*     */           } 
/* 194 */           return true;
/*     */         }
/*     */       };
/* 197 */     this.areaRight = new GuiImageButton(this, 0, k / 2 + 99, l / 2 + 80, 7, 10, null, null, this.tex, 232, 0, 7, 10)
/*     */       {
/*     */         public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
/* 200 */           if (mouseX >= this.field_146128_h - this.field_146120_f / 2 && mouseY >= this.field_146129_i - this.field_146121_g / 2 && mouseX < this.field_146128_h - this.field_146120_f / 2 + this.field_146120_f && mouseY < this.field_146129_i - this.field_146121_g / 2 + this.field_146121_g && 
/*     */             
/* 202 */             GuiCelestialMagnet.this.magnet.area < 9) {
/* 203 */             GuiCelestialMagnet.this.magnet.area++;
/* 204 */             Common.INSTANCE.sendToServer((IMessage)new MagnetMessage(GuiCelestialMagnet.this.magnet.func_174877_v(), null, this.field_146124_l, GuiCelestialMagnet.this.magnet.area));
/* 205 */             return true;
/*     */           } 
/* 207 */           return true;
/*     */         }
/*     */       };
/* 210 */     this.mob
/* 211 */       .active = (this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.both || this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.mob);
/* 212 */     this.item
/* 213 */       .field_146124_l = (this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.both || this.magnet.getEntityFilter() == TileCelestialMagnet.EntityFilter.item);
/* 214 */     this.aspect.field_146124_l = this.magnet.aspectFilter;
/* 215 */     this.field_146292_n.add(this.mob);
/* 216 */     this.field_146292_n.add(this.item);
/* 217 */     this.field_146292_n.add(this.aspect);
/* 218 */     this.field_146292_n.add(this.areaLeft);
/* 219 */     this.field_146292_n.add(this.areaRight);
/* 220 */     super.func_73866_w_();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
/* 225 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 226 */     this.field_146297_k.func_110434_K().func_110577_a(this.tex);
/* 227 */     int k = this.field_146294_l;
/* 228 */     int l = this.field_146295_m;
/* 229 */     GL11.glEnable(3042);
/* 230 */     GL11.glBlendFunc(770, 771);
/* 231 */     func_73729_b(k / 2 - 76, l / 2 - 88, 0, 0, 208, 200);
/*     */ 
/*     */ 
/*     */     
/* 235 */     func_73731_b(this.field_146289_q, Integer.toString(this.magnet.area), k / 2 + 89, l / 2 + 76, Color.WHITE.getRGB());
/* 236 */     super.func_73863_a(mouseX, mouseY, partialTicks);
/*     */   }
/*     */   
/*     */   public class GuiCelestialAspectButton
/*     */     extends GuiButton {
/*     */     private final Aspect aspect;
/*     */     private boolean active = false;
/*     */     
/*     */     public GuiCelestialAspectButton(int buttonId, int x, int y, Aspect aspectIn, String buttonText) {
/* 245 */       super(buttonId, x, y, 16, 16, buttonText);
/* 246 */       this.aspect = aspectIn;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
/* 251 */       if (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g) {
/* 252 */         this.active = !this.active;
/* 253 */         if (!GuiCelestialMagnet.this.magnet.addAspectFilter(this.aspect))
/* 254 */           GuiCelestialMagnet.this.magnet.removeAspectFilter(this.aspect); 
/* 255 */         Common.INSTANCE.sendToServer((IMessage)new MagnetMessage(GuiCelestialMagnet.this
/* 256 */               .magnet.func_174877_v(), this.aspect, GuiCelestialMagnet.this.magnet.aspectFilter, GuiCelestialMagnet.this.magnet.area));
/*     */       } 
/* 258 */       return super.func_146116_c(mc, mouseX, mouseY);
/*     */     }
/*     */ 
/*     */     
/*     */     public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/* 263 */       Color color = new Color(this.aspect.getColor());
/* 264 */       float alpha = this.active ? 0.9F : 0.3F;
/* 265 */       GL11.glPushMatrix();
/* 266 */       GL11.glAlphaFunc(516, 0.003921569F);
/* 267 */       GL11.glEnable(3042);
/* 268 */       GL11.glBlendFunc(770, 771);
/* 269 */       Minecraft.func_71410_x().func_110434_K().func_110577_a(this.aspect.getImage());
/* 270 */       Tessellator tessellator = Tessellator.func_178181_a();
/* 271 */       BufferBuilder buffer = tessellator.func_178180_c();
/* 272 */       buffer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
/* 273 */       buffer.func_178994_b(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, (int)alpha);
/*     */       
/* 275 */       buffer.func_181662_b(this.field_146128_h, this.field_146129_i, 0.0D).func_187315_a(0.0D, 0.0D)
/* 276 */         .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha).func_181675_d();
/* 277 */       buffer.func_181662_b(this.field_146128_h, (this.field_146129_i + 16), 0.0D).func_187315_a(0.0D, 1.0D)
/* 278 */         .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha).func_181675_d();
/* 279 */       buffer.func_181662_b((this.field_146128_h + 16), (this.field_146129_i + 16), 0.0D).func_187315_a(1.0D, 1.0D)
/* 280 */         .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha).func_181675_d();
/* 281 */       buffer.func_181662_b((this.field_146128_h + 16), this.field_146129_i, 0.0D).func_187315_a(1.0D, 0.0D)
/* 282 */         .func_181666_a(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, alpha).func_181675_d();
/* 283 */       tessellator.func_78381_a();
/* 284 */       GL11.glScalef(0.5F, 0.5F, 0.5F);
/* 285 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 286 */       GL11.glDisable(3042);
/* 287 */       GL11.glAlphaFunc(516, 0.1F);
/* 288 */       GL11.glPopMatrix();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\gui\GuiCelestialMagnet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */