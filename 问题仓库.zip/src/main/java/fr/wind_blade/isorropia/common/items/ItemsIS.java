 package fr.wind_blade.isorropia.common.items;
 
 import fr.wind_blade.isorropia.common.Common;
 import fr.wind_blade.isorropia.common.items.baubles.ItemSomaticBrain;
 import fr.wind_blade.isorropia.common.items.misc.ItemCat;
 import fr.wind_blade.isorropia.common.items.misc.ItemIncubatedEgg;
 import fr.wind_blade.isorropia.common.items.misc.ItemJelly;
 import fr.wind_blade.isorropia.common.items.misc.ItemLens;
 import fr.wind_blade.isorropia.common.items.tools.ItemPrimalWell;
 import fr.wind_blade.isorropia.common.items.tools.ItemSkullAxe;
 import java.util.ArrayList;
 import java.util.List;
 import net.minecraft.item.Item;
 import net.minecraft.util.ResourceLocation;
 
 
 
 public class ItemsIS
 {
/* 20 */   public static final List<Item> items = new ArrayList<>();
   
   public static Item itemBaseLens;
   public static ItemLens itemAirLens;
   public static ItemLens itemFireLens;
   public static ItemLens itemOrdoLens;
   public static ItemLens itemEnvyLens;
   public static ItemSomaticBrain itemSomaticBrain;
   public static Item itemRingMirror;
   public static Item itemBrokenMirrorPane;
   public static Item facticePrimordialPerle;
   public static Item itemIncubatedEgg;
   public static Item itemPrimalWell;
   public static Item itemSkullAxe;
   public static Item itemIRElytra;
   public static Item itemInkEgg;
   public static Item itemFlesh;
   public static Item itemCat;
   public static ItemJelly itemJelly;
   
   public static void initItems() {
/* 41 */     itemBaseLens = getItem(new Item(), "lens");
/* 42 */     itemAirLens = getItem(new ItemLens(), "lens_air");
/* 43 */     itemOrdoLens = getItem(new ItemLens(), "lens_ordo");
/* 44 */     itemFireLens = getItem(new ItemLens(), "lens_fire");
/* 45 */     itemEnvyLens = getItem(new ItemLens(), "lens_envy");
/* 46 */     itemSomaticBrain = getItem(new ItemSomaticBrain(), "somatic_brain");
/* 47 */     itemIncubatedEgg = getItem(new ItemIncubatedEgg(), "incubated_egg");
/* 48 */     itemPrimalWell = getItem(new ItemPrimalWell(), "primal_well");
/* 49 */     itemSkullAxe = getItem(new ItemSkullAxe(), "skulltaker");
/* 50 */     itemInkEgg = getItem("ink_egg");
/* 51 */     itemFlesh = getItem("flesh");
/* 52 */     itemCat = getItem(new ItemCat(), "cat");
/* 53 */     itemJelly = getItem(new ItemJelly(), "jelly");
   }
   
   public static Item getItem(String name) {
/* 57 */     return getItem(new Item(), name);
   }
   
   public static <T extends Item> T getItem(T item, String name) {
/* 61 */     ((Item)item.setRegistryName(new ResourceLocation("isorropia", name)))
/* 62 */       .func_77655_b("isorropia." + name);
/* 63 */     item.func_77637_a(Common.isorropiaCreativeTabs);
/* 64 */     items.add((Item)item);
/* 65 */     return item;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\ItemsIS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */