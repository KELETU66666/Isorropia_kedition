 package fr.wind_blade.isorropia.common.entities;
 
 import net.minecraft.entity.Entity;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.util.DamageSource;
 import net.minecraft.world.World;
 
 
 
 
 public class EntitySaehrimnirReborn
   extends Entity
 {
   public EntitySaehrimnirReborn(World worldIn) {
/* 15 */     super(worldIn);
   }
 
   
   public boolean func_70097_a(DamageSource source, float amount) {
/* 20 */     return super.func_70097_a(source, amount);
   }
 
   
   public void func_70030_z() {
/* 25 */     super.func_70030_z();
/* 26 */     if (this.field_70173_aa >= 24000 && !this.field_70128_L && !this.field_70170_p.field_72995_K) {
/* 27 */       EntitySaehrimnir entity = new EntitySaehrimnir(this.field_70170_p);
/* 28 */       entity.func_70634_a(this.field_70165_t, this.field_70163_u, this.field_70161_v);
/* 29 */       this.field_70170_p.func_72838_d((Entity)entity);
/* 30 */       func_70106_y();
     } 
   }
 
   
   public void func_70037_a(NBTTagCompound compound) {
/* 36 */     this.field_70173_aa = compound.func_74765_d("ticksExisted");
   }
 
   
   public void func_70014_b(NBTTagCompound compound) {
/* 41 */     compound.func_74777_a("ticksExisted", (short)this.field_70173_aa);
   }
   
   protected void func_70088_a() {}
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntitySaehrimnirReborn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */