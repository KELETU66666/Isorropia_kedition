 package fr.wind_blade.isorropia.common.network;
 
 import io.netty.buffer.ByteBuf;
 import net.minecraft.client.Minecraft;
 import net.minecraft.util.math.BlockPos;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
 import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
 
 
 public class ParticuleDestroyMessage
   implements IMessage
 {
   private BlockPos pos;
   
   public ParticuleDestroyMessage() {}
   
   public ParticuleDestroyMessage(BlockPos pos) {
/* 19 */     this.pos = pos;
   }
 
   
   public void fromBytes(ByteBuf buf) {
/* 24 */     this.pos = BlockPos.func_177969_a(buf.readLong());
   }
 
   
   public void toBytes(ByteBuf buf) {
/* 29 */     buf.writeLong(this.pos.func_177986_g());
   }
   
   public static class Handler
     implements IMessageHandler<ParticuleDestroyMessage, IMessage>
   {
     public IMessage onMessage(ParticuleDestroyMessage message, MessageContext ctx) {
/* 36 */       Minecraft.func_71410_x().func_152344_a(() -> (Minecraft.func_71410_x()).field_71452_i.func_180533_a(message.pos, (Minecraft.func_71410_x()).field_71441_e.func_180495_p(message.pos)));
 
 
       
/* 40 */       return null;
     }
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\network\ParticuleDestroyMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */