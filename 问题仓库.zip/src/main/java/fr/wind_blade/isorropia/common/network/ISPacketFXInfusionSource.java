 package fr.wind_blade.isorropia.common.network;
 
 import fr.wind_blade.isorropia.common.tiles.TileVat;
 import io.netty.buffer.ByteBuf;
 import net.minecraft.client.Minecraft;
 import net.minecraft.tileentity.TileEntity;
 import net.minecraft.util.math.BlockPos;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
 import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
 import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
 import thaumcraft.Thaumcraft;
 
 
 public class ISPacketFXInfusionSource
   implements IMessage, IMessageHandler<ISPacketFXInfusionSource, IMessage>
 {
   private long p1;
   private long p2;
   private int color;
   private int index;
   
   public ISPacketFXInfusionSource() {}
   
   public ISPacketFXInfusionSource(BlockPos pos, BlockPos pos2, int color) {
/* 25 */     this(pos, pos2, color, 0);
   }
   
   public ISPacketFXInfusionSource(BlockPos pos, BlockPos pos2, int color, int index) {
/* 29 */     this.p1 = pos.func_177986_g();
/* 30 */     this.p2 = pos2.func_177986_g();
/* 31 */     this.color = color;
/* 32 */     this.index = index;
   }
 
   
   public void toBytes(ByteBuf buffer) {
/* 37 */     buffer.writeLong(this.p1);
/* 38 */     buffer.writeLong(this.p2);
/* 39 */     buffer.writeInt(this.color);
/* 40 */     buffer.writeInt(this.index);
   }
 
   
   public void fromBytes(ByteBuf buffer) {
/* 45 */     this.p1 = buffer.readLong();
/* 46 */     this.p2 = buffer.readLong();
/* 47 */     this.color = buffer.readInt();
/* 48 */     this.index = buffer.readInt();
   }
 
   
   public IMessage onMessage(ISPacketFXInfusionSource message, MessageContext ctx) {
/* 53 */     BlockPos p1 = BlockPos.func_177969_a(message.p1);
/* 54 */     BlockPos p2 = BlockPos.func_177969_a(message.p2);
/* 55 */     String key = "" + p2.func_177958_n() + ":" + p2.func_177956_o() + ":" + p2.func_177952_p() + ":" + message.color;
/* 56 */     TileEntity tile = Thaumcraft.proxy.getClientWorld().func_175625_s(p1);
/* 57 */     if (tile instanceof TileVat) {
/* 58 */       int count = 15;
/* 59 */       TileEntity te = (Minecraft.func_71410_x()).field_71441_e.func_175625_s(p2);
/* 60 */       if (te instanceof thaumcraft.common.tiles.crafting.TilePedestal) {
/* 61 */         count = 60;
       }
/* 63 */       TileVat is = (TileVat)tile;
/* 64 */       if (is.getSourceFX().containsKey(key)) {
/* 65 */         TileVat.SourceFX sf = (TileVat.SourceFX)is.getSourceFX().get(key);
/* 66 */         sf.ticks = count;
/* 67 */         is.getSourceFX().put(key, sf);
       } else {
/* 69 */         TileVat matrix = is;
/* 70 */         matrix.getClass();
/* 71 */         matrix.getClass(); is.getSourceFX().put(key, new TileVat.SourceFX(matrix, p2, count, message.color));
       } 
     } 
/* 74 */     return null;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\network\ISPacketFXInfusionSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */