 package fr.wind_blade.isorropia.common.libs.research;
 
 import fr.wind_blade.isorropia.common.items.tools.ItemSkullAxe;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.util.text.ITextComponent;
 import net.minecraft.util.text.TextComponentString;
 import net.minecraft.util.text.TextComponentTranslation;
 import net.minecraft.util.text.TextFormatting;
 import thaumcraft.api.capabilities.ThaumcraftCapabilities;
 import thaumcraft.api.research.IScanThing;
 
 public class ScanSkull
   implements IScanThing {
   public boolean checkThing(EntityPlayer var1, Object obj) {
/* 16 */     if (!(obj instanceof EntityLivingBase) || 
/* 17 */       !ThaumcraftCapabilities.getKnowledge(var1).isResearchKnown("SKULLTAKER@0")) {
/* 18 */       return false;
     }
/* 20 */     EntityLivingBase base = (EntityLivingBase)obj;
     
/* 22 */     if (ItemSkullAxe.getHeadId(base.getClass()) != -1)
/* 23 */       return true; 
/* 24 */     return false;
   }
 
   
   public void onSuccess(EntityPlayer player, Object object) {
/* 29 */     player.func_145747_a((ITextComponent)new TextComponentString(TextFormatting.DARK_PURPLE + (new TextComponentTranslation("research.scan.skull.text", new Object[0]))
/* 30 */           .func_150254_d()));
   }
 
   
   public String getResearchKey(EntityPlayer var1, Object var2) {
/* 35 */     return "!scan.skull";
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\research\ScanSkull.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */