 package fr.wind_blade.isorropia.client.model;
 
 import fr.wind_blade.isorropia.client.renderer.RenderCustomItem;
 import java.util.List;
 import javax.vecmath.Matrix4f;
 import net.minecraft.block.state.IBlockState;
 import net.minecraft.client.renderer.block.model.BakedQuad;
 import net.minecraft.client.renderer.block.model.IBakedModel;
 import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
 import net.minecraft.client.renderer.block.model.ItemOverrideList;
 import net.minecraft.client.renderer.texture.TextureAtlasSprite;
 import net.minecraft.item.Item;
 import net.minecraft.util.EnumFacing;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 import org.apache.commons.lang3.tuple.Pair;
 
 
 
 @SideOnly(Side.CLIENT)
 public class DynamicStaticModel
   implements IBakedModel
 {
   private final IBakedModel oldModel;
   private final Item item;
   
   public DynamicStaticModel(IBakedModel internal, Item item) {
/* 28 */     this.oldModel = internal;
/* 29 */     this.item = item;
   }
 
   
   public List<BakedQuad> func_188616_a(IBlockState state, EnumFacing side, long rand) {
/* 34 */     return this.oldModel.func_188616_a(state, side, rand);
   }
 
   
   public boolean func_177555_b() {
/* 39 */     return this.oldModel.func_177555_b();
   }
 
   
   public boolean func_177556_c() {
/* 44 */     return this.oldModel.func_177556_c();
   }
   
   public IBakedModel getInternal() {
/* 48 */     return this.oldModel;
   }
 
   
   public boolean func_188618_c() {
/* 53 */     return true;
   }
 
   
   public TextureAtlasSprite func_177554_e() {
/* 58 */     return this.oldModel.func_177554_e();
   }
 
   
   public ItemOverrideList func_188617_f() {
/* 63 */     return ItemOverrideList.field_188022_a;
   }
 
   
   public Pair<? extends IBakedModel, Matrix4f> handlePerspective(ItemCameraTransforms.TransformType type) {
/* 68 */     ((RenderCustomItem)this.item.getTileEntityItemStackRenderer()).transform = type;
/* 69 */     return Pair.of(this, this.oldModel.handlePerspective(type).getRight());
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\model\DynamicStaticModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */