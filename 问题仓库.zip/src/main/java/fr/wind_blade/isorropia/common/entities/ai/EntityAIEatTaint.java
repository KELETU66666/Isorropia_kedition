/*     */ package fr.wind_blade.isorropia.common.entities.ai;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.config.Config;
/*     */ import fr.wind_blade.isorropia.common.network.ParticuleDestroyMessage;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.BlockLog;
/*     */ import net.minecraft.block.BlockOldLog;
/*     */ import net.minecraft.block.BlockPlanks;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Biomes;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.biome.Biome;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import thaumcraft.api.ThaumcraftMaterials;
/*     */ import thaumcraft.api.blocks.BlocksTC;
/*     */ import thaumcraft.common.blocks.world.taint.BlockTaintLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIEatTaint
/*     */   extends EntityAIBase
/*     */ {
/*  33 */   public static final Map<Biome, BlockPlanks.EnumType> WOOD_IN_BIOMES = new HashMap<>(); private EntityLiving living;
/*     */   
/*     */   static {
/*  36 */     WOOD_IN_BIOMES.put(Biomes.field_76770_e, BlockPlanks.EnumType.SPRUCE);
/*  37 */     WOOD_IN_BIOMES.put(Biomes.field_76768_g, BlockPlanks.EnumType.SPRUCE);
/*  38 */     WOOD_IN_BIOMES.put(Biomes.field_76784_u, BlockPlanks.EnumType.SPRUCE);
/*  39 */     WOOD_IN_BIOMES.put(Biomes.field_76783_v, BlockPlanks.EnumType.SPRUCE);
/*  40 */     WOOD_IN_BIOMES.put(Biomes.field_150584_S, BlockPlanks.EnumType.SPRUCE);
/*  41 */     WOOD_IN_BIOMES.put(Biomes.field_150579_T, BlockPlanks.EnumType.SPRUCE);
/*  42 */     WOOD_IN_BIOMES.put(Biomes.field_150578_U, BlockPlanks.EnumType.SPRUCE);
/*  43 */     WOOD_IN_BIOMES.put(Biomes.field_150581_V, BlockPlanks.EnumType.SPRUCE);
/*  44 */     WOOD_IN_BIOMES.put(Biomes.field_76781_i, BlockPlanks.EnumType.SPRUCE);
/*  45 */     WOOD_IN_BIOMES.put(Biomes.field_185443_S, BlockPlanks.EnumType.SPRUCE);
/*  46 */     WOOD_IN_BIOMES.put(Biomes.field_150590_f, BlockPlanks.EnumType.SPRUCE);
/*  47 */     WOOD_IN_BIOMES.put(Biomes.field_185431_ac, BlockPlanks.EnumType.SPRUCE);
/*  48 */     WOOD_IN_BIOMES.put(Biomes.field_185432_ad, BlockPlanks.EnumType.SPRUCE);
/*  49 */     WOOD_IN_BIOMES.put(Biomes.field_185433_ae, BlockPlanks.EnumType.SPRUCE);
/*  50 */     WOOD_IN_BIOMES.put(Biomes.field_185434_af, BlockPlanks.EnumType.SPRUCE);
/*  51 */     WOOD_IN_BIOMES.put(Biomes.field_150583_P, BlockPlanks.EnumType.BIRCH);
/*  52 */     WOOD_IN_BIOMES.put(Biomes.field_150582_Q, BlockPlanks.EnumType.BIRCH);
/*  53 */     WOOD_IN_BIOMES.put(Biomes.field_185448_Z, BlockPlanks.EnumType.BIRCH);
/*  54 */     WOOD_IN_BIOMES.put(Biomes.field_185429_aa, BlockPlanks.EnumType.BIRCH);
/*  55 */     WOOD_IN_BIOMES.put(Biomes.field_76782_w, BlockPlanks.EnumType.JUNGLE);
/*  56 */     WOOD_IN_BIOMES.put(Biomes.field_76792_x, BlockPlanks.EnumType.JUNGLE);
/*  57 */     WOOD_IN_BIOMES.put(Biomes.field_150574_L, BlockPlanks.EnumType.JUNGLE);
/*  58 */     WOOD_IN_BIOMES.put(Biomes.field_185446_X, BlockPlanks.EnumType.JUNGLE);
/*  59 */     WOOD_IN_BIOMES.put(Biomes.field_185447_Y, BlockPlanks.EnumType.JUNGLE);
/*  60 */     WOOD_IN_BIOMES.put(Biomes.field_150588_X, BlockPlanks.EnumType.ACACIA);
/*  61 */     WOOD_IN_BIOMES.put(Biomes.field_150587_Y, BlockPlanks.EnumType.ACACIA);
/*  62 */     WOOD_IN_BIOMES.put(Biomes.field_185435_ag, BlockPlanks.EnumType.ACACIA);
/*  63 */     WOOD_IN_BIOMES.put(Biomes.field_185436_ah, BlockPlanks.EnumType.ACACIA);
/*  64 */     WOOD_IN_BIOMES.put(Biomes.field_150585_R, BlockPlanks.EnumType.DARK_OAK);
/*  65 */     WOOD_IN_BIOMES.put(Biomes.field_185430_ab, BlockPlanks.EnumType.DARK_OAK);
/*     */   }
/*     */ 
/*     */   
/*     */   private BlockPos targetPos;
/*     */   int cooldown;
/*     */   
/*     */   public EntityAIEatTaint(EntityLiving living) {
/*  73 */     this.living = living;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  78 */     if (this.cooldown > 0) {
/*  79 */       this.cooldown--;
/*  80 */       return false;
/*     */     } 
/*  82 */     return findTaint();
/*     */   }
/*     */   
/*     */   private boolean findTaint() {
/*  86 */     this.targetPos = null;
/*  87 */     for (BlockPos pos : BlockPos.func_177975_b(this.living.func_180425_c().func_177982_a(-5, -2, -5), this.living
/*  88 */         .func_180425_c().func_177982_a(5, 5, 5))) {
/*  89 */       if (this.living.field_70170_p.func_180495_p(pos).func_185904_a() != ThaumcraftMaterials.MATERIAL_TAINT || 
/*  90 */         this.living.func_70661_as().func_75488_a(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p()) == null)
/*     */         continue; 
/*  92 */       this.targetPos = pos;
/*  93 */       return true;
/*     */     } 
/*     */ 
/*     */     
/*  97 */     for (int tries = 0; tries < 30; ) {
/*  98 */       int x2 = (int)this.living.field_70165_t + this.living.field_70170_p.field_73012_v.nextInt(17) - 8;
/*  99 */       int z = (int)this.living.field_70161_v + this.living.field_70170_p.field_73012_v.nextInt(17) - 8;
/* 100 */       int y2 = (int)this.living.field_70163_u + this.living.field_70170_p.field_73012_v.nextInt(5) - 2;
/* 101 */       if (!this.living.field_70170_p.func_175623_d(new BlockPos(x2, y2 + 1, z)) || this.living.field_70170_p
/* 102 */         .func_180495_p(new BlockPos(x2, y2, z)).func_185904_a() != ThaumcraftMaterials.MATERIAL_TAINT || 
/* 103 */         this.living.func_70661_as().func_75488_a(x2, y2, z) == null) {
/*     */         tries++; continue;
/* 105 */       }  this.targetPos = new BlockPos(x2, y2, z);
/* 106 */       return true;
/*     */     } 
/*     */     
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/* 114 */     return (!this.living.func_70661_as().func_75500_f() && this.targetPos != null && this.living
/* 115 */       .func_70661_as().func_179680_a(this.targetPos) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 120 */     this.targetPos = null;
/* 121 */     this.living.func_70661_as().func_75499_g();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 126 */     this.living.func_70671_ap().func_75650_a(this.targetPos.func_177958_n() + 0.5D, this.targetPos.func_177956_o() + 0.5D, this.targetPos
/* 127 */         .func_177952_p() + 0.5D, 30.0F, 30.0F);
/* 128 */     double dist = this.living.func_70092_e(this.targetPos.func_177958_n() + 0.5D, this.targetPos.func_177956_o() + 0.5D, this.targetPos
/* 129 */         .func_177952_p() + 0.5D);
/* 130 */     if (dist <= 4.0D) {
/* 131 */       eatTaint();
/*     */     } else {
/* 133 */       this.living.func_70661_as().func_75492_a(this.targetPos.func_177958_n() + 0.5D, this.targetPos.func_177956_o() + 0.5D, this.targetPos
/* 134 */           .func_177952_p() + 0.5D, 1.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void eatTaint() {
/* 139 */     IBlockState state = this.living.field_70170_p.func_180495_p(this.targetPos);
/*     */     
/* 141 */     if (state.func_185904_a() == ThaumcraftMaterials.MATERIAL_TAINT || state.func_177230_c() instanceof thaumcraft.common.blocks.world.taint.ITaintBlock) {
/*     */       
/* 143 */       if (state.func_177230_c() == BlocksTC.taintLog) {
/* 144 */         Biome biome = this.living.field_70170_p.func_180494_b(this.targetPos);
/* 145 */         BlockPlanks.EnumType type = WOOD_IN_BIOMES.containsKey(biome) ? WOOD_IN_BIOMES.get(biome) : BlockPlanks.EnumType.OAK;
/* 146 */         this.living.field_70170_p.func_175656_a(this.targetPos, Blocks.field_150364_r
/* 147 */             .func_176223_P().func_177226_a((IProperty)BlockOldLog.field_176301_b, (Comparable)type).func_177226_a((IProperty)BlockLog.field_176299_a, 
/*     */               
/* 149 */               (Comparable)BlockLog.EnumAxis.func_176870_a((EnumFacing.Axis)state.func_177229_b((IProperty)BlockTaintLog.AXIS))));
/*     */       }
/* 151 */       else if (state.func_177230_c() == BlocksTC.taintRock) {
/* 152 */         this.living.field_70170_p.func_175656_a(this.targetPos, Blocks.field_150348_b.func_176223_P());
/* 153 */       } else if (state.func_177230_c() == BlocksTC.taintSoil) {
/* 154 */         this.living.field_70170_p.func_175656_a(this.targetPos, Blocks.field_150346_d.func_176223_P());
/*     */       } else {
/* 156 */         this.living.field_70170_p.func_175698_g(this.targetPos);
/*     */       } 
/*     */ 
/*     */       
/* 160 */       Common.INSTANCE.sendToAllAround((IMessage)new ParticuleDestroyMessage(this.targetPos), new NetworkRegistry.TargetPoint(this.living.field_70170_p.field_73011_w
/* 161 */             .getDimension(), this.targetPos.func_177958_n(), this.targetPos.func_177956_o(), this.targetPos.func_177952_p(), 10.0D));
/* 162 */       this.living.func_184185_a(SoundEvents.field_187739_dZ, 0.2F, ((this.living.field_70170_p.field_73012_v
/* 163 */           .nextFloat() - this.living.field_70170_p.field_73012_v.nextFloat()) * 0.7F + 1.0F) * 2.0F);
/* 164 */       this.living.func_70691_i(1.0F);
/* 165 */       this.cooldown = Config.taint_pig_cooldown;
/*     */     } else {
/* 167 */       func_75251_c();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void func_75249_e() {
/* 172 */     if (this.targetPos != null)
/* 173 */       this.living.func_70661_as().func_75492_a(this.targetPos.func_177958_n() + 0.5D, this.targetPos.func_177956_o() + 0.5D, this.targetPos
/* 174 */           .func_177952_p() + 0.5D, 1.0D); 
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\ai\EntityAIEatTaint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */