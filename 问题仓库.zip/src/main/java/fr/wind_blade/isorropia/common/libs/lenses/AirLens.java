/*     */ package fr.wind_blade.isorropia.common.libs.lenses;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.items.misc.ItemLens;
/*     */ import fr.wind_blade.isorropia.common.libs.helpers.IRMathHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import thaumcraft.client.lib.UtilsFX;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AirLens
/*     */   extends Lens
/*     */ {
/*     */   public static final byte AIR_LENS_DIST_CAP = 24;
/*  29 */   public static final ResourceLocation TEX = new ResourceLocation("isorropia", "textures/fx/ripple.png");
/*  30 */   public static final ResourceLocation TEX_UNDEAD = new ResourceLocation("isorropia", "textures/fx/vortex.png");
/*  31 */   public static final ResourceLocation TEX_ELDRITCH = new ResourceLocation("thaumcraft", "textures/misc/vortex.png");
/*     */ 
/*     */   
/*     */   public AirLens(ItemLens lensIn) {
/*  35 */     super(lensIn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleTicks(World worldIn, EntityPlayer playerIn, boolean doubleLens) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRenderGameOverlay(World worldIn, EntityPlayer playerIn, ScaledResolution resolution, boolean doubleLens, float partialTicks) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRenderWorldLast(World worldIn, EntityPlayer playerIn, boolean doubleLens, float partialTicks) {
/*  51 */     if ((Minecraft.func_71410_x()).field_71474_y.field_74320_O > 0) {
/*     */       return;
/*     */     }
/*  54 */     List<EntityLivingBase> base = playerIn.field_70170_p.func_175647_a(EntityLivingBase.class, new AxisAlignedBB(playerIn.field_70165_t - 24.0D, playerIn.field_70163_u - 24.0D, playerIn.field_70161_v - 24.0D, playerIn.field_70165_t + 24.0D, playerIn.field_70163_u + 24.0D, playerIn.field_70161_v + 24.0D), e -> (e != playerIn));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     for (EntityLivingBase e : base) {
/*     */       
/*  62 */       double playerOffX = playerIn.field_70169_q + (playerIn.field_70165_t - playerIn.field_70169_q) * partialTicks;
/*  63 */       double playerOffY = playerIn.field_70167_r + (playerIn.field_70163_u - playerIn.field_70167_r) * partialTicks;
/*  64 */       double playerOffZ = playerIn.field_70166_s + (playerIn.field_70161_v - playerIn.field_70166_s) * partialTicks;
/*     */       
/*  66 */       double eOffX = e.field_70169_q + (e.field_70165_t - e.field_70169_q) * partialTicks;
/*  67 */       double eOffY = e.field_70167_r + (e.field_70163_u - e.field_70167_r) * partialTicks;
/*  68 */       double eOffZ = e.field_70166_s + (e.field_70161_v - e.field_70166_s) * partialTicks;
/*     */       
/*  70 */       double scale = e.func_174791_d().func_178788_d(playerIn.func_174791_d()).func_72433_c();
/*  71 */       float sizeOffset = (e.field_70173_aa % 16);
/*     */       
/*  73 */       double cappedTchebychevDist = Math.min(IRMathHelper.getTchebychevDistance((Entity)e, (Entity)playerIn), 24.0D);
/*  74 */       float alpha = (float)(1.0D - cappedTchebychevDist / 24.0D);
/*  75 */       float size = Math.min(e.field_70131_O, e.field_70130_N);
/*     */       
/*  77 */       if (e instanceof thaumcraft.api.entities.IEldritchMob) {
/*  78 */         GlStateManager.func_179094_E();
/*  79 */         GL11.glDisable(2929);
/*  80 */         size = (float)(size * 0.8D);
/*     */         
/*  82 */         GlStateManager.func_179137_b(-playerOffX, -playerOffY, -playerOffZ);
/*  83 */         GlStateManager.func_179137_b(eOffX, eOffY + (e.field_70131_O / 2.0F), eOffZ);
/*  84 */         GlStateManager.func_179114_b(-playerIn.field_70177_z, 0.0F, 1.0F, 0.0F);
/*  85 */         GlStateManager.func_179114_b(playerIn.field_70125_A, 1.0F, 0.0F, 0.0F);
/*  86 */         GlStateManager.func_179114_b((e.field_70173_aa % 360), 0.0F, 0.0F, 1.0F);
/*  87 */         UtilsFX.renderQuadCentered(TEX_ELDRITCH, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*  88 */         GlStateManager.func_179114_b((-(e.field_70173_aa % 360) * 2), 0.0F, 0.0F, 1.0F);
/*  89 */         size *= 2.0F;
/*     */         
/*  91 */         UtilsFX.renderQuadCentered(TEX_ELDRITCH, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*     */         
/*  93 */         GL11.glEnable(2929);
/*  94 */         GlStateManager.func_179121_F(); continue;
/*     */       } 
/*  96 */       if (e.func_70662_br()) {
/*  97 */         size = (float)(size * 1.3D);
/*  98 */         GlStateManager.func_179094_E();
/*  99 */         GL11.glDisable(2929);
/*     */         
/* 101 */         GlStateManager.func_179137_b(-playerOffX, -playerOffY, -playerOffZ);
/* 102 */         GlStateManager.func_179137_b(eOffX, eOffY + (e.field_70131_O / 2.0F), eOffZ);
/* 103 */         GlStateManager.func_179114_b(-playerIn.field_70177_z, 0.0F, 1.0F, 0.0F);
/* 104 */         GlStateManager.func_179114_b(playerIn.field_70125_A, 1.0F, 0.0F, 0.0F);
/* 105 */         GlStateManager.func_179114_b(-(e.field_70173_aa % 360), 0.0F, 0.0F, 1.0F);
/* 106 */         UtilsFX.renderQuadCentered(TEX_UNDEAD, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/* 107 */         size *= 2.0F;
/* 108 */         GlStateManager.func_179114_b((e.field_70173_aa % 360 * 2), 0.0F, 0.0F, 1.0F);
/*     */         
/* 110 */         UtilsFX.renderQuadCentered(TEX_UNDEAD, size, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*     */         
/* 112 */         GL11.glEnable(2929);
/* 113 */         GlStateManager.func_179121_F(); continue;
/*     */       } 
/* 115 */       double numbers = Math.min(48.0D / scale + 1.0D, 4.0D);
/*     */       
/* 117 */       for (int i = 0; i < numbers; i++) {
/* 118 */         float numSize = (float)(((i * 16) / (numbers + 1.0D) + sizeOffset) % 16.0D / 12.0D) * size;
/*     */         
/* 120 */         GlStateManager.func_179094_E();
/* 121 */         GL11.glDisable(2929);
/*     */         
/* 123 */         GlStateManager.func_179137_b(-playerOffX, -playerOffY, -playerOffZ);
/* 124 */         GlStateManager.func_179137_b(eOffX, eOffY + (e.field_70131_O / 2.0F), eOffZ);
/* 125 */         GlStateManager.func_179114_b(-playerIn.field_70177_z, 0.0F, 1.0F, 0.0F);
/* 126 */         GlStateManager.func_179114_b(playerIn.field_70125_A, 1.0F, 0.0F, 0.0F);
/* 127 */         UtilsFX.renderQuadCentered(TEX, numSize, 1.0F, 1.0F, 1.0F, -99, 771, alpha);
/*     */         
/* 129 */         GL11.glEnable(2929);
/* 130 */         GlStateManager.func_179121_F();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handleRemoval(World worldIn, EntityPlayer playerIn) {}
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\lenses\AirLens.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */