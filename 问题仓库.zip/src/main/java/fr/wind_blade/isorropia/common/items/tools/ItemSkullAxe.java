/*     */ package fr.wind_blade.isorropia.common.items.tools;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.boss.EntityDragon;
/*     */ import net.minecraft.entity.monster.EntityCreeper;
/*     */ import net.minecraft.entity.monster.EntitySkeleton;
/*     */ import net.minecraft.entity.monster.EntityWitherSkeleton;
/*     */ import net.minecraft.entity.monster.EntityZombie;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.IItemPropertyGetter;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ActionResult;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import thaumcraft.api.ThaumcraftMaterials;
/*     */ import thaumcraft.api.items.IRechargable;
/*     */ import thaumcraft.common.lib.utils.EntityUtils;
/*     */ 
/*     */ public class ItemSkullAxe
/*     */   extends ItemSword
/*     */   implements IRechargable
/*     */ {
/*  35 */   public static HashMap<EntityPlayer, EntityLivingBase> jumps = new HashMap<>();
/*  36 */   public static HashMap<EntityPlayer, Long> jumpsTime = new HashMap<>();
/*  37 */   public static HashMap<EntityPlayer, EnumHand> jumpsHand = new HashMap<>();
/*     */   
/*     */   public ItemSkullAxe() {
/*  40 */     super(ThaumcraftMaterials.TOOLMAT_ELEMENTAL);
/*  41 */     func_185043_a(new ResourceLocation("active"), new IItemPropertyGetter()
/*     */         {
/*     */           @SideOnly(Side.CLIENT)
/*     */           public float func_185085_a(ItemStack stack, World worldIn, EntityLivingBase entityIn) {
/*  45 */             return stack.func_77942_o() ? (stack.func_77978_p().func_74767_n("ir_active") ? 1.0F : 0.0F) : 0.0F;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxCharge(ItemStack arg0, EntityLivingBase arg1) {
/*  52 */     return 200;
/*     */   }
/*     */   
/*     */   public static void update(EntityPlayer player) {
/*  56 */     if (!jumps.containsKey(player))
/*     */       return; 
/*  58 */     player.field_70143_R = 0.0F;
/*  59 */     EntityLivingBase base = jumps.get(player);
/*  60 */     Vec3d len = new Vec3d(base.field_70165_t - player.field_70165_t, base.field_70163_u - player.field_70163_u, base.field_70161_v - base.field_70161_v);
/*  61 */     float depth = (float)Math.sqrt(len.field_72450_a * len.field_72450_a + len.field_72449_c * len.field_72449_c);
/*  62 */     if (depth < 0.8D) {
/*  63 */       player.func_184598_c(jumpsHand.get(player));
/*  64 */       jumpsHand.remove(player);
/*  65 */       jumps.remove(player);
/*  66 */       jumpsTime.remove(player);
/*  67 */       player.func_71059_n((Entity)base);
/*  68 */       player.field_70159_w = 0.0D;
/*  69 */       player.field_70181_x = 0.0D;
/*  70 */       player.field_70179_y = 0.0D;
/*  71 */       player.func_184224_h(false);
/*  72 */       player.field_70170_p.func_72866_a((Entity)player, false);
/*     */     
/*     */     }
/*  75 */     else if (jumps.containsKey(player) && System.currentTimeMillis() - ((Long)jumpsTime.get(player)).longValue() >= 3000L) {
/*  76 */       jumps.remove(player);
/*  77 */       jumpsTime.remove(player);
/*  78 */       jumpsTime.remove(player);
/*  79 */       player.func_184224_h(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
/*  85 */     ItemStack stack = playerIn.func_184586_b(handIn);
/*     */     
/*  87 */     stack.func_77982_d(stack.func_77942_o() ? stack.func_77978_p() : new NBTTagCompound());
/*  88 */     if (playerIn.func_70093_af()) {
/*  89 */       if (!stack.func_190926_b() && stack.func_77973_b() == ItemsIS.itemSkullAxe)
/*  90 */         stack.func_77978_p().func_74757_a("ir_active", !stack.func_77978_p().func_74767_n("ir_active")); 
/*  91 */     } else if (!stack.func_77978_p().func_74764_b("cooldown") || 
/*  92 */       System.currentTimeMillis() - stack.func_77978_p().func_74763_f("cooldown") >= 3000L) {
/*  93 */       Entity entity = EntityUtils.getPointedEntity(worldIn, (Entity)playerIn, 1.0D, 30.0D, 0.0F, true);
/*  94 */       if (entity instanceof EntityLivingBase) {
/*  95 */         stack.func_77982_d(stack.func_77942_o() ? stack.func_77978_p() : new NBTTagCompound());
/*  96 */         Vec3d depth = new Vec3d(entity.field_70165_t - playerIn.field_70165_t, entity.field_70163_u - playerIn.field_70163_u, entity.field_70161_v - playerIn.field_70161_v);
/*     */         
/*  98 */         playerIn.field_70159_w += depth.field_72450_a / 2.0D;
/*  99 */         playerIn.field_70181_x += depth.field_72448_b / 2.0D;
/* 100 */         playerIn.field_70179_y += depth.field_72449_c / 2.0D;
/* 101 */         jumps.put(playerIn, (EntityLivingBase)entity);
/* 102 */         jumpsTime.put(playerIn, Long.valueOf(System.currentTimeMillis()));
/* 103 */         jumpsHand.put(playerIn, handIn);
/* 104 */         stack.func_77978_p().func_74772_a("cooldown", System.currentTimeMillis());
/* 105 */         playerIn.func_184224_h(true);
/*     */       } 
/*     */     } 
/* 108 */     return super.func_77659_a(worldIn, playerIn, handIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRechargable.EnumChargeDisplay showInHud(ItemStack arg0, EntityLivingBase arg1) {
/* 113 */     return IRechargable.EnumChargeDisplay.NORMAL;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_77662_d() {
/* 118 */     return true;
/*     */   }
/*     */   
/* 121 */   public static final List<Class<?>> TYPES = (List<Class<?>>)ImmutableList.of(EntitySkeleton.class, EntityWitherSkeleton.class, EntityZombie.class, EntityPlayerMP.class, EntityCreeper.class, EntityDragon.class);
/*     */ 
/*     */   
/*     */   public static int getHeadId(Class<?> clazz) {
/* 125 */     return TYPES.indexOf(clazz);
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\tools\ItemSkullAxe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */