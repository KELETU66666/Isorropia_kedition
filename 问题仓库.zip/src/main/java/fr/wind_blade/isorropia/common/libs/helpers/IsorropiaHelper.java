/*     */ package fr.wind_blade.isorropia.common.libs.helpers;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.minecraft.MinecraftProfileTexture;
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.blocks.BlocksIS;
/*     */ import fr.wind_blade.isorropia.common.capabilities.LivingCapability;
/*     */ import fr.wind_blade.isorropia.common.celestial.CelestialBody;
/*     */ import fr.wind_blade.isorropia.common.celestial.ICelestialBody;
/*     */ import fr.wind_blade.isorropia.common.config.ConfigContainment;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.IImageBuffer;
/*     */ import net.minecraft.client.renderer.ImageBufferDownload;
/*     */ import net.minecraft.client.renderer.ThreadDownloadImageData;
/*     */ import net.minecraft.client.renderer.texture.ITextureObject;
/*     */ import net.minecraft.client.resources.DefaultPlayerSkin;
/*     */ import net.minecraft.client.resources.SkinManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.passive.EntityTameable;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTUtil;
/*     */ import net.minecraft.network.PacketBuffer;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializer;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraft.util.text.translation.I18n;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.blocks.BlocksTC;
/*     */ import thaumcraft.common.lib.utils.InventoryUtils;
/*     */ 
/*     */ 
/*     */ public class IsorropiaHelper
/*     */ {
/*  57 */   public static GameProfile AUTHOR_GAMEPROFILE = new GameProfile(
/*  58 */       UUID.fromString("e5528ce9-e498-40e1-833b-2dceee510efb"), "Wind_Blade");
/*     */   
/*     */   public static final String ENTITY_ID = "ENTITY_ID";
/*     */   
/*     */   public static final String ENTITY_UUID = "ENTITY_UUID";
/*     */   public static final String ENTITY_DATA = "ENTITY_DATA";
/*  64 */   public static final Map<UUID, Float> contain = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityPlayer getOwner(EntityLiving living) {
/*     */     EntityPlayer player;
/*  70 */     if (living instanceof EntityTameable) {
/*  71 */       player = (EntityPlayer)((EntityTameable)living).func_70902_q();
/*     */     } else {
/*  73 */       player = living.field_70170_p.func_152378_a(((LivingCapability)Common.getCap((EntityLivingBase)living)).uuidOwner);
/*     */     } 
/*     */     
/*  76 */     return player;
/*     */   }
/*     */   
/*     */   public static boolean canEntityBeJarred(EntityLiving living) {
/*  80 */     switch (ConfigContainment.TYPE.getName()) {
/*     */       case "whitelist":
/*  82 */         return ConfigContainment.ENTRIES.contains(living.getClass());
/*     */       case "blacklist":
/*  84 */         return !ConfigContainment.ENTRIES.contains(living.getClass());
/*     */     } 
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean doPlayerHaveJar(EntityPlayer player, boolean simulate) {
/*  92 */     boolean flag = (InventoryUtils.isPlayerCarryingAmount(player, new ItemStack(BlocksTC.jarNormal, 1), false) || player.func_184812_l_());
/*     */     
/*  94 */     if (!simulate && !flag) {
/*  95 */       player.func_145747_a((ITextComponent)new TextComponentString(TextFormatting.ITALIC + "" + TextFormatting.GRAY + 
/*  96 */             I18n.func_74838_a("isorropia.containment.jar")));
/*     */     }
/*     */     
/*  99 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean containEntity(EntityLivingBase owner, EntityLivingBase target, float amount) {
/* 112 */     float progression = (contain.containsKey(target.func_110124_au()) ? ((Float)contain.get(target.func_110124_au())).floatValue() : 0.0F) + amount;
/*     */     
/* 114 */     contain.put(target.func_110124_au(), Float.valueOf(progression));
/* 115 */     return (progression > target.func_110143_aJ() * 20.0F);
/*     */   }
/*     */   
/*     */   public static void playerJarEntity(EntityPlayer player, EntityLiving target) {
/* 119 */     if (InventoryUtils.consumePlayerItem(player, Item.func_150898_a(BlocksTC.jarNormal), 0) || player
/* 120 */       .func_184812_l_()) {
/* 121 */       ItemStack jar = new ItemStack((Block)BlocksIS.blockJarSoul);
/* 122 */       jar.func_77982_d(livingToNBT(target));
/*     */       
/* 124 */       if (!player.field_71071_by.func_70441_a(jar)) {
/* 125 */         player.func_70099_a(jar, 1.0F);
/*     */       }
/*     */       
/* 128 */       contain.remove(target.func_110124_au());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static NBTTagCompound livingToNBT(EntityLiving living) {
/* 133 */     NBTTagCompound nbt = livingToNBTNoWorld(living);
/* 134 */     living.field_70170_p.func_72900_e((Entity)living);
/* 135 */     return nbt;
/*     */   }
/*     */   
/*     */   public static NBTTagCompound livingToNBTNoWorld(EntityLiving living) {
/* 139 */     NBTTagCompound nbt = new NBTTagCompound();
/* 140 */     NBTTagCompound entityData = new NBTTagCompound();
/* 141 */     living.func_70039_c(entityData);
/*     */     
/* 143 */     nbt.func_74782_a("ENTITY_DATA", (NBTBase)entityData);
/* 144 */     return nbt;
/*     */   }
/*     */   
/*     */   public static EntityLiving nbtToLiving(NBTTagCompound nbt, World world, BlockPos pos) {
/* 148 */     EntityLiving living = (EntityLiving)EntityList.func_75615_a(nbt.func_74775_l("ENTITY_DATA"), world);
/*     */     
/* 150 */     if (living != null && !living.field_70128_L) {
/* 151 */       living.func_174828_a(pos, 0.0F, 0.0F);
/* 152 */       living.func_70634_a(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/* 153 */       world.func_72838_d((Entity)living);
/*     */     } 
/*     */     
/* 156 */     return living;
/*     */   }
/*     */   
/*     */   public static NBTTagCompound livingBaseToStatue(EntityLivingBase base) {
/* 160 */     NBTTagCompound nbt = new NBTTagCompound();
/*     */     
/* 162 */     if (base instanceof EntityLiving) {
/* 163 */       nbt = livingToNBTNoWorld((EntityLiving)base);
/* 164 */       nbt.func_74778_a("ENTITY_ID", "LIVING");
/* 165 */     } else if (base instanceof EntityPlayer) {
/* 166 */       NBTTagCompound profile = new NBTTagCompound();
/* 167 */       NBTUtil.func_180708_a(profile, ((EntityPlayer)base).func_146103_bH());
/* 168 */       nbt.func_74778_a("ENTITY_ID", "PLAYER");
/* 169 */       nbt.func_74782_a("ENTITY_DATA", (NBTBase)profile);
/*     */     } 
/*     */     
/* 172 */     return nbt;
/*     */   }
/*     */   
/*     */   public static void profileToStatueData(NBTTagCompound nbt, GameProfile profile) {
/* 176 */     NBTTagCompound data = new NBTTagCompound();
/* 177 */     NBTUtil.func_180708_a(data, profile);
/* 178 */     nbt.func_74782_a("ENTITY_DATA", (NBTBase)data);
/* 179 */     nbt.func_74778_a("ENTITY_ID", "PLAYER");
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public static ResourceLocation loadSkin(final MinecraftProfileTexture profileTexture, final MinecraftProfileTexture.Type textureType, @Nullable final SkinManager.SkinAvailableCallback skinAvailableCallback) {
/* 185 */     final ResourceLocation resourcelocation = new ResourceLocation("skins/" + profileTexture.getHash());
/* 186 */     ITextureObject itextureobject = (Minecraft.func_71410_x()).field_71446_o.func_110581_b(resourcelocation);
/*     */     
/* 188 */     if (itextureobject != null) {
/* 189 */       if (skinAvailableCallback != null) {
/* 190 */         skinAvailableCallback.func_180521_a(textureType, resourcelocation, profileTexture);
/*     */       }
/*     */     } else {
/*     */       
/* 194 */       File file1 = new File(new File((Minecraft.func_71410_x()).field_71412_D, "skins"), (profileTexture.getHash().length() > 2) ? profileTexture.getHash().substring(0, 2) : "xx");
/* 195 */       File file2 = new File(file1, profileTexture.getHash());
/* 196 */       final ImageBufferDownload iimagebuffer = (textureType == MinecraftProfileTexture.Type.SKIN) ? new ImageBufferDownload() : null;
/*     */       
/* 198 */       ThreadDownloadImageData threaddownloadimagedata = new ThreadDownloadImageData(file2, profileTexture.getUrl(), DefaultPlayerSkin.func_177335_a(), new IImageBuffer()
/*     */           {
/*     */             public BufferedImage func_78432_a(BufferedImage image) {
/* 201 */               if (iimagebuffer != null) {
/* 202 */                 image = iimagebuffer.func_78432_a(image);
/*     */               }
/*     */               
/* 205 */               return image;
/*     */             }
/*     */ 
/*     */             
/*     */             public void func_152634_a() {
/* 210 */               if (iimagebuffer != null) {
/* 211 */                 iimagebuffer.func_152634_a();
/*     */               }
/*     */               
/* 214 */               if (skinAvailableCallback != null) {
/* 215 */                 skinAvailableCallback.func_180521_a(textureType, resourcelocation, profileTexture);
/*     */               }
/*     */             }
/*     */           });
/*     */       
/* 220 */       (Minecraft.func_71410_x()).field_71446_o.func_110579_a(resourcelocation, (ITextureObject)threaddownloadimagedata);
/*     */     } 
/*     */     
/* 223 */     return resourcelocation;
/*     */   }
/*     */   
/*     */   public static Entity getEntityByUUID(UUID uuid, World world) {
/* 227 */     for (Entity e : world.field_72996_f) {
/* 228 */       if (e.getPersistentID().equals(uuid))
/* 229 */         return e; 
/* 230 */     }  return null;
/*     */   }
/*     */   
/*     */   public static ICelestialBody getCurrentCelestialBody(World world) {
/* 234 */     return CelestialBody.isDay(world) ? CelestialBody.SUN : CelestialBody.MOON;
/*     */   }
/*     */   
/* 237 */   public static final DataSerializer<Aspect> ASPECT = new DataSerializer<Aspect>()
/*     */     {
/*     */       public DataParameter<Aspect> func_187161_a(int id)
/*     */       {
/* 241 */         return new DataParameter(id, this);
/*     */       }
/*     */ 
/*     */       
/*     */       public void write(PacketBuffer buf, Aspect value) {
/* 246 */         buf.func_180714_a((value != null) ? value.getTag() : "");
/*     */       }
/*     */ 
/*     */       
/*     */       public Aspect read(PacketBuffer buf) throws IOException {
/* 251 */         return Aspect.getAspect(buf.func_150789_c(32767));
/*     */       }
/*     */ 
/*     */       
/*     */       public Aspect copyValue(Aspect value) {
/* 256 */         return value;
/*     */       }
/*     */     };
/*     */   
/*     */   static {
/* 261 */     DataSerializers.func_187189_a(ASPECT);
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\helpers\IsorropiaHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */