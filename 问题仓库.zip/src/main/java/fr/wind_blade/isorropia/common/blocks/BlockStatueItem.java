 package fr.wind_blade.isorropia.common.blocks;
 
 import com.mojang.authlib.GameProfile;
 import fr.wind_blade.isorropia.common.libs.helpers.IsorropiaHelper;
 import java.util.UUID;
 import net.minecraft.block.Block;
 import net.minecraft.item.ItemBlock;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.tileentity.TileEntitySkull;
 import org.apache.commons.lang3.StringUtils;
 
 
 
 public class BlockStatueItem
   extends ItemBlock
 {
   public BlockStatueItem(Block block) {
/* 18 */     super(block);
   }
 
   
   public boolean func_179215_a(NBTTagCompound nbt) {
/* 23 */     super.func_179215_a(nbt);
/* 24 */     return checkAndValidNBT(nbt);
   }
 
   
   public static boolean checkAndValidNBT(NBTTagCompound nbt) {
/* 29 */     if (!nbt.func_74779_i("ENTITY_ID").equals("LIVING")) {
       
/* 31 */       NBTTagCompound profileNBT = nbt.func_74775_l("ENTITY_DATA");
/* 32 */       boolean flagName = !StringUtils.isBlank(profileNBT.func_74779_i("Name"));
/* 33 */       boolean flagId = !StringUtils.isBlank(profileNBT.func_74779_i("Id"));
       
/* 35 */       GameProfile gameprofile = TileEntitySkull.func_174884_b((flagName && flagId) ? new GameProfile(
/* 36 */             UUID.fromString(profileNBT.func_74779_i("Id")), profileNBT.func_74779_i("Name")) : (flagName ? new GameProfile(null, profileNBT
/* 37 */             .func_74779_i("Name")) : (flagId ? new GameProfile(
/* 38 */             UUID.fromString(profileNBT.func_74779_i("Id")), null) : IsorropiaHelper.AUTHOR_GAMEPROFILE)));
       
/* 40 */       IsorropiaHelper.profileToStatueData(nbt, gameprofile);
/* 41 */       return true;
     } 
     
/* 44 */     return false;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockStatueItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */