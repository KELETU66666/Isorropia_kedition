/*     */ package fr.wind_blade.isorropia.common.blocks;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyInteger;
/*     */ import net.minecraft.block.state.BlockStateContainer;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockArcaneCake
/*     */   extends Block
/*     */ {
/*  25 */   public static final PropertyInteger CAKE_STATE = PropertyInteger.func_177719_a("cake_state", 0, 12);
/*  26 */   protected static final AxisAlignedBB[] CAKE_AABB = new AxisAlignedBB[] { new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D), new AxisAlignedBB(0.1875D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D), new AxisAlignedBB(0.3125D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D), new AxisAlignedBB(0.4375D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D), new AxisAlignedBB(0.5625D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D), new AxisAlignedBB(0.6875D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D), new AxisAlignedBB(0.8125D, 0.0D, 0.0625D, 0.9375D, 0.5D, 0.9375D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlockArcaneCake() {
/*  36 */     super(Material.field_151568_F);
/*  37 */     func_149675_a(true);
/*  38 */     func_149711_c(0.5F);
/*  39 */     func_180632_j(func_176223_P().func_177226_a((IProperty)CAKE_STATE, Integer.valueOf(0)));
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess source, BlockPos pos) {
/*  44 */     return CAKE_AABB[((Integer)state.func_177229_b((IProperty)CAKE_STATE)).intValue() / 2];
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_180640_a(IBlockState state, World worldIn, BlockPos pos) {
/*  50 */     return state.func_185890_d((IBlockAccess)worldIn, pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d(IBlockState state) {
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c(IBlockState state) {
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
/*  66 */     eatCakeSlice(worldIn, pos, playerIn);
/*  67 */     return super.func_180639_a(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/*  72 */     return func_176223_P().func_177226_a((IProperty)CAKE_STATE, Integer.valueOf(meta));
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/*  77 */     return ((Integer)state.func_177229_b((IProperty)CAKE_STATE)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockStateContainer func_180661_e() {
/*  82 */     return new BlockStateContainer(this, new IProperty[] { (IProperty)CAKE_STATE });
/*     */   }
/*     */   
/*     */   private void eatCakeSlice(World world, BlockPos pos, EntityPlayer player) {
/*  86 */     if (player.func_71043_e(false)) {
/*  87 */       player.func_71024_bL().func_75122_a(2, 1.0F);
/*  88 */       int l = func_176201_c(world.func_180495_p(pos)) + 1;
/*     */       
/*  90 */       if (l >= 12) {
/*  91 */         world.func_175698_g(pos);
/*     */       } else {
/*  93 */         world.func_180501_a(pos, func_176223_P().func_177226_a((IProperty)CAKE_STATE, Integer.valueOf(l)), 2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void func_180650_b(World worldIn, BlockPos pos, IBlockState state, Random rand) {
/*  99 */     super.func_180650_b(worldIn, pos, state, rand);
/* 100 */     int l = func_176201_c(state);
/* 101 */     if (l > 0) {
/* 102 */       l--;
/* 103 */       worldIn.func_180501_a(pos, state.func_177226_a((IProperty)CAKE_STATE, Integer.valueOf(l)), 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_149745_a(Random random) {
/* 109 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getPickBlock(IBlockState state, RayTraceResult target, World world, BlockPos pos, EntityPlayer player) {
/* 115 */     return new ItemStack(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176196_c(World worldIn, BlockPos pos) {
/* 120 */     return (super.func_176196_c(worldIn, pos) && canBlockStay(worldIn, pos));
/*     */   }
/*     */   
/*     */   public boolean canBlockStay(World world, BlockPos pos) {
/* 124 */     return world.func_180495_p(new BlockPos(pos.func_177958_n(), pos.func_177956_o() - 1, pos.func_177952_p())).func_185904_a().func_76220_a();
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockArcaneCake.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */