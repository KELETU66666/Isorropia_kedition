 package fr.wind_blade.isorropia.common.tiles;
 
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityList;
 import net.minecraft.nbt.NBTBase;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.util.ITickable;
 import thaumcraft.common.tiles.TileThaumcraft;
 
 
 
 public class TileJarSoul
   extends TileThaumcraft
   implements ITickable
 {
/* 16 */   public NBTTagCompound entityData = null;
/* 17 */   public Entity entity = null;
 
   
   public void func_73660_a() {
/* 21 */     if (this.entity == null && this.entityData != null && !this.entityData.func_74764_b("ENTITY_DATA")) {
/* 22 */       this.entity = EntityList.func_75615_a(this.entityData.func_74775_l("ENTITY_DATA"), this.field_145850_b);
       
/* 24 */       if (!this.field_145850_b.field_72995_K) {
/* 25 */         syncTile(false);
       }
     } 
   }
   
   public void readSyncNBT(NBTTagCompound nbt) {
/* 31 */     this.entityData = nbt.func_74775_l("entityData");
   }
 
   
   public NBTTagCompound writeSyncNBT(NBTTagCompound nbt) {
/* 36 */     if (this.entityData != null)
/* 37 */       nbt.func_74782_a("entityData", (NBTBase)this.entityData); 
/* 38 */     return nbt;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\tiles\TileJarSoul.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */