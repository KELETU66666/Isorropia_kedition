 package fr.wind_blade.isorropia.client.fx;
 
 import net.minecraft.client.Minecraft;
 import net.minecraft.world.World;
 import net.minecraftforge.fml.relauncher.Side;
 import net.minecraftforge.fml.relauncher.SideOnly;
 
 @SideOnly(Side.CLIENT)
 public class ISFXDispatcher
 {
   public static void elemental(World worldIn, double x, double y, double z) {
/* 12 */     (Minecraft.func_71410_x()).field_71452_i.func_78873_a(new FXElementalWisp(worldIn, x, y, z));
   }
   
   public static void fxAbsorption(double x, double y, double z, float r, float g, float b, boolean absorption) {
/* 16 */     FXCelestialAbsorption efa = new FXCelestialAbsorption((World)(Minecraft.func_71410_x()).field_71441_e, x, y, z, r, g, b, absorption);
     
/* 18 */     (Minecraft.func_71410_x()).field_71452_i.func_78873_a(efa);
   }
   
   public static void fluxExplosion(World world, double x, double y, double z) {
/* 22 */     FXFluxExplosion fx = new FXFluxExplosion(world, x, y, z);
/* 23 */     (Minecraft.func_71410_x()).field_71452_i.func_78873_a(fx);
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\fx\ISFXDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */