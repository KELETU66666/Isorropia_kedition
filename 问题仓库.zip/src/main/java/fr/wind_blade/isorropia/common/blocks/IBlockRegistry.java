/*   */ package fr.wind_blade.isorropia.common.blocks;
/*   */ 
/*   */ public interface IBlockRegistry {
/*   */   default boolean haveItemBlock() {
/* 5 */     return true;
/*   */   }
/*   */   
/*   */   default boolean isInCreativeTabs() {
/* 9 */     return true;
/*   */   }
/*   */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\IBlockRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */