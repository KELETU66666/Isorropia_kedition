/*     */ package fr.wind_blade.isorropia.client;
/*     */ 
/*     */ import fr.wind_blade.isorropia.client.libs.RenderEventHandler;
/*     */ import fr.wind_blade.isorropia.client.renderer.RenderCustomItem;
/*     */ import fr.wind_blade.isorropia.client.renderer.tiles.RenderJarSoul;
/*     */ import fr.wind_blade.isorropia.client.renderer.tiles.RenderModifiedMatrix;
/*     */ import fr.wind_blade.isorropia.client.renderer.tiles.RenderStatue;
/*     */ import fr.wind_blade.isorropia.common.Common;
/*     */ import fr.wind_blade.isorropia.common.blocks.BlocksIS;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityGravekeeper;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityHangingLabel;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityHellHound;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityJellyRabbit;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityOrePig;
/*     */ import fr.wind_blade.isorropia.common.entities.EntitySaehrimnir;
/*     */ import fr.wind_blade.isorropia.common.entities.EntitySaehrimnirReborn;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityScholarChicken;
/*     */ import fr.wind_blade.isorropia.common.entities.EntitySheeder;
/*     */ import fr.wind_blade.isorropia.common.entities.EntityTaintPig;
/*     */ import fr.wind_blade.isorropia.common.entities.projectile.EntityEmber;
/*     */ import fr.wind_blade.isorropia.common.entities.projectile.EntityIncubatedEgg;
/*     */ import fr.wind_blade.isorropia.common.events.KeyHandler;
/*     */ import fr.wind_blade.isorropia.common.items.ItemsIS;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileJarSoul;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileModifiedMatrix;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileStatue;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.color.IItemColor;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.entity.RenderSnowball;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntityItemStackRenderer;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.client.model.obj.OBJLoader;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.client.registry.ClientRegistry;
/*     */ import net.minecraftforge.fml.client.registry.IRenderFactory;
/*     */ import net.minecraftforge.fml.client.registry.RenderingRegistry;
/*     */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*     */ import net.minecraftforge.fml.relauncher.ReflectionHelper;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.api.aspects.IEssentiaContainerItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class Client
/*     */   extends Common
/*     */ {
/*     */   public void preInit(FMLPreInitializationEvent event) {
/*  64 */     super.preInit(event);
/*     */     
/*  66 */     MinecraftForge.EVENT_BUS.register(RenderEventHandler.class);
/*  67 */     RenderingRegistry.registerEntityRenderingHandler(EntityIncubatedEgg.class, renderManager -> new RenderSnowball(renderManager, ItemsIS.itemIncubatedEgg, Minecraft.func_71410_x().func_175599_af()));
/*     */ 
/*     */     
/*  70 */     ClientRegistry.bindTileEntitySpecialRenderer(TileJarSoul.class, (TileEntitySpecialRenderer)new RenderJarSoul());
/*  71 */     ClientRegistry.bindTileEntitySpecialRenderer(TileStatue.class, (TileEntitySpecialRenderer)new RenderStatue());
/*  72 */     ClientRegistry.bindTileEntitySpecialRenderer(TileModifiedMatrix.class, (TileEntitySpecialRenderer)new RenderModifiedMatrix());
/*     */     
/*  74 */     RenderingRegistry.registerEntityRenderingHandler(EntitySaehrimnir.class, fr.wind_blade.isorropia.client.renderer.entities.RenderSaehrimnir::new);
/*  75 */     RenderingRegistry.registerEntityRenderingHandler(EntitySaehrimnirReborn.class, fr.wind_blade.isorropia.client.renderer.entities.RenderSaehrimnirReborn::new);
/*  76 */     RenderingRegistry.registerEntityRenderingHandler(EntityTaintPig.class, fr.wind_blade.isorropia.client.renderer.entities.RenderTaintPig::new);
/*  77 */     RenderingRegistry.registerEntityRenderingHandler(EntityGravekeeper.class, net.minecraft.client.renderer.entity.RenderOcelot::new);
/*  78 */     RenderingRegistry.registerEntityRenderingHandler(EntitySheeder.class, fr.wind_blade.isorropia.client.renderer.entities.RenderSheeder::new);
/*  79 */     RenderingRegistry.registerEntityRenderingHandler(EntityOrePig.class, fr.wind_blade.isorropia.client.renderer.entities.RenderOrePig::new);
/*  80 */     RenderingRegistry.registerEntityRenderingHandler(EntityScholarChicken.class, fr.wind_blade.isorropia.client.renderer.entities.RenderScholarChicken::new);
/*  81 */     RenderingRegistry.registerEntityRenderingHandler(EntityJellyRabbit.class, fr.wind_blade.isorropia.client.renderer.entities.RenderJellyRabbit::new);
/*  82 */     RenderingRegistry.registerEntityRenderingHandler(EntityHangingLabel.class, fr.wind_blade.isorropia.client.renderer.entities.RenderHangingLabel::new);
/*  83 */     RenderingRegistry.registerEntityRenderingHandler(EntityHellHound.class, fr.wind_blade.isorropia.client.renderer.entities.RenderHellHound::new);
/*  84 */     RenderingRegistry.registerEntityRenderingHandler(EntityEmber.class, fr.wind_blade.isorropia.client.renderer.entities.RenderEmber::new);
/*     */     
/*  86 */     OBJLoader.INSTANCE.addDomain("isorropia");
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(FMLInitializationEvent event) {
/*  91 */     super.init(event);
/*  92 */     ItemsIS.items.stream().filter(item -> item instanceof fr.wind_blade.isorropia.common.blocks.IItemStackRenderProvider)
/*  93 */       .forEach(item -> item.setTileEntityItemStackRenderer((TileEntityItemStackRenderer)new RenderCustomItem()));
/*  94 */     BlocksIS.blocks.stream().filter(block -> Item.func_150898_a(block) instanceof fr.wind_blade.isorropia.common.blocks.IItemStackRenderProvider)
/*  95 */       .forEach(block -> Item.func_150898_a(block).setTileEntityItemStackRenderer((TileEntityItemStackRenderer)new RenderCustomItem()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void postInit(FMLPostInitializationEvent event) {
/* 100 */     super.postInit(event);
/* 101 */     IItemColor itemEssentiaColourHandler = (stack, tintIndex) -> {
/*     */         IEssentiaContainerItem item = (IEssentiaContainerItem)stack.func_77973_b();
/* 103 */         return (item != null && item.getAspects(stack) != null) ? item.getAspects(stack).getAspects()[0].getColor() : Aspect.SENSES.getColor();
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     Minecraft.func_71410_x().getItemColors().func_186730_a(itemEssentiaColourHandler, new Item[] { (Item)ItemsIS.itemJelly });
/*     */     
/* 111 */     MinecraftForge.EVENT_BUS.register(new KeyHandler());
/* 112 */     RenderEventHandler.tip = ReflectionHelper.findMethod(Render.class, "getEntityTexture", "func_110775_a", new Class[] { Entity.class });
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\client\Client.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */