/*   */ package fr.wind_blade.isorropia.common.libs.curative;
/*   */ 
/*   */ import fr.wind_blade.isorropia.common.libs.research.recipes.CurativeInfusionRecipe;
/*   */ 
/*   */ public class BaseInfusion
/*   */   extends CurativeInfusionRecipe {
/*   */   protected BaseInfusion(CurativeInfusionRecipe.Builder builder) {
/* 8 */     super(builder);
/*   */   }
/*   */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\curative\BaseInfusion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */