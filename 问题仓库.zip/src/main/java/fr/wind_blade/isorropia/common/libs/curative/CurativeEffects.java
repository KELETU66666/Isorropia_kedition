/*     */ package fr.wind_blade.isorropia.common.libs.curative;
/*     */ 
/*     */ import fr.wind_blade.isorropia.common.IsorropiaAPI;
/*     */ import fr.wind_blade.isorropia.common.tiles.TileVat;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import thaumcraft.api.ThaumcraftApiHelper;
/*     */ import thaumcraft.api.aspects.Aspect;
/*     */ import thaumcraft.common.entities.monster.mods.ChampionModifier;
/*     */ 
/*     */ 
/*     */ public class CurativeEffects
/*     */ {
/*     */   public static class IGNIS_CURE
/*     */     implements ICurativeEffectProvider
/*     */   {
/*     */     public Aspect getAspect() {
/*  19 */       return Aspect.FIRE;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean effectCanApply(EntityLivingBase contained, TileVat vat) {
/*  24 */       return (contained instanceof thaumcraft.api.entities.ITaintedMob || (contained
/*  25 */         .func_110148_a(ThaumcraftApiHelper.CHAMPION_MOD) != null && contained
/*  26 */         .func_110148_a(ThaumcraftApiHelper.CHAMPION_MOD).func_111126_e() == 13.0D));
/*     */     }
/*     */ 
/*     */     
/*     */     public void onApply(EntityLivingBase contained, TileVat vat) {
/*  31 */       if (contained instanceof thaumcraft.api.entities.ITaintedMob) {
/*  32 */         contained.func_70097_a(DamageSource.field_76376_m, 1.0F);
/*  33 */       } else if ((vat.func_145831_w()).field_73012_v.nextInt(100) < 3) {
/*  34 */         contained.func_110148_a(ThaumcraftApiHelper.CHAMPION_MOD)
/*  35 */           .func_111124_b((ChampionModifier.mods[13]).attributeMod);
/*     */       } 
/*     */     }
/*     */     
/*     */     public int getCooldown(EntityLivingBase contained, TileVat vat) {
/*  40 */       return 4;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LIFE_HEAL
/*     */     implements ICurativeEffectProvider
/*     */   {
/*     */     public Aspect getAspect() {
/*  48 */       return Aspect.LIFE;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean effectCanApply(EntityLivingBase contained, TileVat vat) {
/*  53 */       return (!contained.func_70662_br() && contained.func_110143_aJ() < contained.func_110138_aP());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onApply(EntityLivingBase contained, TileVat vat) {
/*  58 */       contained.func_70691_i(1.0F);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getCooldown(EntityLivingBase contained, TileVat vat) {
/*  63 */       return 50;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class HUNGER_FOOD
/*     */     implements ICurativeEffectProvider
/*     */   {
/*     */     public Aspect getAspect() {
/*  71 */       return IsorropiaAPI.HUNGER;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean effectCanApply(EntityLivingBase contained, TileVat vat) {
/*  76 */       return (contained instanceof EntityPlayer && ((EntityPlayer)contained).func_71024_bL().func_75121_c());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onApply(EntityLivingBase contained, TileVat vat) {
/*  81 */       ((EntityPlayer)contained).func_71024_bL().func_75122_a(1, 1.0F);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getCooldown(EntityLivingBase contained, TileVat vat) {
/*  86 */       return 25;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DEATH_HEAL
/*     */     implements ICurativeEffectProvider
/*     */   {
/*     */     public Aspect getAspect() {
/*  94 */       return Aspect.DEATH;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean effectCanApply(EntityLivingBase contained, TileVat vat) {
/*  99 */       return (contained.func_70662_br() && contained.func_110143_aJ() < contained.func_110138_aP());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onApply(EntityLivingBase contained, TileVat vat) {
/* 104 */       contained.func_70691_i(4.0F);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getCooldown(EntityLivingBase contained, TileVat vat) {
/* 109 */       return 50;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class UNDEAD_HEAL
/*     */     implements ICurativeEffectProvider
/*     */   {
/*     */     public Aspect getAspect() {
/* 118 */       return Aspect.UNDEAD;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean effectCanApply(EntityLivingBase contained, TileVat vat) {
/* 123 */       return (contained.func_70662_br() && contained.func_110143_aJ() < contained.func_110138_aP());
/*     */     }
/*     */ 
/*     */     
/*     */     public void onApply(EntityLivingBase contained, TileVat vat) {
/* 128 */       contained.func_70691_i(8.0F);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getCooldown(EntityLivingBase contained, TileVat vat) {
/* 133 */       return 40;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\libs\curative\CurativeEffects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */