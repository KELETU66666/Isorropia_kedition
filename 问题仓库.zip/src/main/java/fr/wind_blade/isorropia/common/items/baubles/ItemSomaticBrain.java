 package fr.wind_blade.isorropia.common.items.baubles;
 
 import baubles.api.BaubleType;
 import baubles.api.IBauble;
 import baubles.api.render.IRenderBauble;
 import fr.wind_blade.isorropia.client.model.ModelSomaticBrain;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.renderer.GlStateManager;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.inventory.EntityEquipmentSlot;
 import net.minecraft.item.EnumRarity;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 
 public class ItemSomaticBrain
   extends Item implements IBauble, IRenderBauble {
   public ItemSomaticBrain() {
/* 18 */     func_77625_d(1);
   }
 
   
   public EnumRarity func_77613_e(ItemStack itemstack) {
/* 23 */     return EnumRarity.RARE;
   }
 
   
   public BaubleType getBaubleType(ItemStack arg0) {
/* 28 */     return BaubleType.HEAD;
   }
 
   
   public void onPlayerBaubleRender(ItemStack stack, EntityPlayer player, IRenderBauble.RenderType type, float arg3) {
/* 33 */     if (type == IRenderBauble.RenderType.HEAD) {
/* 34 */       boolean helmet = !player.func_184582_a(EntityEquipmentSlot.HEAD).func_190926_b();
/* 35 */       IRenderBauble.Helper.translateToHeadLevel(player);
/* 36 */       IRenderBauble.Helper.translateToFace();
/* 37 */       IRenderBauble.Helper.defaultTransforms();
/* 38 */       GlStateManager.func_179152_a(1.81F, -1.81F, 1.81F);
/* 39 */       GlStateManager.func_179137_b(0.0D, helmet ? -1.73D : -1.72D, 0.27D);
/* 40 */       GlStateManager.func_179147_l();
/* 41 */       (Minecraft.func_71410_x()).field_71446_o.func_110577_a(ModelSomaticBrain.TEX);
/* 42 */       ModelSomaticBrain.INSTANCE.func_78088_a(null, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/* 43 */       GlStateManager.func_179084_k();
     } 
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\items\baubles\ItemSomaticBrain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */