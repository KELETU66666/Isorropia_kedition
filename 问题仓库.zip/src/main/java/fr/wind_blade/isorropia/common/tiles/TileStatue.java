 package fr.wind_blade.isorropia.common.tiles;
 
 import fr.wind_blade.isorropia.common.blocks.BlockStatueItem;
 import net.minecraft.block.Block;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.EntityList;
 import net.minecraft.nbt.NBTBase;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.util.ITickable;
 import net.minecraft.util.math.AxisAlignedBB;
 import thaumcraft.common.tiles.TileThaumcraft;
 
 
 
 
 public class TileStatue
   extends TileThaumcraft
   implements ITickable
 {
   protected NBTTagCompound entityData;
   protected Entity entity;
   protected boolean check;
   
   public void func_73660_a() {
/* 25 */     if (!this.field_145850_b.field_72995_K && !this.check && getEntityData() != null && 
/* 26 */       !getEntityData().func_74764_b("ENTITY_DATA") && 
/* 27 */       getEntityData().func_74779_i("ENTITY_ID").equals("LIVING")) {
/* 28 */       setEntity(EntityList.func_75615_a(
/* 29 */             getEntityData().func_74775_l("ENTITY_DATA"), this.field_145850_b));
/* 30 */       if (this.entity != null) {
/* 31 */         syncTile(false);
/* 32 */         this.check = true;
       } 
     } 
   }
 
 
   
   public void unpetrificate() {}
 
 
   
   public void readSyncNBT(NBTTagCompound nbt) {
/* 44 */     setEntityData(nbt.func_74775_l("entityData"));
     
/* 46 */     if (getEntityData().func_74779_i("ENTITY_ID").equals("LIVING")) {
/* 47 */       setEntity(
/* 48 */           EntityList.func_75615_a(getEntityData().func_74775_l("ENTITY_DATA"), this.field_145850_b));
     }
   }
 
   
   public NBTTagCompound writeSyncNBT(NBTTagCompound nbt) {
/* 54 */     nbt.func_74782_a("entityData", (NBTBase)getEntityData());
/* 55 */     return nbt;
   }
   
   public AxisAlignedBB getAABB() {
/* 59 */     return (getEntity() != null) ? getEntity().func_174813_aQ() : Block.field_185505_j;
   }
   
   public NBTTagCompound getEntityData() {
/* 63 */     return this.entityData;
   }
   
   public void setEntityData(NBTTagCompound entityData) {
/* 67 */     if (this.entityData != entityData) {
/* 68 */       BlockStatueItem.checkAndValidNBT(entityData);
/* 69 */       this.entityData = entityData;
/* 70 */       this.check = false;
     } 
   }
   
   public Entity getEntity() {
/* 75 */     return this.entity;
   }
   
   public void setEntity(Entity entity) {
/* 79 */     this.entity = entity;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\tiles\TileStatue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */