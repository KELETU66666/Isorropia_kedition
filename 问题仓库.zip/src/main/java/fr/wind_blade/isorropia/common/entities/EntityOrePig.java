 package fr.wind_blade.isorropia.common.entities;
 
 import fr.wind_blade.isorropia.common.config.Config;
 import fr.wind_blade.isorropia.common.config.DuoWeightedRandom;
 import fr.wind_blade.isorropia.common.config.OrePigEntry;
 import fr.wind_blade.isorropia.common.entities.ai.EntityAIEatStone;
 import fr.wind_blade.isorropia.common.entities.ai.IEatStone;
 import net.minecraft.entity.EntityLiving;
 import net.minecraft.entity.ai.EntityAIBase;
 import net.minecraft.entity.passive.EntityPig;
 import net.minecraft.init.Blocks;
 import net.minecraft.init.Items;
 import net.minecraft.item.ItemStack;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.world.World;
 
 public class EntityOrePig
   extends EntityPig
   implements IEatStone
 {
   private OrePigEntry ore_entry;
   private int orePercent;
   
   public EntityOrePig(World world) {
/* 25 */     super(world);
/* 26 */     this.orePercent = 0;
   }
 
   
   protected void func_184651_r() {
/* 31 */     super.func_184651_r();
/* 32 */     this.field_70714_bg.func_75776_a(9, (EntityAIBase)new EntityAIEatStone((EntityLiving)this));
   }
 
 
   
   public void eatStone() {
/* 38 */     this.orePercent += this.field_70170_p.field_73012_v.nextInt(15) + 1;
/* 39 */     if (this.orePercent >= 100) {
/* 40 */       this.orePercent -= 100;
/* 41 */       excreteNugget();
     } 
   }
   
   private void excreteNugget() {
     OrePigEntry entry;
/* 47 */     if (this.ore_entry != null && this.ore_entry.isActive()) {
/* 48 */       entry = (OrePigEntry)DuoWeightedRandom.getRandomItemWithMain(this.field_70146_Z, (DuoWeightedRandom.DuoItem)this.ore_entry, Config.ORE_PIG_ENTRIES);
     } else {
/* 50 */       entry = (OrePigEntry)DuoWeightedRandom.getRandomItem(this.field_70146_Z, Config.ORE_PIG_ENTRIES);
     } 
     
/* 53 */     if (entry != null) {
/* 54 */       ItemStack stack = (ItemStack)Config.orePigOreDictionary.get(entry.getOreDictionary());
/* 55 */       if (stack != null && !stack.func_190926_b()) {
/* 56 */         func_70099_a(stack.func_77946_l(), 0.0F);
         
         return;
       } 
     } 
/* 61 */     excreteNugget();
   }
 
   
   protected void func_70628_a(boolean p_70628_1_, int p_70628_2_) {
/* 66 */     for (int j = this.field_70146_Z.nextInt(3) + 1 + this.field_70146_Z.nextInt(1 + p_70628_2_), k = 0; k < j; k++) {
/* 67 */       func_70099_a(new ItemStack(Blocks.field_150348_b), 1.0F);
     }
/* 69 */     if (func_70901_n()) {
/* 70 */       func_145779_a(Items.field_151141_av, 1);
     }
   }
   
   public void setOre(String oreName) {
/* 75 */     this
/* 76 */       .ore_entry = Config.ORE_PIG_ENTRIES.stream().filter(entry -> entry.getOreDictionary().equals(oreName)).findFirst().get();
   }
 
   
   public void func_70014_b(NBTTagCompound compound) {
/* 81 */     super.func_70014_b(compound);
/* 82 */     compound.func_74768_a("percent", this.orePercent);
/* 83 */     if (this.ore_entry != null) {
/* 84 */       compound.func_74778_a("oreName", this.ore_entry.getOreDictionary());
     }
   }
   
   public void func_70037_a(NBTTagCompound compound) {
/* 89 */     super.func_70037_a(compound);
/* 90 */     this.orePercent = compound.func_74762_e("percent");
/* 91 */     this
       
/* 93 */       .ore_entry = Config.ORE_PIG_ENTRIES.stream().filter(entry -> entry.getOreDictionary().equals(compound.func_74779_i("oreName"))).findFirst().orElse(null);
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityOrePig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */