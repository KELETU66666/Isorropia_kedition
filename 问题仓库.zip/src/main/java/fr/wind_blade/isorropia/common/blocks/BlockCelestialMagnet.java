 package fr.wind_blade.isorropia.common.blocks;
 
 import fr.wind_blade.isorropia.Isorropia;
 import fr.wind_blade.isorropia.common.tiles.TileCelestialMagnet;
 import net.minecraft.block.Block;
 import net.minecraft.block.ITileEntityProvider;
 import net.minecraft.block.material.Material;
 import net.minecraft.block.properties.IProperty;
 import net.minecraft.block.properties.PropertyDirection;
 import net.minecraft.block.state.BlockStateContainer;
 import net.minecraft.block.state.IBlockState;
 import net.minecraft.entity.EntityLivingBase;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.item.ItemStack;
 import net.minecraft.tileentity.TileEntity;
 import net.minecraft.util.BlockRenderLayer;
 import net.minecraft.util.EnumFacing;
 import net.minecraft.util.EnumHand;
 import net.minecraft.util.math.BlockPos;
 import net.minecraft.world.World;
 import net.minecraftforge.fml.common.network.internal.FMLNetworkHandler;
 import thaumcraft.api.aspects.IEssentiaContainerItem;
 import thaumcraft.api.blocks.ILabelable;
 
 public class BlockCelestialMagnet
   extends Block implements ITileEntityProvider, ILabelable {
/* 27 */   public static PropertyDirection FACING = PropertyDirection.func_177714_a("facing");
   
   public BlockCelestialMagnet(Material materialIn) {
/* 30 */     super(materialIn);
   }
 
   
   public IBlockState func_176203_a(int meta) {
/* 35 */     return func_176223_P().func_177226_a((IProperty)FACING, (Comparable)EnumFacing.func_82600_a(meta));
   }
 
   
   public int func_176201_c(IBlockState state) {
/* 40 */     return ((EnumFacing)state.func_177229_b((IProperty)FACING)).func_176745_a();
   }
 
   
   public BlockStateContainer func_180661_e() {
/* 45 */     return new BlockStateContainer(this, new IProperty[] { (IProperty)FACING });
   }
 
 
   
   public IBlockState func_180642_a(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
/* 51 */     return func_176223_P().func_177226_a((IProperty)FACING, (Comparable)facing);
   }
 
   
   public TileEntity func_149915_a(World worldIn, int meta) {
/* 56 */     return (TileEntity)new TileCelestialMagnet();
   }
   
   public BlockRenderLayer getBlockLayer() {
/* 60 */     return BlockRenderLayer.TRANSLUCENT;
   }
 
   
   public boolean func_149662_c(IBlockState state) {
/* 65 */     return false;
   }
 
   
   public boolean func_149686_d(IBlockState state) {
/* 70 */     return false;
   }
 
 
   
   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
/* 76 */     FMLNetworkHandler.openGui(playerIn, Isorropia.instance, 0, worldIn, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/* 77 */     return super.func_180639_a(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
   }
 
   
   public boolean applyLabel(EntityPlayer entityPlayer, BlockPos pos, EnumFacing enumFacing, ItemStack stack) {
/* 82 */     if (!stack.func_190926_b()) {
/* 83 */       World worldIn = entityPlayer.field_70170_p;
/* 84 */       TileEntity te = worldIn.func_175625_s(pos);
/* 85 */       if (!(te instanceof TileCelestialMagnet))
/* 86 */         return false; 
/* 87 */       TileCelestialMagnet temp = (TileCelestialMagnet)te;
/* 88 */       if (stack.func_77973_b() instanceof thaumcraft.common.items.consumables.ItemLabel) {
/* 89 */         IEssentiaContainerItem label = (IEssentiaContainerItem)stack.func_77973_b();
/* 90 */         if (label.getAspects(stack) != null) {
/* 91 */           return temp.addAspectFilter(label.getAspects(stack).getAspects()[0]);
         }
       } 
     } 
/* 95 */     return false;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\blocks\BlockCelestialMagnet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */