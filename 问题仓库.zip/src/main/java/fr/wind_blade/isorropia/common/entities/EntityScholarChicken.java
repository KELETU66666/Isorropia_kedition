 package fr.wind_blade.isorropia.common.entities;
 
 import fr.wind_blade.isorropia.common.items.ItemsIS;
 import net.minecraft.entity.passive.EntityChicken;
 import net.minecraft.init.Items;
 import net.minecraft.init.SoundEvents;
 import net.minecraft.nbt.NBTTagCompound;
 import net.minecraft.world.World;
 
 
 
 public class EntityScholarChicken
   extends EntityChicken
 {
   public int timeUntilNextFeather;
   
   public EntityScholarChicken(World world) {
/* 18 */     super(world);
/* 19 */     this.field_70887_j = this.field_70146_Z.nextInt(6000) + 6000;
/* 20 */     this.timeUntilNextFeather = this.field_70146_Z.nextInt(4000) + 4000;
   }
 
   
   public void func_70636_d() {
/* 25 */     int notTime = this.field_70887_j;
/* 26 */     this.field_70887_j = Integer.MAX_VALUE;
/* 27 */     super.func_70636_d();
/* 28 */     this.field_70887_j = notTime;
     
/* 30 */     if (this.field_70170_p.field_72995_K || func_70631_g_() || func_152116_bZ()) {
       return;
     }
/* 33 */     if (--this.field_70887_j <= 0) {
/* 34 */       func_184185_a(SoundEvents.field_187665_Y, 1.0F, (this.field_70146_Z
/* 35 */           .nextFloat() - this.field_70146_Z.nextFloat()) * 0.2F + 1.0F);
/* 36 */       func_145779_a(ItemsIS.itemInkEgg, 1);
/* 37 */       this.field_70887_j = this.field_70146_Z.nextInt(6000) + 6000;
     } 
     
/* 40 */     if (--this.timeUntilNextFeather <= 0) {
/* 41 */       func_184185_a(SoundEvents.field_187665_Y, 1.0F, (this.field_70146_Z
/* 42 */           .nextFloat() - this.field_70146_Z.nextFloat()) * 0.2F + 1.0F);
/* 43 */       func_145779_a(Items.field_151008_G, 1);
/* 44 */       this.timeUntilNextFeather = this.field_70146_Z.nextInt(4000) + 4000;
     } 
   }
 
   
   public void func_70014_b(NBTTagCompound compound) {
/* 50 */     super.func_70014_b(compound);
/* 51 */     compound.func_74768_a("egg", this.field_70887_j);
/* 52 */     compound.func_74768_a("feather", this.timeUntilNextFeather);
   }
 
   
   public void func_70037_a(NBTTagCompound compound) {
/* 57 */     super.func_70037_a(compound);
/* 58 */     this.field_70887_j = (compound.func_74762_e("egg") != 0) ? compound.func_74762_e("egg") : this.field_70887_j;
/* 59 */     this.timeUntilNextFeather = (compound.func_74762_e("feather") != 0) ? compound.func_74762_e("feather") : this.timeUntilNextFeather;
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\entities\EntityScholarChicken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */