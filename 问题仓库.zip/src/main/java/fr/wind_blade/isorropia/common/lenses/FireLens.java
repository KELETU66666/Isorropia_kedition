 package fr.wind_blade.isorropia.common.lenses;
 
 import fr.wind_blade.isorropia.common.items.misc.ItemLens;
 import net.minecraft.client.Minecraft;
 import net.minecraft.client.gui.ScaledResolution;
 import net.minecraft.entity.player.EntityPlayer;
 import net.minecraft.potion.Potion;
 import net.minecraft.potion.PotionEffect;
 import net.minecraft.world.World;
 
 public class FireLens
   extends Lens {
   public FireLens(ItemLens lensIn) {
/* 14 */     super(lensIn);
   }
 
 
 
   
   public void handleTicks(World worldIn, EntityPlayer playerIn, boolean doubleLens) {}
 
 
   
   public void handleRenderGameOverlay(World worldIn, EntityPlayer player, ScaledResolution resolution, boolean doubleLens, float partialTicks) {
/* 25 */     if (worldIn.field_72995_K) {
/* 26 */       Minecraft mc = Minecraft.func_71410_x();
/* 27 */       if (!mc.field_71439_g.func_70644_a(Potion.func_188412_a(16)) || mc.field_71439_g
/* 28 */         .func_70660_b(Potion.func_188412_a(16)).func_76459_b() < 242) {
/* 29 */         mc.field_71439_g.func_70690_d(new PotionEffect(Potion.func_188412_a(16), 255, 0, false, false));
       }
     } 
   }
 
 
   
   public void handleRenderWorldLast(World worldIn, EntityPlayer playerIn, boolean doubleLens, float partialTicks) {}
 
   
   public void handleRemoval(World worldIn, EntityPlayer playerIn) {
/* 40 */     playerIn.func_184589_d(Potion.func_188412_a(16));
   }
 }


/* Location:              E:\新建文件夹 (2)\isorropia-1.12.2-0.1.14.jar!\fr\wind_blade\isorropia\common\lenses\FireLens.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */